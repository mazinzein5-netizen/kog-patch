KINGDOM ORGANICS - FIGMA WORK PACK
============================================

Figma file key : LeyqF0AgnduyZGn2eRH4t3
Title          : Glassmorphism is on Figma! (Community) (Copy)
Created        : 2026-09-22T14:14:17Z  (your fork)
Access         : view (link shared)

OPEN IN THE FIGMA APP ON YOUR PHONE
  Tap this link on the phone and Android will hand it to Figma:

      figma://file/LeyqF0AgnduyZGn2eRH4t3

  Web fallback (any browser):
      https://www.figma.com/design/LeyqF0AgnduyZGn2eRH4t3

WHAT IS IN THIS PACK

  figma_extract/          what could be pulled WITHOUT a token
     figma_meta.json          file metadata (name, dates, access)
     figma_cover_full.png     canvas cover render, 1708x1200
     figma_cover_2x.png       same, 2x nearest-neighbour zoom
     figma_thumbnail1200x.webp  original signed render

  v172_design_pack/       YOUR APP design system at build v172
     design-sheet.html        import target for html.to.design
     tokens.json              Tokens Studio colour/radius/blur set
     KOG-v172-design-board.png  flat swatch/reference sheet
     screens/                 live v172 app screenshots

WHAT IS NOT HERE, AND WHY
  The individual frames of your Figma file are NOT in this pack.
  Figma serves them only through the authenticated API. Anonymous
  access returns one cover thumbnail and nothing more - height 1600
  and 2000 both return HTTP 400.

  To export every frame properly, a free read-only Figma token is
  needed. See the token instructions in the chat.

COST: EUR 0