KINGDOM ORGANICS - v172 FIGMA PACK (WINDOWS)
====================================================

Built from src/index.css at BUILD v172. All colours, glass recipes
and radii were extracted from the live source, not typed by hand.

FILES
  design-sheet.html           the main import - opens in any browser
  tokens.json                 Tokens Studio colour/radius/blur set
  KOG-v172-design-board.png   flat reference sheet, always imports
  screens/                    5 live v172 screenshots
  README-WINDOWS.txt          this file

METHOD 1 - EDITABLE LAYERS (recommended)
  1. Unzip this folder somewhere permanent, e.g. C:\kog-figma
  2. Open Figma desktop or figma.com in Chrome
  3. Menu > Plugins > search "html.to.design" and Run it
  4. Choose "Import from local file"
  5. Pick design-sheet.html from the unzipped folder
  6. Wait for it to render. You get real editable text layers,
     rectangles and colour fills - not a screenshot.

METHOD 2 - TOKENS (styles only)
  1. Menu > Plugins > search "Tokens Studio" and Run it
  2. Import > select tokens.json
  3. Colour, radius and blur tokens appear as variables

METHOD 3 - FLAT REFERENCE (zero plugins)
  1. Drag KOG-v172-design-board.png straight onto the Figma canvas
  2. Or drag any file from screens/ for a device-accurate frame

NOTE ON THE SCREENS
  Only 5 screens are included. The original capture set had 8 files
  but 3 were byte-identical duplicates (dark==light for home and
  menu, and splash2==splash3), so they were removed rather than
  presented as separate theme proofs.

COST: EUR 0