// Kingdom Organics API - Express service (Render-ready)
const express = require('express');
const cors = require('cors');
const store = require('./store');

const app = express();
const PORT = process.env.PORT || 8787;
const ALLOWED_ORIGINS = [
  'https://aura-grocery.vercel.app',
  /https:\/\/aura-grocery-[a-z0-9]+-mazinzein5-5571s-projects\.vercel\.app$/
];
app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true); // curl / same-origin / native
    if (ALLOWED_ORIGINS.some(o => o instanceof RegExp ? o.test(origin) : o === origin)) return cb(null, true);
    return cb(null, true); // dev: reflect all origins; tighten before production auth work
  }
}));
app.use(express.json({ limit: '25mb' })); // base64 phone photos


const ok = (res, data) => res.status(200).json(data);

app.get('/api/health', (req, res) => ok(res, {ok:true, service:'kingdom-organics-api', ts:Date.now(), version:'1.0.0'}));

// loyalty
app.get('/api/loyalty/balance', (req, res) => ok(res, store.getPoints()));
app.post('/api/loyalty/earn', (req, res) => ok(res, store.addPoints((req.body||{}).amt)));
app.get('/api/member-offers', (req, res) => ok(res, store.memberOffers()));

// inventory
app.get('/api/inventory', (req, res) => ok(res, store.listInventory()));
app.post('/api/inventory/ingest', (req, res) => {
  // Stub parser: real implementation should OCR/parse the uploaded file.
  const parsed = store.addInventory((req.body&&req.body.items)||[
    {name:'Bulgur Wheat',sku:'P4',price:2.90,unit:'kg'},
    {name:'Pekmez',sku:'C3',price:4.90,unit:'jar'}
  ]);
  ok(res, {parsed});
});
app.get('/api/inventory/:id/sticker', (req, res) => {
  const inv = store.listInventory().find(i => i.id === req.params.id);
  if (!inv) return res.status(404).json({error:'not found'});
  const qr = 'https://kingdomorganics.ie/p/' + encodeURIComponent(inv.id); // TODO: real QR image generation
  ok(res, {id:inv.id, name:inv.name, sku:inv.id, price:inv.price, qr});
});

// distributors
app.get('/api/distributors', (req, res) => ok(res, store.listDistributors()));
app.get('/api/distributors/:id', (req, res) => {
  const d = store.getDistributor(req.params.id);
  if (!d) return res.status(404).json({error:'not found'});
  ok(res, d);
});

// me
app.get('/api/me', (req, res) => ok(res, store.getMe()));
app.post('/api/me', (req, res) => ok(res, store.saveMe(req.body)));
app.post('/api/me/location', (req, res) => ok(res, store.saveLocation(req.body)));

// chat
app.get('/api/chat/history', (req, res) => ok(res, store.chatHistory()));
app.post('/api/chat/send', (req, res) => ok(res, store.addChat((req.body||{}).msg)));

// auth (stub verify - replace with real provider later)
app.post('/api/auth/session', (req, res) => {
  const role = (req.body&&req.body.role)||'customer';
  ok(res, {role, token:'stub-'+role+'-'+Date.now(), user:{name:'Mazin'}});
});
app.post('/api/auth/logout', (req, res) => ok(res, {ok:true}));

/* ------------------------------------------------------------------ *
 * Scan -> AI -> review -> inventory + accountant ledger
 * ------------------------------------------------------------------ */
const ai = require('./ai');

// POST /api/scan  { images:[{name,mime,data}], hint? }  -> structured document, nothing committed
app.post('/api/scan', async (req, res) => {
  const body = req.body || {};
  const images = (Array.isArray(body.images) ? body.images : []).filter((i) => i && i.data);
  if (!images.length) return res.status(400).json({ error: 'no images', hint: 'send {images:[{name,mime,data(base64)}]}' });
  try {
    const doc = await ai.extract(images, body.hint);
    const rec = store.addDocument(doc, { files: images.map((i) => ({ name: i.name || 'photo', mime: i.mime || 'image/jpeg', size: Math.round(String(i.data).length * 0.75) })), by: (body.by || 'admin') });
    ok(res, { document: rec, ai: { mode: ai.MODE, model: ai.MODEL, key: ai.HAS_KEY } });
  } catch (e) {
    res.status(500).json({ error: String(e.message || e) });
  }
});

// what the scanner is wired to, so the UI can warn "demo data" vs "live AI"
app.get('/api/scan/mode', (req, res) => ok(res, { mode: ai.MODE, model: ai.MODEL, base: ai.BASE, hasKey: ai.HAS_KEY }));

app.get('/api/documents', (req, res) => ok(res, store.listDocuments()));
app.get('/api/documents/:id', (req, res) => { const d = store.getDocument(req.params.id); d ? ok(res, d) : res.status(404).json({ error: 'not found' }); });

// POST /api/documents/:id/commit { lines:[...] }  -> inventory + ledger (the human-confirmed step)
app.post('/api/documents/:id/commit', (req, res) => {
  const out = store.commitDocument(req.params.id, (req.body || {}).lines);
  out ? ok(res, out) : res.status(404).json({ error: 'not found' });
});

app.get('/api/ledger', (req, res) => ok(res, store.listLedger()));
app.post('/api/ledger', (req, res) => ok(res, store.addLedgerEntry(req.body)));

// the AI accountant's input: totals, VAT, spend per distributor, pending scans, stock value
app.get('/api/accountant/summary', (req, res) => ok(res, store.accountantSummary()));

app.listen(PORT, () => console.log('kingdom-organics-api listening on port '+PORT));
