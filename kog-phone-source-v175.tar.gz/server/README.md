# Kingdom Organics API (Render-ready)

Express backend for the Kingdom Organics grocery app.

## Run locally

```bash
cd server
npm install
PORT=8787 node index.js
# health check: curl http://localhost:8787/api/health
```

## Deploy on Render

1. Push this repo to GitHub (repo root contains render.yaml Blueprint).
2. In Render: New -> Blueprint -> select the repo -> Apply.
   Render uses `rootDir: server`, installs deps and starts `node index.js`.
3. Health check path is `/api/health`.

## Endpoints

| Method | Path | Response |
|--------|------|----------|
| GET | /api/health | `{ok,service,ts,version}` |
| GET | /api/loyalty/balance | `{points,memberId,tier}` |
| POST | /api/loyalty/earn | `{earned,total}` (body: `{amt}`) |
| GET | /api/member-offers | `[{t,price}]` |
| GET | /api/inventory | `[{id,name,price,stock}]` |
| POST | /api/inventory/ingest | `{parsed:[{name,sku,price,unit}]}` |
| GET | /api/inventory/:id/sticker | `{id,name,sku,price,qr}` |
| GET | /api/distributors | `[{id,supplier,date,items}]` |
| GET | /api/distributors/:id | distributor detail |
| GET | /api/me | `{name,age,sex,address,eircode,location}` |
| POST | /api/me | saved profile |
| POST | /api/me/location | `{ok,location}` (body: `{lat,lng}`) |
| GET | /api/chat/history | `[{msg,ts}]` |
| POST | /api/chat/send | `{ok:true}` (body: `{msg}`) |
| POST | /api/auth/session | `{role,token,user}` (body: `{role}`) |
| POST | /api/auth/logout | `{ok:true}` |

## Data layer

`store.js` is an in-memory seed mirroring `src/lib/data.ts`.
TODO: swap for Postgres behind the SAME function signatures.
