// Kingdom Organics - in-memory data store.
// TODO: swap for Postgres (Neon/Render Postgres) behind the SAME function
// signatures. Route handlers must not change when that happens.
const CATEGORIES = [
  {id:'meat',title:'MEAT & POULTRY'},
  {id:'rice',title:'RICE, WHEAT & GRAINS'},
  {id:'spices',title:'ORIENTAL SPICES & SPECIALTY OILS'},
  {id:'produce',title:'ORGANIC VEGETABLE PRODUCE'},
  {id:'beans',title:'BEANS, SEEDS & AFRICAN SPECIALTY ITEMS'},
  {id:'dairy',title:'DAIRY & MILK PURE NATURAL'}
];
const PRODUCTS = [
  {id:'P1',name:'Basmati Rice',sub:'Aromatic & Aged Rice',price:2.90,cat:'rice',stock:120,sku:'P1',unit:'kg'},
  {id:'P2',name:'Organic Wheat Groats',sub:'High in Fiber & Protein',price:2.90,cat:'rice',stock:80,sku:'P2',unit:'kg'},
  {id:'P3',name:'Organic Verde Rice',sub:'Whole Grain & Gluten-Free',price:2.90,cat:'rice',stock:60,sku:'P3',unit:'kg'},
  {id:'P4',name:'Bulgur Wheat',sub:'Cracked Wheat',price:2.90,cat:'rice',stock:120,sku:'P4',unit:'kg'},
  {id:'C1',name:'Royal Saffron',sub:'Premium Threads',price:6.90,cat:'spices',stock:40,sku:'C1',unit:'jar'},
  {id:'C2',name:'Turmeric Powder',sub:'Cold Ground',price:3.90,cat:'spices',stock:90,sku:'C2',unit:'jar'},
  {id:'C3',name:'Pekmez',sub:'Grape Molasses',price:4.90,cat:'spices',stock:60,sku:'C3',unit:'jar'},
  {id:'D1',name:'Farm Milk 1L',sub:'Whole & Pasteurised',price:2.40,cat:'dairy',stock:75,sku:'D1',unit:'L'},
  {id:'D2',name:'Aged Cheddar',sub:'12-Month Matured',price:5.40,cat:'dairy',stock:40,sku:'D2',unit:'block'}
];
const STORES = [
  {id:'kingdom',name:'Kingdom Organics',kind:'HALAL SHOP • ORGANIC ORIENTAL & LOCAL ITEMS',live:true,rating:4.9,distance:'0.8 km'},
  {id:'yousef',name:"Yousef's Spice",kind:'HALAL SHOP • ORIENTAL SPECIALTY',live:true,rating:4.7,distance:'1.2 km'},
  {id:'terry',name:'Terry Health Foods',kind:'HEALTH FOODS',live:false,rating:4.6,distance:'2.0 km'},
  {id:'manna',name:'Manna Grocery',kind:'WHOLEFOODS & GRAINS',live:false,rating:4.5,distance:'2.4 km'},
  {id:'kerry',name:'Kerry Fresh Produce',kind:'FARM PRODUCE',live:false,rating:4.8,distance:'3.1 km'},
  {id:'aran',name:'Aran Organics',kind:'CERTIFIED ORGANIC',live:false,rating:4.8,distance:'4.0 km'},
  {id:'atlantic',name:'Atlantic Seafood & More',kind:'SEAFOOD • LOCAL',live:false,rating:4.4,distance:'4.0 km'}
];
const MEMBER_OFFERS = [
  {t:'Lamb Chops',price:'Member €9.99'},
  {t:'Basmati Rice',price:'Member €2.49'},
  {t:'Black Seed Oil',price:'Member €5.99'}
];
let points = 1250;
const MEMBER_ID = '123456789';
const TIER = 'GOLD';
let inventory = PRODUCTS.map(p=>({id:p.id,name:p.name,price:p.price,stock:p.stock}));
let distributors = [
  {id:'D1',supplier:'Halal Meats Co.',date:'2026-09-05',items:[{name:'Grass-fed Beef Box',qty:10,price:42.00}]},
  {id:'D2',supplier:'Green Valley Organics',date:'2026-09-08',items:[{name:'Organic Veg Crate',qty:24,price:18.50},{name:'Free-range Eggs (tray)',qty:12,price:4.20}]}
];
let me = {name:'Mazin',age:34,sex:'M',address:'12 Main St',eircode:'V92',location:null};
let chat = [];
const getPoints = () => ({points,memberId:MEMBER_ID,tier:TIER});
const addPoints = (amt) => { const n=Math.max(0,Math.round(Number(amt)||0)); points+=n; return {earned:n,total:points}; };
const memberOffers = () => MEMBER_OFFERS.slice();
const listInventory = () => inventory.map(i=>({...i}));
const addInventory = (items) => { const parsed=(Array.isArray(items)?items:[]).map((it,i)=>({id:it.sku||('X'+(inventory.length+1+i)),name:it.name||'Item',sku:it.sku||('X'+(inventory.length+1+i)),price:Number(it.price)||0,unit:it.unit||'unit'})); inventory=[...inventory,...parsed.map(p=>({id:p.id,name:p.name,price:p.price,stock:100}))]; return parsed; };
const listDistributors = () => distributors.map(d=>({...d,items:d.items.map(i=>({...i}))}));
const getDistributor = (id) => { const d=distributors.find(x=>x.id===id); return d?{...d,items:d.items.map(i=>({...i}))}:null; };
const getMe = () => ({...me});
const saveMe = (d) => { me={...me,...(d||{})}; return {...me}; };
const saveLocation = (loc) => { me={...me,location:loc||null}; return {ok:true,location:me.location}; };
const chatHistory = () => chat.slice();
const addChat = (msg) => { chat.push({msg,ts:Date.now()}); return {ok:true}; };

/* ------------------------------------------------------------------ *
 * Scan -> AI -> ledger spine.
 * documents: every photo/screenshot/upload the owner ran through /api/scan
 * ledger:    confirmed distributor invoices / statements, the AI accountant's input
 * ------------------------------------------------------------------ */
const fs = require('fs');
const path = require('path');
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');
let documents = [];
let ledger = [];

function persist() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify({ points, inventory, distributors, documents, ledger, me, chat }, null, 2));
  } catch (e) { /* free instance with no disk: stay in memory */ }
}
function load() {
  try {
    const j = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (j.points) points = j.points;
    if (Array.isArray(j.inventory) && j.inventory.length) inventory = j.inventory;
    if (Array.isArray(j.distributors) && j.distributors.length) distributors = j.distributors;
    if (Array.isArray(j.documents)) documents = j.documents;
    if (Array.isArray(j.ledger)) ledger = j.ledger;
    if (j.me) me = j.me;
    if (Array.isArray(j.chat)) chat = j.chat;
  } catch (e) { /* first boot */ }
}
load();

const addDocument = (doc, meta) => {
  const rec = {
    id: 'doc_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    at: Date.now(),
    status: 'pending',            // pending -> confirmed (nothing hits the ledger until a human confirms)
    source: meta || {},           // {files:[{name,size,mime}], by:'admin'}
    doc,
  };
  documents = [rec, ...documents].slice(0, 200);
  persist();
  return rec;
};
const listDocuments = () => documents.map((d) => ({ ...d }));
const getDocument = (id) => documents.find((d) => d.id === id) || null;

// Human-confirmed rows: merge into inventory (match on SKU, else on name) and write the ledger entry.
const commitDocument = (id, lines) => {
  const rec = getDocument(id);
  if (!rec) return null;
  const rows = Array.isArray(lines) && lines.length ? lines : rec.doc.lines;
  const merged = [];
  rows.forEach((l, i) => {
    const name = String((l && l.name) || '').trim();
    const sku = String((l && l.sku) || '').trim().toLowerCase();
    if (!name) return;
    const hit = inventory.find(
      (it) => (sku && String(it.sku || it.id).toLowerCase() === sku) || String(it.name).toLowerCase() === name.toLowerCase()
    );
    const qty = Number(l.qty) || 0;
    const price = Number(l.unitPrice) || Number(l.price) || 0;
    if (hit) {
      hit.stock = (Number(hit.stock) || 0) + qty;
      if (price) hit.price = price;
      merged.push({ ...hit, matched: true, added: qty });
    } else {
      const row = { id: l.sku || 'X' + (inventory.length + 1 + i), name, sku: l.sku || '', price, stock: qty, unit: l.unit || 'unit' };
      inventory = [...inventory, row];
      merged.push({ ...row, matched: false, added: qty });
    }
  });
  const entry = {
    id: 'led_' + Date.now().toString(36),
    at: Date.now(),
    docId: rec.id,
    type: (rec.doc && rec.doc.type) || 'other',
    supplier: (rec.doc && rec.doc.supplier) || 'Unknown supplier',
    invoiceNo: (rec.doc && rec.doc.invoiceNo) || '',
    date: (rec.doc && rec.doc.date) || null,
    currency: (rec.doc && rec.doc.currency) || 'EUR',
    lines: rows,
    subtotal: (rec.doc && rec.doc.subtotal) || 0,
    vat: (rec.doc && rec.doc.vat) || 0,
    total: (rec.doc && rec.doc.total) || 0,
    status: 'confirmed',
  };
  ledger = [entry, ...ledger].slice(0, 500);
  rec.status = 'confirmed';
  rec.committed = { at: Date.now(), rows: merged.length, entryId: entry.id };
  persist();
  return { document: { ...rec }, inventory: merged, entry };
};

const addLedgerEntry = (entry) => { const e = { id: 'led_' + Date.now().toString(36), at: Date.now(), ...(entry || {}) }; ledger = [e, ...ledger].slice(0, 500); persist(); return e; };
const listLedger = () => ledger.map((e) => ({ ...e }));

// Everything the AI accountant needs, pre-summarised so the chat model only has to explain it.
const accountantSummary = () => {
  const bySupplier = {};
  const byMonth = {};
  let spend = 0, vat = 0;
  ledger.forEach((e) => {
    const t = Number(e.total) || 0;
    spend += t;
    vat += Number(e.vat) || 0;
    const s = e.supplier || 'Unknown supplier';
    bySupplier[s] = bySupplier[s] || { supplier: s, total: 0, invoices: 0 };
    bySupplier[s].total += t;
    bySupplier[s].invoices += 1;
    const m = (e.date || new Date(e.at).toISOString()).slice(0, 7);
    byMonth[m] = (byMonth[m] || 0) + t;
  });
  const items = inventory.map((i) => ({ ...i }));
  return {
    generatedAt: new Date().toISOString(),
    documents: {
      total: documents.length,
      pending: documents.filter((d) => d.status === 'pending').length,
      byType: documents.reduce((a, d) => { const t = (d.doc && d.doc.type) || 'other'; a[t] = (a[t] || 0) + 1; return a; }, {}),
    },
    spend: {
      total: Number(spend.toFixed(2)),
      vat: Number(vat.toFixed(2)),
      invoices: ledger.length,
      bySupplier: Object.values(bySupplier).map((s) => ({ ...s, total: Number(s.total.toFixed(2)) })).sort((a, b) => b.total - a.total),
      byMonth: Object.keys(byMonth).sort().map((m) => ({ month: m, total: Number(byMonth[m].toFixed(2)) })),
    },
    inventory: { items: items.length, stockValue: Number(items.reduce((s, i) => s + (Number(i.price) || 0) * (Number(i.stock) || 0), 0).toFixed(2)), low: items.filter((i) => (Number(i.stock) || 0) < 25) },
    pending: documents.filter((d) => d.status === 'pending').map((d) => ({ id: d.id, at: d.at, supplier: (d.doc && d.doc.supplier) || '', type: (d.doc && d.doc.type) || 'other', lines: ((d.doc && d.doc.lines) || []).length })),
    recentLedger: ledger.slice(0, 10),
  };
};

module.exports={CATEGORIES,PRODUCTS,STORES,getPoints,addPoints,memberOffers,listInventory,addInventory,listDistributors,getDistributor,getMe,saveMe,saveLocation,chatHistory,addChat,addDocument,listDocuments,getDocument,commitDocument,addLedgerEntry,listLedger,accountantSummary,persist};
