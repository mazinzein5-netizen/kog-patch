// Kingdom Organics - document understanding for store admin.
// Owner/staff photograph, screenshot or upload *anything* (distributor invoice, delivery
// docket, stock sheet, price list, statement) and this turns it into structured rows that
// feed inventory + the AI accountant ledger.
//
// Provider is any OpenAI-compatible endpoint with vision:
//   AI_BASE_URL=https://api.openai.com/v1   AI_MODEL=gpt-4o-mini
//   AI_BASE_URL=http://127.0.0.1:11434/v1   AI_MODEL=qwen2.5vl:7b   (local ollama on the phone)
// With no AI_API_KEY set it runs SCAN_MODE=demo so the whole flow stays testable offline.

const CFG = {
  base: (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, ''),
  key: process.env.AI_API_KEY || '',
  model: process.env.AI_MODEL || 'gpt-4o-mini',
};
const MODE = process.env.SCAN_MODE || (CFG.key ? 'ai' : 'demo');

const PROMPT = [
  'You are the stock & accounts clerk for Kingdom Organics, a halal / organic / oriental grocery.',
  'The user photographed, screenshotted or uploaded one or more images of a single business document:',
  'a distributor invoice, a delivery docket, a stock or inventory sheet, a price list, or a supplier statement.',
  'Reply with JSON ONLY (no prose, no markdown fence) exactly in this shape:',
  '{"type":"distributor_invoice|stock_sheet|price_list|statement|other","supplier":"","invoiceNo":"","date":"YYYY-MM-DD",',
  '"currency":"EUR","lines":[{"name":"","sku":"","qty":0,"unit":"","unitPrice":0,"lineTotal":0}],',
  '"subtotal":0,"vat":0,"total":0,"confidence":0.0,"notes":["what you were unsure about"]}',
  'Rules: numbers must be JSON numbers with no currency symbols or thousands separators;',
  'keep item names exactly as printed; use null for anything unreadable; never invent a line item;',
  'sum the lines into subtotal, add VAT into vat, and put the gross into total;',
  'confidence is your own 0-1 estimate that the extraction is correct.',
  'If the images are not a business document, return type "other" with empty lines and explain in notes.',
].join(' ');

function toDataUrl(img) {
  const data = String(img.data || '').replace(/^data:[^,]+,/, '');
  const mime = img.mime || 'image/jpeg';
  return 'data:' + mime + ';base64,' + data;
}

function num(v) {
  if (typeof v === 'number' && isFinite(v)) return v;
  if (typeof v === 'string') {
    const n = parseFloat(v.replace(/[^0-9.,-]/g, '').replace(/\.(?=\d{3}\b)/g, '').replace(',', '.'));
    return isFinite(n) ? n : null;
  }
  return null;
}

// Never let a model response reach the ledger unshaped.
function normalise(doc, notes) {
  const d = doc && typeof doc === 'object' ? doc : {};
  const lines = (Array.isArray(d.lines) ? d.lines : []).map((l) => ({
    name: String((l && l.name) || 'Unnamed item').trim(),
    sku: String((l && l.sku) || '').trim(),
    qty: num(l && l.qty),
    unit: String((l && l.unit) || '').trim(),
    unitPrice: num(l && l.unitPrice),
    lineTotal: num(l && l.lineTotal),
  }));
  const sum = lines.reduce((s, l) => s + (l.lineTotal || (l.qty && l.unitPrice ? l.qty * l.unitPrice : 0)), 0);
  const subtotal = num(d.subtotal);
  return {
    type: String(d.type || 'other'),
    supplier: String(d.supplier || '').trim(),
    invoiceNo: String(d.invoiceNo || '').trim(),
    date: /^\d{4}-\d{2}-\d{2}$/.test(d.date) ? d.date : null,
    currency: String(d.currency || 'EUR').toUpperCase().slice(0, 3),
    lines,
    subtotal: subtotal === null ? Number(sum.toFixed(2)) : subtotal,
    vat: num(d.vat),
    total: num(d.total),
    confidence: typeof d.confidence === 'number' ? Math.max(0, Math.min(1, d.confidence)) : null,
    notes: [...(Array.isArray(d.notes) ? d.notes.map(String) : []), ...(notes || [])],
    mode: MODE,
  };
}

async function extractWithAI(images, hint) {
  const parts = [{ type: 'text', text: PROMPT + (hint ? ' Extra context from the shop owner: ' + hint : '') }];
  images.slice(0, 8).forEach((img) => parts.push({ type: 'image_url', image_url: { url: toDataUrl(img), detail: 'high' } }));
  parts.push({ type: 'text', text: 'Extract the document now. JSON only.' });
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 90000);
  try {
    const r = await fetch(CFG.base + '/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + CFG.key },
      body: JSON.stringify({
        model: CFG.model,
        temperature: 0,
        max_tokens: 4000,
        messages: [{ role: 'user', content: parts }],
      }),
      signal: ctl.signal,
    });
    if (!r.ok) throw new Error('AI ' + r.status + ' ' + (await r.text()).slice(0, 200));
    const j = await r.json();
    const text = (((j.choices || [])[0] || {}).message || {}).content || '';
    const json = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const start = json.indexOf('{');
    const end = json.lastIndexOf('}');
    if (start < 0 || end < 0) throw new Error('AI returned no JSON');
    return normalise(JSON.parse(json.slice(start, end + 1)), []);
  } finally {
    clearTimeout(t);
  }
}

// Deterministic stand-in so the UI, the review screen and the ledger can be built and
// demoed before an AI key exists.
function extractDemo(images) {
  return normalise(
    {
      type: 'distributor_invoice',
      supplier: 'Green Valley Organics',
      invoiceNo: 'GVO-' + String(Date.now()).slice(-5),
      date: new Date().toISOString().slice(0, 10),
      currency: 'EUR',
      lines: [
        { name: 'Organic Veg Crate', sku: '', qty: 24, unit: 'crate', unitPrice: 18.5, lineTotal: 444.0 },
        { name: 'Free-range Eggs (tray)', sku: '', qty: 12, unit: 'tray', unitPrice: 4.2, lineTotal: 50.4 },
        { name: 'Farm Milk 1L', sku: 'D1', qty: 60, unit: 'L', unitPrice: 1.55, lineTotal: 93.0 },
      ],
      subtotal: 587.4,
      vat: 0,
      total: 587.4,
      confidence: 0.62,
    },
    ['DEMO MODE - no AI_API_KEY set, so these rows are sample data, not read from your ' + images.length + ' image(s).']
  );
}

async function extract(images, hint) {
  if (MODE === 'ai') {
    try {
      return await extractWithAI(images, hint);
    } catch (e) {
      const d = extractDemo(images);
      d.notes.unshift('AI call failed (' + e.message + ') - showing demo rows.');
      return d;
    }
  }
  return extractDemo(images);
}

module.exports = { extract, normalise, MODE, MODEL: CFG.model, BASE: CFG.base, HAS_KEY: !!CFG.key };
