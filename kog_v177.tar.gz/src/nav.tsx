import React,{useState,useRef,useEffect} from 'react';
import {NAV_BY_ROLE,STORES} from './lib/data';
import {api} from './api';
import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {useApp} from './app-context';
import {eur} from './domain/cartMath';

gsap.registerPlugin(ScrollTrigger);

export const prefersReducedMotion=()=>typeof window!=='undefined'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export const go=(p:string)=>{location.hash=p};
export const cur=()=>location.hash.replace('#','')||'start';
export {useApp,eur};

export function useScrollReveal(ref:React.RefObject<HTMLElement|null>,opts={stagger:0.08,dur:0.6}){
  useEffect(()=>{
    const el=ref.current;if(!el)return;
    const items=el.querySelectorAll('[data-reveal]');
    if(!items.length)return;
    items.forEach((item:Element)=>{(item as HTMLElement).style.opacity='1';(item as HTMLElement).style.transform='none';});
    if(prefersReducedMotion())return;
    try{
      const t=gsap.timeline({scrollTrigger:{trigger:el,start:'top 90%',toggleActions:'play none none none'}});
      t.from(items,{opacity:0,duration:opts.dur,stagger:opts.stagger,ease:'power2.out'});
      return()=>t.kill();
    }catch(e){}
  },[ref.current]);
}

export function useParallax(ref:React.RefObject<HTMLElement|null>,intensity=0.3){
  useEffect(()=>{
    const el=ref.current;if(!el||prefersReducedMotion())return;
    gsap.to(el,{ease:'none',scrollTrigger:{trigger:el.parentElement||el,start:'top bottom',end:'bottom top',scrub:true}});
    return()=>ScrollTrigger.getAll().filter(t=>t.trigger===el).forEach(t=>t.kill());
  },[ref.current]);
}

const BUILD='v177';
const APP_VERSION='v146';
const UpdateBanner=()=>{const[upd,setUpd]=useState<string>('');useEffect(()=>{api.app.latest().then((r:any)=>{try{const lv=String((r&&(r.latest_version||r.version))||'').toLowerCase().replace(/^v/,'');if(lv){var nb=parseInt(String(BUILD).replace(/[^0-9]/g,''),10)||0;var nr=parseInt(lv.replace(/[^0-9]/g,''),10)||0;if(nr>nb)setUpd('v'+nr)}}catch(e){}}).catch(()=>{})},[]);if(!upd)return null;return(<div className="px-4 pt-1"><button onClick={()=>window.location.reload()} className="w-full glass rounded-xl px-3 py-1.5 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md"><span className="flex-1 text-left">Update available: {upd}. Tap to refresh.</span><span className="bg-ko-harvest text-[#1a1206] text-[10px] px-2.5 py-[3px] rounded-full">Refresh</span></button></div>);};

export const Badge=()=>(<div className="flex items-center gap-2"><img src="/assets/logo-globe-badge.webp" alt="Kingdom Organics" className="size-9 rounded-full object-contain ring-1 ring-white/30 shadow-glow"/><div className="leading-tight"><div className="font-bold" style={{fontFamily:'system-ui,sans-serif',letterSpacing:'8px'}}>KINGDOM</div><div className="text-[9px] tracking-[.25em] text-white/70">ORGANIC GROCERY</div></div></div>);
const Partner=()=>(<div className="text-right leading-tight"><div className="font-display text-ko-goldbright text-sm">YOUSEF'S<br/>SPICE</div><div className="text-[7px] tracking-wider text-white/70">HALAL SHOP<br/>ORGANIC ORIENTAL<br/>& LOCAL ITEMS</div></div>);
export const StoreBadge=({store}:{store?:any})=>{const st=store||STORES[0];const words=(st.short||st.name||'Kingdom').split(' ');return(<div className="text-right leading-tight"><div className="font-display text-sm" style={{color:st.accent||'#E8960F'}}>{words[0].toUpperCase()}<br/>{words.slice(1).join(' ').toUpperCase()}</div><div className="text-[7px] tracking-wider text-white/70">{(st.kind||'').split(' • ').map((k:string,i:number)=>(<span key={i} className="block">{k}</span>))}</div></div>)};
const MenuBtn=()=>{const[open,setOpen]=useState(false);const items=[['Profile','/profile'],['Settings','/settings']];const close=()=>setOpen(false);return(<div className='relative'><button onClick={()=>setOpen(o=>!o)} aria-label='Menu' className='nav-menu-btn size-9 flex items-center justify-center flex-col gap-[3px] rounded-full glass'><span className='block w-4 h-[2px] bg-current rounded'></span><span className='block w-4 h-[2px] bg-current rounded'></span><span className='block w-4 h-[2px] bg-current rounded'></span></button>{open&&<div className='absolute right-0 top-11 z-50 menu-drop rounded-2xl p-2 w-56 shadow-2xl backdrop-blur-xl border border-white/40 max-h-[70vh] overflow-y-auto'><div className='mb-1 px-3 pt-1 text-[10px] uppercase tracking-wider text-[#5a4a2a]/70'>Menu</div><div className='px-3 pb-1.5 text-[10px] font-bold text-[#3a2f18]'>Build {BUILD}</div>{items.map(([t,p])=>(<button key={p} onClick={()=>{go(p);close()}} className='w-full text-left px-3 py-2 rounded-xl text-sm font-semibold text-[#3a2f18] hover:bg-white/50 transition-colors'>{t}</button>))}</div>}</div>)};
const Header=({back,store}:{back?:string;store?:any})=>(<header className="sticky top-0 z-30 glass-nav text-ko-ink px-3 py-2.5 flex items-center justify-between backdrop-blur-xl"><div className="w-9">{back&&<button aria-label="Back" onClick={()=>go(back)} className="glass rounded-full size-9 flex items-center justify-center text-lg hover:scale-105 transition-transform">‹</button>}</div><Badge/><div className="flex items-center gap-2">{store&&<StoreBadge store={store}/>}<MenuBtn/></div></header>);
const Nav=()=>{const{role}=useApp();const items=NAV_BY_ROLE[role]||NAV_BY_ROLE.customer;const p=cur();return(<nav className="kog-nav-bottom flex gap-1 text-white justify-between glass-nav shadow-lg">{items.map((it)=>{const on=p===it.to;return(<button key={it.to} onClick={()=>go(it.to)} className={"flex flex-col items-center gap-1 px-4 py-1.5 rounded-full text-[10px] transition duration-300 "+(on?"bg-white/25 shadow-glow text-ko-goldbright scale-105":"text-white/80 hover:text-white")}><span className="text-base leading-none">{it.icon}</span>{it.label}</button>)})}</nav>)};

export const Shell=({children,nav=true,back}:{children:React.ReactNode;nav?:boolean;back?:string})=>{const{refresh,refreshKey}=useApp();const[pull,setPull]=useState(0);const[busy,setBusy]=useState(false);const y0=useRef(0);const live=useRef(false);
 const rf=useRef(refresh);rf.current=refresh;
 useEffect(()=>{const s=(e:TouchEvent)=>{live.current=window.scrollY<=0;y0.current=e.touches[0].clientY};
  const m=(e:TouchEvent)=>{if(!live.current)return;const dy=e.touches[0].clientY-y0.current;if(dy>0){setPull(Math.min(96,dy*0.5));if(dy>70)e.preventDefault()}else setPull(0)};
  const en=()=>{if(live.current&&y0.current){const dy=Math.min(96,pull);}const go=pull>=52;live.current=false;setPull(0);if(go){setBusy(true);rf.current();setTimeout(()=>setBusy(false),700)}};
  window.addEventListener('touchstart',s,{passive:true});window.addEventListener('touchmove',m,{passive:false});window.addEventListener('touchend',en);
  return()=>{window.removeEventListener('touchstart',s);window.removeEventListener('touchmove',m);window.removeEventListener('touchend',en)}},[]);
 return(<div className={"min-h-screen bg-gradient-to-b from-ko-deep to-ko-forest text-ko-ink max-w-[390px] mx-auto relative shadow-2xl"+(["driver","queue","delivery","active","delivered","earnings","kyc","driver-start"].some(p=>window.location.hash.includes(p))?" driver-glass":"")}>
  {(pull>0||busy)&&<div style={{position:'fixed',top:10,left:'50%',transform:'translateX(-50%)',zIndex:60}} className="px-3 py-1.5 rounded-full text-[11px] font-bold shadow-lg" ><span style={{background:'#F9F7F2',color:'#111827',padding:'6px 12px',borderRadius:999}}>{busy?'Refreshing…':pull>=52?'Release to refresh':'Pull to refresh'}</span></div>}
  <Header back={back}/><UpdateBanner/><main className={"pb-44"+(cur().startsWith("/p/")?" kog-curtain":"")}>{children}</main>{nav&&<div className="kog-nav-occluder" aria-hidden="true"/>}{nav&&<Nav/>}</div>)};

export const Btn=({children,onClick,ghost}:any)=>(<button onClick={onClick} className={`w-full py-3.5 rounded-2xl font-semibold transition active:scale-[.98] ${ghost?'glass text-white hover:bg-white/10':'bg-ko-harvest text-[#1a1206] shadow-lg hover:shadow-glow'}`}>{children}</button>);

export const FullBleed=({img,alt,to,label,bg}:any)=>(<div className="full-bleed-screen fb-contain" style={{background:bg||'#04301F'} as any}><div className="fullbleed-blur" style={{backgroundImage:'url('+img+')'} as any}/><button type="button" aria-label={label||'Continue'} className="fullbleed-tap" onClick={()=>go(to)}><img src={img} alt={alt||''} className="fullbleed-bg"/></button></div>);

export const BUILD_TAG=BUILD;
