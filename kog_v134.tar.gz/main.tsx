import React,{Component} from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

/* ---- runtime theme: ?theme=<base64url json>  OR localStorage 'ko-theme' ---- */
function b64d(s){try{s=String(s).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';return decodeURIComponent(escape(atob(s)))}catch(e){return null}}
function applyTheme(t){
  if(!t)return;
  var g=t.globals||t;
  for(var k in g){var name;k=k.trim();if(k.indexOf('--ko-')===0)name=k;else if(k.indexOf('--')===0)name='--ko-'+k.slice(2);else name='--ko-'+k;try{document.documentElement.style.setProperty(name,g[k])}catch(e){}}
}
/* deep links: /chat -> #/chat  (shareable URLs + screenshot-able screens) */
(function(){
  var p=location.pathname;
  if(p && p!=='/' && p.indexOf('/assets')!==0 && !location.hash){
    location.replace(location.origin+'/'+location.search+'#/'+p.replace(/^\//,''));
  }
})();
(function(){
  var m=location.search.match(/[?&]theme=([^&]+)/)||location.hash.match(/theme=([^&]+)/);
  var t=null;
  if(m){var raw=b64d(m[1]);if(raw){try{t=JSON.parse(raw)}catch(e){}}}
  if(!t){try{var ls=localStorage.getItem('ko-theme');if(ls)t=JSON.parse(ls)}catch(e){}}
  applyTheme(t);
  /* v134: apply the saved theme at boot, not only inside the Settings toggle */
  try{var tm=localStorage.getItem('kog-theme');
    document.documentElement.setAttribute('data-theme', tm==='dark'?'dark':'light');
  }catch(e){document.documentElement.setAttribute('data-theme','light')}
})();

class EB extends Component{constructor(p){super(p);this.state={e:null}}static getDerivedStateFromError(e){return {e: e}}render(){ if(this.state.e){ return React.createElement('div',{style:{padding:20,color:'#fff',background:'#8a2d1f',minHeight:'100vh',fontFamily:'monospace'}}, React.createElement('h2',null,'App error'), React.createElement('pre',{style:{whiteSpace:'pre-wrap'}}, String(this.state.e && this.state.e.stack || this.state.e))) } return this.props.children }}

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><EB><App/></EB></React.StrictMode>)
