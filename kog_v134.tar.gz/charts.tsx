import React from 'react';

/* Lightweight SVG charts - no chart library, crisp on any screen, and the
   colours come from the caller so every line keeps its measured contrast. */

export type Series = { name: string; color: string; points: number[] };

const money = (v: number) =>
  Math.abs(v) >= 1000 ? '€' + (v / 1000).toFixed(1) + 'k' : '€' + v.toFixed(0);

const smooth = (pts: { x: number; y: number }[]) => {
  if (pts.length < 2) return '';
  let d = 'M' + pts[0].x.toFixed(1) + ' ' + pts[0].y.toFixed(1);
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const c1x = p1.x + (p2.x - p0.x) / 6;
    const c1y = p1.y + (p2.y - p0.y) / 6;
    const c2x = p2.x - (p3.x - p1.x) / 6;
    const c2y = p2.y - (p3.y - p1.y) / 6;
    d += ' C' + c1x.toFixed(1) + ' ' + c1y.toFixed(1) + ',' + c2x.toFixed(1) + ' ' + c2y.toFixed(1) + ',' + p2.x.toFixed(1) + ' ' + p2.y.toFixed(1);
  }
  return d;
};

export const LineChart = ({
  labels, series, height = 180, area = true, moneyAxis = true, legend = true,
}: { labels: string[]; series: Series[]; height?: number; area?: boolean; moneyAxis?: boolean; legend?: boolean }) => {
  const W = 330, H = height, padL = 40, padR = 10, padT = 14, padB = 24;
  const count = Math.max(labels.length, 2);
  const all = series.flatMap((s) => s.points);
  const rawMax = all.length ? Math.max(...all) : 0;
  const rawMin = all.length ? Math.min(...all) : 0;
  const max = Math.max(rawMax * 1.12, rawMin > 0 ? rawMin * 1.2 : 1);
  const min = Math.min(0, rawMin);
  const X = (i: number) => padL + (i * (W - padL - padR)) / (count - 1);
  const Y = (v: number) => padT + (1 - (v - min) / ((max - min) || 1)) * (H - padT - padB);
  const ticks = [0, 0.5, 1].map((t) => min + t * (max - min));

  return (
    <div>
      <svg viewBox={'0 0 ' + W + ' ' + H} className="w-full" style={{ height: H, display: 'block' }} role="img">
        {ticks.map((t, i) => (
          <g key={i}>
            <line x1={padL} x2={W - padR} y1={Y(t)} y2={Y(t)} stroke="#111827" strokeOpacity={0.10} strokeWidth="1" />
            <text x={padL - 6} y={Y(t) + 3.5} textAnchor="end" fontSize="9" fill="#4B5563">
              {moneyAxis ? money(t) : Math.round(t)}
            </text>
          </g>
        ))}
        {labels.map((l, i) => (
          <text key={l + i} x={X(i)} y={H - 7} textAnchor="middle" fontSize="9" fill="#4B5563">
            {l.slice(5) + '/' + l.slice(2, 4)}
          </text>
        ))}
        {series.map((s) => {
          const pts = s.points.map((v, i) => ({ x: X(i), y: Y(v) }));
          const d = smooth(pts);
          const first = pts[0], last = pts[pts.length - 1];
          return (
            <g key={s.name}>
              {area && first && last && (
                <path d={d + ' L' + last.x.toFixed(1) + ' ' + Y(min) + ' L' + first.x.toFixed(1) + ' ' + Y(min) + ' Z'}
                  fill={s.color} fillOpacity={0.12} stroke="none" />
              )}
              <path d={d} fill="none" stroke={s.color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              {pts.map((p, i) => (
                <circle key={i} cx={p.x} cy={p.y} r={i === pts.length - 1 ? 3.6 : 2.1} fill={s.color} stroke="#F9F7F2" strokeWidth="1.2" />
              ))}
            </g>
          );
        })}
      </svg>
      {legend && (
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2">
          {series.map((s) => (
            <span key={s.name} className="flex items-center gap-1.5 text-[11px] text-gray-600">
              <span style={{ background: s.color }} className="size-2.5 rounded-full inline-block" />
              {s.name}
              <b className="text-[#111827]">{money(s.points[s.points.length - 1] || 0)}</b>
            </span>
          ))}
        </div>
      )}
    </div>
  );
};

export const Sparkline = ({ points, color = '#2A00D6', width = 72, height = 26 }:
  { points: number[]; color?: string; width?: number; height?: number }) => {
  const vals = points.length ? points : [0, 0];
  const max = Math.max(...vals, 1), min = Math.min(...vals, 0);
  const X = (i: number) => (i * width) / Math.max(vals.length - 1, 1);
  const Y = (v: number) => height - 2 - ((v - min) / ((max - min) || 1)) * (height - 5);
  const d = vals.map((v, i) => (i ? 'L' : 'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1)).join(' ');
  return (
    <svg width={width} height={height} viewBox={'0 0 ' + width + ' ' + height} aria-hidden="true">
      <path d={d} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={X(vals.length - 1)} cy={Y(vals[vals.length - 1])} r="2.2" fill={color} />
    </svg>
  );
};
