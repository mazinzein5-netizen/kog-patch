import React,{useState,useEffect,useRef} from 'react';
import {Shell,go,useApp} from './App';
import {api} from './api';
import {IconCamera} from './icons';

const ALLERGENS=['Cereals containing gluten','Crustaceans','Egg','Fish','Peanuts','Soybeans','Milk','Nuts','Celery','Mustard','Sesame','Sulphites','Lupin','Molluscs'];
const inp='w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ko-gold/50 mb-2';
const lbl='kog-lbl text-[11px] font-bold mb-1 block';
const btn=(c:string)=>'w-full py-3 rounded-xl font-bold mb-2 '+(c==='primary'?'text-white':'');
const downscale=(file:File):Promise<string>=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');const s=Math.min(1,900/Math.max(im.width,im.height));c.width=im.width*s;c.height=im.height*s;c.getContext('2d')!.drawImage(im,0,0,c.width,c.height);ok(c.toDataURL('image/jpeg',0.7))};im.onerror=no;im.src=String(r.result)};r.onerror=no;r.readAsDataURL(file)});
const FilePick=({label,onPick,value}:{label:string;onPick:(d:string)=>void;value?:string})=>(<label className="block mb-2"><span className={lbl}>{label}</span><input type="file" accept="image/*" capture="environment" onChange={async(e:any)=>{const f=e.target.files&&e.target.files[0];if(f)onPick(await downscale(f))}} className="w-full text-[12px]"/>{!!value&&<img src={value} alt="" className="mt-2 w-24 h-24 object-cover rounded-lg border border-black/10"/>}</label>);

/* ------------------------------------------------------------------ setup checklist */
export const SetupPage=()=>{
 const{refreshKey}=useApp();const[c,setC]=useState<any>(null);
 useEffect(()=>{api.setup.checklist().then(setC).catch(()=>{})},[refreshKey]);
 const routes:any={business:'/setup/business',vat:'/setup/business',food_reg:'/setup/business',halal:'/setup/certificates',organic:'/setup/certificates',butcher:'/setup/certificates',haccp:'/setup/certificates',insurance:'/setup/certificates',suppliers:'/setup/suppliers',inventory:'/setup/inventory'};
 const pct=c&&c.total?Math.round((c.done/c.total)*100):0;
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Store setup</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Everything the shop must have in place before it sells online.</p>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <div className="flex justify-between items-baseline"><b className="text-sm">Ready {pct}%</b><span className="text-[11px] text-gray-600">{c?c.done+' of '+c.total:'loading'}</span></div>
   <div className="h-2 rounded-full bg-black/10 mt-2 overflow-hidden"><div className="h-2 rounded-full" style={{width:pct+'%',background:pct===100?'#0B6B4F':'#2A00D6'}}/></div>
   {!!c&&!!c.inventory&&c.inventory.missingAllergens>0&&<div className="text-[11px] mt-2" style={{color:'#8a4b06'}}>{c.inventory.missingAllergens} product(s) still need allergen information.</div>}
  </div>
  <button onClick={()=>go('/setup/services')} className="card-white w-full p-4 mb-2 text-left shadow-lg" data-reveal><b className="text-sm block">Your plan - four weeks free</b><span className="text-[11px] text-gray-600">Essential, Growth or Complete: setup and monthly prices, support, add-ons. Nothing is charged during the trial.</span></button>
  {(c&&c.items||[]).map((i:any)=>(<button key={i.key} onClick={()=>go(routes[i.key]||'/setup')} className="card-white w-full p-4 mb-2 text-left shadow-lg" data-reveal>
   <div className="flex items-center gap-2"><span className="w-5 h-5 rounded-full text-[11px] font-bold flex items-center justify-center" style={{background:i.done?'#0B6B4F':'rgba(17,24,39,.18)',color:'#F9F7F2'}}>{i.done?'✓':''}</span>
    <b className="text-sm flex-1">{i.label}</b><span className="text-[11px] text-gray-600">{i.done?'done':'to do'}</span></div>
   <div className="text-[11px] text-gray-600 mt-1">{i.why}</div></button>))}
 </div></Shell>);};

/* ------------------------------------------------------------------ business + VAT */
export const BusinessPage=()=>{
 const[b,setB]=useState<any>({});const[saved,setSaved]=useState(false);
 useEffect(()=>{api.setup.business().then((r:any)=>setB(r.business||{})).catch(()=>{})},[]);
 const set=(k:string)=>(e:any)=>setB((x:any)=>({...x,[k]:e.target.value}));
 const save=async()=>{await api.setup.saveBusiness(b).catch(()=>{});setSaved(true);setTimeout(()=>setSaved(false),2000)};
 return(<Shell back="/setup"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-3" data-reveal>Business and VAT</h1>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <span className={lbl}>Registered company name</span><input value={b.legal_name||''} onChange={set('legal_name')} aria-label="Hive Health Ecosystem Ltd" placeholder="Hive Health Ecosystem Ltd" className={inp}/>
   <span className={lbl}>Trading name(s)</span><input value={b.trading_name||''} onChange={set('trading_name')} aria-label="Kingdom Organics" placeholder="Kingdom Organics" className={inp}/>
   <span className={lbl}>CRO company number</span><input value={b.reg_no||''} onChange={set('reg_no')} aria-label="824008" placeholder="824008" className={inp}/>
   <span className={lbl}>VAT number</span><input value={b.vat_no||''} onChange={set('vat_no')} aria-label="IE1234567T" placeholder="IE1234567T" className={inp}/>
   <span className={lbl}>Registered address</span><input value={b.address||''} onChange={set('address')} aria-label="20 Harcourt Street, Dublin 2, D02 H364" placeholder="20 Harcourt Street, Dublin 2, D02 H364" className={inp}/>
   <span className={lbl}>Food business registration number</span><input value={b.food_reg||''} onChange={set('food_reg')} aria-label="Issued by the HSE when you register the food business" placeholder="Issued by the HSE when you register the food business" className={inp}/>
   <span className={lbl}>Contact email</span><input value={b.email||''} onChange={set('email')} aria-label="hello@kingdomorganics.ie" placeholder="hello@kingdomorganics.ie" className={inp}/>
   <span className={lbl}>Phone</span><input value={b.phone||''} onChange={set('phone')} aria-label="087 123 4567" placeholder="087 123 4567" className={inp}/>
   <button onClick={save} className="w-full py-3 rounded-xl font-bold text-white" style={{background:'#2A00D6'}}>Save</button>
   {saved&&<div className="text-[11px] mt-2" style={{color:'#0B6B4F'}}>Saved ✓</div>}
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-1">How to get a VAT number (Ireland)</b>
   <div className="text-[12px] text-gray-700 leading-relaxed">
    1. Register for VAT with Revenue — through <b>ROS</b> (ros.ie) if you already have a Tax Reference Number, or <b>myAccount</b> (myaccount.revenue.ie) if you are an individual.<br/>
    2. Choose <b>Register for VAT</b>, give your business details and the nature of the trade, and submit.<br/>
    3. Revenue issues a VAT number in the format <b>IE</b> followed by 7 digits and a letter (for example IE1234567T). It normally arrives within a few working days.<br/>
    4. Enter that number above. It is then shown on your invoices and on the Legal screen.<br/><br/>
    <b>When you must register:</b> if your turnover passes the services threshold (€37,500) or the goods threshold (€75,000) in any 12 months, if you sell goods online to other EU countries above the €10,000 distance-sales threshold, or if you buy from abroad. Most food is zero-rated, but delivery, non-food goods and catering are not — ask your accountant which applies to you.
   </div>
  </div>
 </div></Shell>);};

/* ------------------------------------------------------------------ certificates */
export const CertificatesPage=()=>{
 const{refreshKey}=useApp();const[c,setC]=useState<any>(null);const[f,setF]=useState<any>({kind:'halal',issuer:'',ref:'',valid_from:'',valid_to:'',image:''});const[busy,setBusy]=useState(false);
 const load=()=>api.certificates.list().then(setC).catch(()=>{});
 useEffect(()=>{load()},[refreshKey]);
 const save=async()=>{setBusy(true);try{await api.certificates.add(f);setF({kind:'halal',issuer:'',ref:'',valid_from:'',valid_to:'',image:''});await load()}catch(e){}setBusy(false)};
 const soon=(d:string)=>{if(!d)return false;const t=new Date(d).getTime();return t-Date.now()<1000*60*60*24*60};
 return(<Shell back="/setup"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Certificates</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Halal, organic, butcher, food safety and insurance — kept where the shop can find them.</p>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <span className={lbl}>Type</span>
   <select value={f.kind} onChange={(e:any)=>setF({...f,kind:e.target.value})} className={inp}>
    {['halal','organic','fsai_food_business','insurance','butcher','meat_traceability','haccp','garda_vetting'].map(k=>(<option key={k} value={k}>{k.replace(/_/g,' ')}</option>))}
   </select>
   <span className={lbl}>Issuer / certifying body</span><input value={f.issuer} onChange={(e:any)=>setF({...f,issuer:e.target.value})} placeholder="e.g. Halal Food Authority, Organic Trust, HSE" className={inp}/>
   <span className={lbl}>Certificate reference</span><input value={f.ref} onChange={(e:any)=>setF({...f,ref:e.target.value})} className={inp}/>
   <div className="flex gap-2"><div className="flex-1"><span className={lbl}>Valid from</span><input type="date" value={f.valid_from} onChange={(e:any)=>setF({...f,valid_from:e.target.value})} className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Valid to</span><input type="date" value={f.valid_to} onChange={(e:any)=>setF({...f,valid_to:e.target.value})} className={inp}/></div></div>
   <FilePick label="Photograph or scan the certificate" value={f.image} onPick={(d)=>setF({...f,image:d})}/>
   <button onClick={save} disabled={busy} className="w-full py-3 rounded-xl font-bold text-white" style={{background:busy?'#6f6f92':'#2A00D6'}}>{busy?'Uploading…':'Save certificate'}</button>
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">On file</b>
   {!(c&&c.certificates&&c.certificates.length)&&<div className="text-[12px] text-gray-600">Nothing uploaded yet.</div>}
   {(c&&c.certificates||[]).map((x:any)=>(<div key={x.id} className="py-2 border-b last:border-0 flex items-center gap-2">
    <span className="flex-1"><b className="text-sm block capitalize">{x.kind.replace(/_/g,' ')}</b><span className="text-[11px] text-gray-600">{x.issuer} {x.ref?'· '+x.ref:''} {x.valid_to?('· until '+x.valid_to):''}</span></span>
    {soon(x.valid_to)&&<span className="text-[10px] font-bold" style={{color:'#8a4b06'}}>renew</span>}
    <button onClick={async()=>{await api.certificates.remove(x.id).catch(()=>{});load()}} className="text-[11px] text-gray-600">Delete</button></div>))}
  </div>
 </div></Shell>);};

/* ------------------------------------------------------------------ suppliers / distributors */
export const SuppliersPage=()=>{
 const{refreshKey}=useApp();const[list,setList]=useState<any[]>([]);const[f,setF]=useState<any>({name:'',contact:'',email:'',phone:'',account:'',terms:'',categories:'',days:'',notes:''});const[busy,setBusy]=useState(false);
 const load=()=>api.suppliers.list().then((r:any)=>setList(r.suppliers||[])).catch(()=>{});
 useEffect(()=>{load()},[refreshKey]);
 const save=async()=>{if(!f.name.trim())return;setBusy(true);try{await api.suppliers.add(f);setF({name:'',contact:'',email:'',phone:'',account:'',terms:'',categories:'',days:'',notes:''});await load()}catch(e){}setBusy(false)};
 return(<Shell back="/setup"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Distributors</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Who you buy from, their terms and their delivery days.</p>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <span className={lbl}>Name</span><input value={f.name} onChange={(e:any)=>setF({...f,name:e.target.value})} placeholder="Green Valley Organics Ltd" className={inp}/>
   <span className={lbl}>Contact person</span><input value={f.contact} onChange={(e:any)=>setF({...f,contact:e.target.value})} className={inp}/>
   <div className="flex gap-2"><div className="flex-1"><span className={lbl}>Email</span><input value={f.email} onChange={(e:any)=>setF({...f,email:e.target.value})} inputMode="email" className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Phone</span><input value={f.phone} onChange={(e:any)=>setF({...f,phone:e.target.value})} inputMode="tel" className={inp}/></div></div>
   <div className="flex gap-2"><div className="flex-1"><span className={lbl}>Account number</span><input value={f.account} onChange={(e:any)=>setF({...f,account:e.target.value})} className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Payment terms</span><input value={f.terms} onChange={(e:any)=>setF({...f,terms:e.target.value})} placeholder="30 days" className={inp}/></div></div>
   <span className={lbl}>What they supply</span><input value={f.categories} onChange={(e:any)=>setF({...f,categories:e.target.value})} placeholder="meat, dairy, spices" className={inp}/>
   <span className={lbl}>Delivery days</span><input value={f.days} onChange={(e:any)=>setF({...f,days:e.target.value})} placeholder="Tue, Fri" className={inp}/>
   <span className={lbl}>Notes</span><input value={f.notes} onChange={(e:any)=>setF({...f,notes:e.target.value})} className={inp}/>
   <button onClick={save} disabled={busy} className="w-full py-3 rounded-xl font-bold text-white" style={{background:busy?'#6f6f92':'#2A00D6'}}>{busy?'Saving…':'Add distributor'}</button>
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">On file ({list.length})</b>
   {!list.length&&<div className="text-[12px] text-gray-600">No distributors yet.</div>}
   {list.map((s:any)=>(<div key={s.id} className="py-2 border-b last:border-0"><b className="text-sm block">{s.name}</b>
    <span className="text-[11px] text-gray-600">{[s.contact,s.phone,s.email,s.terms,s.days,s.categories].filter(Boolean).join(' · ')}</span></div>))}
  </div>
 </div></Shell>);};

/* ------------------------------------------------------------------ inventory editor */
const KoSwitch=({on,onChange,rec}:{on:boolean;onChange:(v:boolean)=>void;rec:boolean})=>(<button type="button" role="switch" aria-checked={on} onClick={()=>onChange(!on)} className="relative w-12 h-7 rounded-full shrink-0" style={{background:on?'#2A00D6':'rgba(20,37,31,.22)',transition:rec?'none':'background .3s cubic-bezier(.4,0,.2,1)'}}><span aria-hidden="true" className="absolute top-1 w-5 h-5 rounded-full bg-white shadow border border-black/10" style={{left:on?22:4,transition:rec?'none':'left .3s cubic-bezier(.4,0,.2,1)'}}/></button>);

const InventoryScanWidget=()=>{
 const rec=typeof window!=='undefined'&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const fileRef=useRef<HTMLInputElement|null>(null);
 const[busy,setBusy]=useState(false);const[msg,setMsg]=useState('');
 const[flags,setFlags]=useState<{[k:string]:boolean}>(()=>{try{const o=JSON.parse(localStorage.getItem('kog-inv-flags')||'{}');return{organic:!!o.organic,allergen:!!o.allergen,delivery:!!o.delivery,pickup:!!o.pickup}}catch(e){return{organic:false,allergen:false,delivery:false,pickup:false}}});
 const set=(k:string)=>(v:boolean)=>{const n:any={...flags};n[k]=v;setFlags(n);try{localStorage.setItem('kog-inv-flags',JSON.stringify(n))}catch(e){}};
 const pick=(cap:boolean)=>{const el=fileRef.current;if(!el)return;el.setAttribute('accept',cap?'image/*':'image/*,application/pdf');if(cap){el.setAttribute('capture','environment')}else{el.removeAttribute('capture')}el.click()};
 const onFiles=(e:any)=>{const f:any[]=Array.from(e.target.files||[]);if(!f.length)return;setBusy(true);setMsg('Sent - an agent will organize your inventory.');setTimeout(()=>{setBusy(false);setMsg('')},2500)};
 const ROWS:[string,string][]=[['Organic','organic'],['Milk or Peanut Allergen','allergen'],['Delivery','delivery'],['Pick-Up','pickup']];
 return(<div data-reveal className="glass rounded-2xl p-4 mb-3 text-white">
  <input ref={fileRef} type="file" multiple className="hidden" onChange={onFiles}/>
  <div className="text-center font-display text-base font-bold tracking-wide mb-3">SCAN OR UPLOAD INVENTORY</div>
  <button type="button" disabled={busy} onClick={()=>pick(true)} className="w-full rounded-2xl border border-white/20 bg-white/10 hover:bg-white/15 py-6 mb-2 flex flex-col items-center gap-2">
   <IconCamera className="w-10 h-10"/>
   <span className="text-sm font-bold">{busy?'Working...':'Tap to photograph'}</span>
   <span className="text-[11px] text-white/75">Camera, screenshot or file - PDF included</span>
  </button>
  <button type="button" disabled={busy} onClick={()=>pick(false)} className="w-full rounded-xl bg-white/10 hover:bg-white/15 text-[12px] font-semibold py-2.5 mb-3">Choose a file or screenshot</button>
  <div className="text-[11px] text-white/75 text-center mb-3">An agent will organize your inventory</div>
  {msg&&<div className="text-[11px] bg-black/25 rounded-xl px-3 py-2 mb-3 text-center">{msg}</div>}
  {ROWS.map(([label,key])=>(<div key={key} className="flex items-center justify-between gap-3 py-1.5"><span className="text-[12px] font-semibold">{label}</span><KoSwitch on={!!flags[key]} onChange={set(key)} rec={rec}/></div>))}
 </div>);
};

export const InventoryAdminPage=()=>{
 const{refreshKey}=useApp();const[list,setList]=useState<any[]>([]);const[open,setOpen]=useState(false);
 const[f,setF]=useState<any>({id:'',name:'',price:'',unit:'each',stock:'',sku:'',allergens:[],ingredients:'',origin:'',supplier:'',image:''});const[busy,setBusy]=useState(false);
 const load=()=>api.inventory.list().then((r:any)=>setList(Array.isArray(r)?r:(r.items||[]))).catch(()=>{});
 useEffect(()=>{load()},[refreshKey]);
 const tick=(a:string)=>setF((x:any)=>({...x,allergens:x.allergens.includes(a)?x.allergens.filter((y:string)=>y!==a):[...x.allergens,a]}));
 const edit=(p:any)=>{setF({id:p.id,name:p.name||'',price:p.price||'',unit:p.unit||'each',stock:p.stock||'',sku:p.sku||'',allergens:p.allergens||[],ingredients:p.ingredients||'',origin:p.origin||'',supplier:p.supplier||'',image:p.image||''});setOpen(true)};
 const save=async()=>{if(!f.name.trim())return;setBusy(true);try{await api.inventory.save(f);setOpen(false);setF({id:'',name:'',price:'',unit:'each',stock:'',sku:'',allergens:[],ingredients:'',origin:'',supplier:'',image:''});await load()}catch(e){}setBusy(false)};
 return(<Shell back="/setup"><div className="px-4 pt-3">
   <InventoryScanWidget/>
  <div className="flex items-center justify-between mb-3"><h1 className="font-display text-white text-2xl font-bold">Stock</h1>
   <button onClick={()=>setOpen(!open)} className="px-3 py-2 rounded-xl text-[12px] font-bold" style={{background:'#E8960F',color:'#1a1206'}}>{open?'Close':'+ Add product'}</button></div>
  {open&&<div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <span className={lbl}>Product name</span><input value={f.name} onChange={(e:any)=>setF({...f,name:e.target.value})} className={inp}/>
   <div className="flex gap-2"><div className="flex-1"><span className={lbl}>Price €</span><input value={f.price} onChange={(e:any)=>setF({...f,price:e.target.value})} inputMode="decimal" className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Unit</span><input value={f.unit} onChange={(e:any)=>setF({...f,unit:e.target.value})} className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Stock</span><input value={f.stock} onChange={(e:any)=>setF({...f,stock:e.target.value})} inputMode="numeric" className={inp}/></div></div>
   <span className={lbl}>Allergens (EU 14)</span>
   <div className="flex flex-wrap gap-1.5 mb-2">{ALLERGENS.map(a=>(<button key={a} onClick={()=>tick(a)} className="px-2.5 py-1 rounded-full text-[10px] font-semibold" style={f.allergens.includes(a)?{background:'#2A00D6',color:'#F9F7F2'}:{background:'rgba(0,1,87,.07)',color:'#1b1146'}}>{a}</button>))}</div>
   <span className={lbl}>Ingredients</span><input value={f.ingredients} onChange={(e:any)=>setF({...f,ingredients:e.target.value})} className={inp}/>
   <span className={lbl}>Country of origin</span><input value={f.origin} onChange={(e:any)=>setF({...f,origin:e.target.value})} className={inp}/>
   <span className={lbl}>Supplier</span><input value={f.supplier} onChange={(e:any)=>setF({...f,supplier:e.target.value})} className={inp}/>
   <FilePick label="Product photo" value={f.image} onPick={(d)=>setF({...f,image:d})}/>
   <button onClick={save} disabled={busy} className="w-full py-3 rounded-xl font-bold text-white" style={{background:busy?'#6f6f92':'#2A00D6'}}>{busy?'Saving…':(f.id?'Update product':'Add product')}</button>
  </div>}
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">In stock ({list.length})</b>
   {!list.length&&<div className="text-[12px] text-gray-600">No products yet — add your first item.</div>}
   {list.map((p:any)=>{const miss=!p.allergens||!p.allergens.length;return(<div key={p.id} className="py-2 border-b last:border-0 flex items-center gap-2">
    <span className="flex-1"><b className="text-sm block">{p.name}</b><span className="text-[11px] text-gray-600">€{Number(p.price||0).toFixed(2)} · {p.stock||0} {p.unit||''} {p.allergens&&p.allergens.length?('· '+p.allergens.join(', ')):''}</span>
     {miss&&<span className="text-[10px] font-bold" style={{color:'#8a4b06'}}>allergens missing</span>}</span>
    <button onClick={()=>edit(p)} className="text-[11px] font-semibold" style={{color:'#2A00D6'}}>Edit</button></div>)})}
  </div>
 </div></Shell>);};

/* ---------------------------------------------------------------- plans, trial, purchase */
export const ServicesPage=()=>{
 const{refreshKey}=useApp();const[p,setP]=useState<any>(null);const[st,setSt]=useState<any>({});
 const[cycle,setCycle]=useState('monthly');const[busy,setBusy]=useState('');const[msg,setMsg]=useState('');
 const[f,setF]=useState({name:'',business:'',email:'',phone:'',tier:'growth',notes:''});
 useEffect(()=>{api.services.pricing().then(setP).catch(()=>{});api.services.status().then(setSt).catch(()=>{})},[refreshKey]);
 const money=(n:any)=>'€'+Number(n||0).toLocaleString();
 const trial=async(tier:string)=>{setBusy(tier);try{const r:any=await api.services.startTrial({tier,cycle});setMsg('Free trial started — '+(r.days||28)+' days on the '+tier+' plan. No payment taken.');setSt({...st,plan:tier,inTrial:true,daysLeft:r.days||28})}catch(e){setMsg('Could not start the trial — try again.')}setBusy('')};
 const enquire=async()=>{if(!f.name.trim()||!f.email.trim()){setMsg('Name and email, please.');return}setBusy('enq');try{await api.services.enquire(f);setMsg('Thank you — we will come back to you within one working day.')}catch(e){setMsg('Could not send it — try again.')}setBusy('')};
 return(<Shell back="/setup"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Plan and billing</h1>
  <p className="text-white/70 text-xs mb-3" data-reveal>Your app, your shop, your marketing — priced plainly.</p>
  <div className="rounded-2xl px-4 py-3 mb-3" style={{background:'linear-gradient(135deg,#E8C454,#E8960F)',color:'#1a1206'}} data-reveal>
   <b className="text-sm block">Four weeks free</b>
   <span className="text-[12px]">No setup fee, no monthly fee, no card taken during the trial. Cancel inside the trial and you pay nothing.</span>
   {!!st&&!!st.inTrial&&<div className="text-[12px] font-bold mt-1">Trial running · {st.daysLeft} days left on {st.plan}</div>}
  </div>
  <div className="glass rounded-full p-1 flex mb-3" data-reveal>{[['monthly','Monthly'],['annual','Annual (2 months free)']].map(([k,lab])=>(<button key={k} onClick={()=>setCycle(k)} className={"flex-1 py-2 rounded-full text-[12px] font-semibold "+(cycle===k?"bg-white text-ko-forest":"text-white/70")}>{lab}</button>))}</div>
  {!!msg&&<div className="rounded-xl px-3 py-2 mb-3 text-[12px]" style={{background:'rgba(232,196,84,.16)',border:'1px solid rgba(232,196,84,.6)',color:'#E8C454'}} data-reveal>{msg}</div>}
  {(p&&p.tiers||[]).map((t:any)=>(<div key={t.id} className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <div className="flex items-baseline justify-between"><b className="font-display text-lg">{t.name}</b><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{background:'rgba(42,0,214,.10)',color:'#1b1146'}}>{t.tag}</span></div>
   <div className="text-[11px] text-gray-600 mb-2">{t.for}</div>
   <div className="flex items-end gap-2 mb-2"><span className="font-display text-2xl font-bold">{money(cycle==='annual'?t.annual:t.monthly)}</span><span className="text-[11px] text-gray-600 mb-1">/ {cycle==='annual'?'year':'month'}</span></div>
   <div className="text-[11px] text-gray-700 mb-2">Setup {money(t.setup)} · waived during the trial</div>
   <div className="text-[12px] text-gray-700 mb-1"><b>Included</b></div>
   <ul className="list-disc pl-4 mb-2">{(t.includes||[]).map((i:string)=>(<li key={i} className="text-[11px] text-gray-700">{i}</li>))}</ul>
   <div className="text-[11px] mb-2"><b>Support:</b> {t.support}</div>
   <button onClick={()=>trial(t.id)} disabled={busy===t.id} className="w-full py-3 rounded-xl font-bold text-white" style={{background:busy===t.id?'#6f6f92':'#2A00D6'}}>{busy===t.id?'Starting…':'Start 4 weeks free'}</button>
  </div>))}
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">Add-ons whenever you need them</b>
   {(p&&p.addons||[]).map((a:any)=>(<div key={a.name} className="flex justify-between py-1.5 border-b last:border-0 text-[11px]"><span className="flex-1 pr-2">{a.name}</span><b className="text-right">{a.price}</b></div>))}
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">Ask for a quote or a callback</b>
   <input value={f.name} onChange={(e:any)=>setF({...f,name:e.target.value})} placeholder="Your name" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
   <input value={f.business} onChange={(e:any)=>setF({...f,business:e.target.value})} placeholder="Shop name" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
   <input value={f.email} onChange={(e:any)=>setF({...f,email:e.target.value})} placeholder="Email" inputMode="email" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
   <input value={f.phone} onChange={(e:any)=>setF({...f,phone:e.target.value})} placeholder="Phone" inputMode="tel" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
   <select value={f.tier} onChange={(e:any)=>setF({...f,tier:e.target.value})} className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2">
    <option value="essential">Essential</option><option value="growth">Growth</option><option value="complete">Complete</option><option value="addon">Add-ons only</option></select>
   <textarea value={f.notes} onChange={(e:any)=>setF({...f,notes:e.target.value})} placeholder="What do you need?" rows={3} className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2"/>
   <button onClick={enquire} disabled={busy==='enq'} className="w-full py-3 rounded-xl font-bold" style={{background:'#E8960F',color:'#1a1206'}}>{busy==='enq'?'Sending…':'Send enquiry'}</button>
  </div>
 </div></Shell>);};

/* ---------------------------------------------------------------- deals manager */
export const DealsAdminPage=()=>{
 const{refreshKey}=useApp();const[list,setList]=useState<any[]>([]);const[opps,setOpps]=useState<any>(null);const[advice,setAdvice]=useState<any>(null);
 const[f,setF]=useState<any>({title:'',kind:'percent',percent:10,retail:'',cost:'',ends:'',note:''});const[busy,setBusy]=useState('');const[msg,setMsg]=useState('');
 const load=()=>{api.dealPlans.list().then((r:any)=>setList(r.deals||[])).catch(()=>{});api.dealOpps().then(setOpps).catch(()=>{})};
 useEffect(()=>{load()},[refreshKey]);
 const save=async()=>{if(!f.title.trim()){setMsg('Give the deal a name.');return}setBusy('save');try{await api.dealPlans.save(f);setF({title:'',kind:'percent',percent:10,retail:'',cost:'',ends:'',note:''});setMsg('Deal saved.');await load()}catch(e){setMsg('Could not save it.')}setBusy('')};
 const del=async(id:string)=>{setBusy(id);try{await api.dealPlans.remove(id);await load()}catch(e){}setBusy('')};
 const ask=async()=>{setBusy('ai');try{const r:any=await api.dealAdvice();setAdvice(r)}catch(e){}setBusy('')};
 const money=(n:any)=>'EUR '+Number(n||0).toFixed(2);
 return(<Shell back="/setup"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Deals</h1>
  <p className="text-white/70 text-xs mb-3" data-reveal>Create a deal, see the margin it leaves, and let the AI point at what to promote.</p>
  {!!msg&&<div className="rounded-xl px-3 py-2 mb-3 text-[12px]" style={{background:'rgba(232,196,84,.16)',border:'1px solid rgba(232,196,84,.6)',color:'#E8C454'}}>{msg}</div>}
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">Create a deal</b>
   <span className={lbl}>What is it called</span><input value={f.title} onChange={(e:any)=>setF({...f,title:e.target.value})} placeholder="15% off spices and oils" className={inp}/>
   <div className="flex gap-2"><div className="flex-1"><span className={lbl}>Discount %</span><input value={f.percent} onChange={(e:any)=>setF({...f,percent:e.target.value})} inputMode="numeric" className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Retail EUR</span><input value={f.retail} onChange={(e:any)=>setF({...f,retail:e.target.value})} inputMode="decimal" className={inp}/></div>
    <div className="flex-1"><span className={lbl}>Cost EUR</span><input value={f.cost} onChange={(e:any)=>setF({...f,cost:e.target.value})} inputMode="decimal" className={inp}/></div></div>
   <span className={lbl}>Ends</span><input value={f.ends} onChange={(e:any)=>setF({...f,ends:e.target.value})} placeholder="Ends Friday" className={inp}/>
   <span className={lbl}>Note</span><input value={f.note} onChange={(e:any)=>setF({...f,note:e.target.value})} className={inp}/>
   <button onClick={save} disabled={busy==='save'} className="w-full py-3 rounded-xl font-bold" style={{background:'#E8960F',color:'#1a1206'}}>{busy==='save'?'Saving…':'Create deal'}</button>
  </div>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">Live deals ({list.length})</b>
   {!list.length&&<div className="text-[12px] text-gray-700">No deals yet — create one above.</div>}
   {list.map((d:any)=>(<div key={d.id} className="py-2 border-b last:border-0">
    <div className="flex items-center gap-2"><b className="text-sm flex-1">{d.title}</b>
     <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={d.marginPct>=20?{background:'rgba(11,107,79,.12)',color:'#0B6B4F'}:{background:'rgba(232,150,15,.18)',color:'#7a3f05'}}>margin {d.marginPct}%</span>
     <button onClick={()=>del(d.id)} disabled={busy===d.id} className="text-[11px] font-semibold" style={{color:'#8a2d1f'}}>{busy===d.id?'…':'Delete'}</button></div>
    <div className="text-[11px]" style={{color:'#374151'}}>{d.ends||''} · retail {money(d.retail)} · {Number(d.percent||0)}% off · net {money(d.netRetail)} · cost {money(d.cost)}</div>
   </div>))}
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <div className="flex items-center justify-between mb-2"><b className="text-sm">AI deal chances</b>
    <button onClick={ask} disabled={busy==='ai'} className="px-3 py-1.5 rounded-lg text-[11px] font-bold text-white" style={{background:busy==='ai'?'#6f6f92':'#2A00D6'}}>{busy==='ai'?'Thinking…':'Ask the AI'}</button></div>
   {!!opps&&!!opps.advice&&<div className="rounded-xl p-3 mb-2 text-[12px]" style={{background:'rgba(0,1,87,.06)',border:'1px solid rgba(0,1,87,.2)',color:'#111827'}}>{opps.advice}</div>}
   {(opps&&opps.opportunities||[]).map((o:any)=>(<div key={o.name} className="py-2 border-b last:border-0">
    <div className="flex items-center gap-2"><b className="text-[13px] flex-1">{o.name}</b><span className="text-[10px] font-bold" style={{color:'#0B6B4F'}}>up to {Math.round(o.maxDiscount)}% off</span></div>
    <div className="text-[11px]" style={{color:'#374151'}}>{o.why}</div></div>))}
   {!(opps&&opps.opportunities&&opps.opportunities.length)&&<div className="text-[12px] text-gray-700">No margins to work with yet — confirm a supplier invoice and the chances appear here.</div>}
   {(opps&&opps.avoid||[]).map((o:any)=>(<div key={o.name} className="py-2 border-b last:border-0">
    <div className="text-[13px] font-semibold" style={{color:'#7a3f05'}}>Hold price: {o.name}</div>
    <div className="text-[11px]" style={{color:'#374151'}}>{o.why}</div></div>))}
   {!!advice&&!!advice.advice&&<div className="mt-2 rounded-xl p-3 text-[12px] whitespace-pre-line" style={{background:'rgba(42,0,214,.07)',border:'1px solid rgba(42,0,214,.25)',color:'#1b1146'}}>{advice.advice}</div>}
  </div>
 </div></Shell>);};

/* ---------------------------------------------------------------- guest codes (superuser) */
export const GuestCodesPage=()=>{
 const{refreshKey}=useApp();const[list,setList]=useState<any[]>([]);const[weeks,setWeeks]=useState(3);const[label,setLabel]=useState('Guest demo');const[msg,setMsg]=useState('');const[busy,setBusy]=useState(false);
 const load=()=>api.guests.list().then((r:any)=>{if(r&&r.ok===false){setMsg('Superuser account only.');return}setList(r.codes||[])}).catch(()=>setMsg('Superuser account only.'));
 useEffect(()=>{load()},[refreshKey]);
 const mint=async()=>{setBusy(true);try{const r:any=await api.guests.create(weeks,label);setMsg(r&&r.code?('New code: '+r.code+' — valid '+r.weeks+' weeks'):((r&&r.error)||'Could not create')) ;await load()}catch(e){setMsg('Could not create the code.')}setBusy(false)};
 return(<Shell back="/setup"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Guest codes</h1>
  <p className="text-white/70 text-xs mb-3" data-reveal>Temporary access for a prospect, an inspector or a supplier. Two to four weeks, then it stops.</p>
  {!!msg&&<div className="rounded-xl px-3 py-2 mb-3 text-[12px] font-semibold" style={{background:'rgba(232,196,84,.16)',border:'1px solid rgba(232,196,84,.6)',color:'#E8C454'}}>{msg}</div>}
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <span className={lbl}>Who is it for</span><input value={label} onChange={(e:any)=>setLabel(e.target.value)} className={inp}/>
   <span className={lbl}>How long</span>
   <div className="flex gap-2 mb-2">{[2,3,4].map(w=>(<button key={w} onClick={()=>setWeeks(w)} className="px-3 py-1.5 rounded-full text-[12px] font-semibold" style={weeks===w?{background:'#2A00D6',color:'#F9F7F2'}:{background:'rgba(0,1,87,.07)',color:'#1b1146'}}>{w} weeks</button>))}</div>
   <button onClick={mint} disabled={busy} className="w-full py-3 rounded-xl font-bold text-white" style={{background:busy?'#6f6f92':'#2A00D6'}}>{busy?'Creating…':'Create guest code'}</button>
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-2">Codes ({list.length})</b>
   {!list.length&&<div className="text-[12px] text-gray-700">No codes yet.</div>}
   {list.map((c:any)=>(<div key={c.code} className="py-2 border-b last:border-0 flex items-center gap-2">
    <span className="flex-1"><b className="text-sm block" style={{letterSpacing:1}}>{c.code}</b>
     <span className="text-[11px]" style={{color:'#374151'}}>{c.label} · {c.weeks} weeks · {c.live?(c.daysLeft+' days left'):'expired or revoked'}</span></span>
    {c.live&&<button onClick={async()=>{await api.guests.revoke(c.code).catch(()=>{});load()}} className="text-[11px] font-semibold" style={{color:'#8a2d1f'}}>Revoke</button>}
   </div>))}
  </div>
 </div></Shell>);};
