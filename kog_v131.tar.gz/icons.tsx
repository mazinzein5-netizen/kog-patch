// Lucide-style line icons inlined as SVG (no dependency, stroke at currentColor).
const S = ({ children, className = 'w-4 h-4', strokeWidth = 2.25 }: any) => (
  <svg viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth={strokeWidth} strokeLinecap='round' strokeLinejoin='round' className={className} aria-hidden='true'>{children}</svg>
);

export const IconSearch = ({ className }: any) => <S className={className}><circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/></S>;
export const IconStore = ({ className }: any) => <S className={className}><path d='M3 9l1.5-5h15L21 9'/><path d='M3 9v11a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V9'/><path d='M3 9a3 3 0 0 0 6 0a3 3 0 0 0 6 0a3 3 0 0 0 6 0'/><path d='M9 21v-6h6v6'/></S>;
export const IconCart = ({ className }: any) => <S className={className}><circle cx='8' cy='21' r='1'/><circle cx='19' cy='21' r='1'/><path d='M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12'/></S>;
export const IconScooter = ({ className }: any) => <S className={className}><circle cx='5.5' cy='17.5' r='3.5'/><circle cx='18.5' cy='17.5' r='3.5'/><circle cx='15' cy='5' r='1'/><path d='M15 6h3'/><path d='m5 7 4 3 5 2 2.5 6'/></S>;
export const IconTruck = ({ className }: any) => <S className={className}><path d='M14 17H5V6h11v11Z'/><path d='M14 9h4l3 3v5h-3'/><circle cx='8' cy='17' r='2'/><circle cx='17' cy='17' r='2'/></S>;
export const IconLeaf = ({ className }: any) => <S className={className}><path d='M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z'/><path d='M2 21c0-3 1.85-5.36 5.08-6'/></S>;
export const IconPackage = ({ className }: any) => <S className={className}><path d='m7.5 4.27 9 5.15'/><path d='M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z'/><path d='M3.3 7 12 12l8.7-5'/><path d='M12 22V12'/></S>;
export const IconUser = ({ className }: any) => <S className={className}><path d='M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/></S>;
export const IconSettings = ({ className }: any) => <S className={className}><line x1='21' y1='4' x2='14' y2='4'/><line x1='10' y1='4' x2='3' y2='4'/><line x1='21' y1='12' x2='12' y2='12'/><line x1='8' y1='12' x2='3' y2='12'/><line x1='21' y1='20' x2='16' y2='20'/><line x1='12' y1='20' x2='3' y2='20'/><line x1='14' y1='2' x2='14' y2='6'/><line x1='8' y1='10' x2='8' y2='14'/><line x1='16' y1='18' x2='16' y2='22'/></S>;
export const IconHeart = ({ className }: any) => <S className={className}><path d='M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z'/></S>;
export const IconSend = ({ className }: any) => <S className={className}><path d='M22 2 11 13'/><path d='M22 2 15 22l-4-9-9-4Z'/></S>;
export const IconChevronRight = ({ className }: any) => <S className={className}><path d='m9 18 6-6-6-6'/></S>;
export const IconMapPin = ({ className }: any) => <S className={className}><path d='M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z'/><circle cx='12' cy='10' r='3'/></S>;
export const IconMenu = ({ className }: any) => <S className={className}><line x1='4' y1='6' x2='20' y2='6'/><line x1='4' y1='12' x2='20' y2='12'/><line x1='4' y1='18' x2='20' y2='18'/></S>;
export const IconBot = ({ className }: any) => <S className={className}><rect x='3' y='8' width='16' height='13' rx='2'/><path d='M12 8V4M8 4h8'/><circle cx='9' cy='13' r='1'/><circle cx='15' cy='13' r='1'/></S>;
export const IconSwitch = ({ className }: any) => <S className={className}><path d='M3 12a9 9 0 0 1 15-6.7L21 8'/><path d='M21 3v5h-5'/><path d='M21 12a9 9 0 0 1-15 6.7L3 16'/><path d='M3 21v-5h5'/></S>;
export const IconChart = ({ className }: any) => <S className={className}><line x1='12' y1='20' x2='12' y2='10'/><line x1='18' y1='20' x2='18' y2='4'/><line x1='6' y1='20' x2='6' y2='16'/><line x1='2' y1='20' x2='22' y2='20'/></S>;
export const IconWallet = ({ className }: any) => <S className={className}><path d='M21 12V7H5a2 2 0 0 1 0-4h14v4'/><path d='M3 5v14a2 2 0 0 0 2 2h16v-5'/><path d='M18 12a2 2 0 0 0 0 4h4v-4Z'/></S>;

export const IconMic = ({ className }: any) => <S className={className}><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0"/><line x1="12" y1="19" x2="12" y2="22"/></S>;
export const IconByRole = ({ role, className }: any) => role==='admin' ? <IconStore className={className}/> : role==='driver' ? <IconScooter className={className}/> : <IconCart className={className}/>;
export const IconCamera = ({ className }: any) => <S className={className}><path d='M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z'/><circle cx='12' cy='13' r='4'/></S>;
