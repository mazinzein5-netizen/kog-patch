const C='aura-v127';
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match('/index.html')));return}e.respondWith(caches.open(C).then(async c=>{const h=await c.match(e.request);if(h)return h;try{const r=await fetch(e.request);if(r.ok&&new URL(e.request.url).origin===location.origin)c.put(e.request,r.clone());return r}catch(_){return h}}))});
