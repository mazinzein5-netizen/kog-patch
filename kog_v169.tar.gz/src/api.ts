// API layer — talks to the live FastAPI backend (Render) when VITE_API_URL is set
// at build time, and to deterministic mock data otherwise (offline / local dev).
const ENV_URL = (import.meta as any).env && (import.meta as any).env.VITE_API_URL;
export const API_URL: string = (ENV_URL || 'https://aura-grocery-api.onrender.com').replace(/\/+$/, '');
export const LIVE: boolean = true;

export const accountEmail = () => { try { const a = JSON.parse(localStorage.getItem('ko-account') || 'null'); return (a && a.email) || email(); } catch { return email(); } };
const superEmail = () => { try { const a = JSON.parse(localStorage.getItem('ko-account') || 'null'); return (a && a.email) || email(); } catch { return email(); } };
const email = () => { try { return localStorage.getItem('kog-email') || 'guest@kingdomorganics.ie'; } catch { return 'guest@kingdomorganics.ie'; } };

async function req<T>(path: string, opts?: RequestInit): Promise<T> {
  const r = await fetch(API_URL + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  if (!r.ok) throw new Error('API ' + r.status + ' ' + path);
  return r.json();
}
const get = <T,>(p: string) => req<T>(p);
const post = <T,>(p: string, body: unknown) => req<T>(p, { method: 'POST', body: JSON.stringify(body) });

export type ScanLine = { name: string; sku?: string; qty?: number | null; unit?: string; unitPrice?: number | null; lineTotal?: number | null };
export type ScanDoc = {
  type: string; supplier: string; invoiceNo: string; date: string | null; currency: string;
  lines: ScanLine[]; subtotal: number | null; vat: number | null; total: number | null;
  confidence: number | null; notes: string[]; model?: string;
};
export type ScanRecord = { id: string; at: number; status: 'pending' | 'confirmed'; source?: any; doc: ScanDoc };

function fileToBase64(f: File): Promise<{ name: string; mime: string; data: string }> {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve({ name: f.name, mime: f.type || 'image/jpeg', data: String(fr.result).replace(/^data:[^,]+,/, '') });
    fr.onerror = () => reject(new Error('could not read ' + f.name));
    fr.readAsDataURL(f);
  });
}

const demoDoc = (n: number): ScanDoc => ({
  type: 'distributor_invoice', supplier: 'Green Valley Organics', invoiceNo: 'GVO-' + String(Date.now()).slice(-5),
  date: new Date().toISOString().slice(0, 10), currency: 'EUR',
  lines: [
    { name: 'Organic Veg Crate', qty: 24, unit: 'crate', unitPrice: 18.5, lineTotal: 444 },
    { name: 'Free-range Eggs (tray)', qty: 12, unit: 'tray', unitPrice: 4.2, lineTotal: 50.4 },
    { name: 'Farm Milk 1L', sku: 'D1', qty: 60, unit: 'L', unitPrice: 1.55, lineTotal: 93 },
  ],
  subtotal: 587.4, vat: 0, total: 587.4, confidence: 0.62,
  notes: ['OFFLINE - sample rows, not read from your ' + n + ' image(s).'],
});
const MOCK = {
  loyalty: { points: 1250, memberId: '123456789', tier: 'GOLD', plan: 'plus', spent: 125000, orders: 42 },
  offers: [
    { t: 'Lamb Chops', price: 'Member €9.99' },
    { t: 'Basmati Rice', price: 'Member €2.49' },
    { t: 'Black Seed Oil', price: 'Member €5.99' },
  ],
  inventory: [{ id: 'P4', name: 'Bulgur Wheat', price: 2.9, stock: 120, unit: 'kg', sku: 'P4' }],
  distributors: [{ id: 'd1', supplier: 'Halal Meats Co.', date: '2026-09-05', invoices: 1, total: 420, vat: 0, lines: 1, documents: [] }],
  summary: { documents: { total: 0, pending: 0, byType: {} }, spend: { total: 0, vat: 0, invoices: 0, bySupplier: [], byMonth: [] }, inventory: { items: 0, stockValue: 0, low: [] }, pending: [], recentLedger: [] },
  /* offline finance series - clearly flagged as sample data in the UI */
  finance: (() => {
    const months = ['2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09'];
    const rev = [9800, 10420, 9960, 11380, 12140, 12960];
    const cost = [6120, 6480, 6310, 7020, 7480, 7760];
    return {
      sample: true, partialCost: false,
      months: months.map((m, i) => ({
        month: m, revenue: rev[i], cost: cost[i], profit: rev[i] - cost[i],
        margin: Math.round(((rev[i] - cost[i]) / rev[i]) * 1000) / 10, orders: 46 + i * 4,
      })),
      suppliers: [
        { supplier: 'Green Valley Organics Ltd', total: 2860, invoices: 6, vat: 286, avgInvoice: 476.7, share: 41.2, trend: [380, 420, 455, 470, 520, 615] },
        { supplier: 'Halal Meats Co.', total: 1980, invoices: 5, vat: 198, avgInvoice: 396, share: 28.5, trend: [300, 320, 340, 330, 350, 340] },
        { supplier: 'Kerry Wholesale Foods', total: 1240, invoices: 4, vat: 124, avgInvoice: 310, share: 17.9, trend: [180, 210, 240, 250, 260, 300] },
      ],
      items: [
        { name: 'Basmati Rice 25kg', samples: 3, avg: 30.8, best: { supplier: 'Green Valley Organics Ltd', unitPrice: 28.9 }, worst: { supplier: 'Kerry Wholesale Foods', unitPrice: 34.1 }, spreadPct: 18, lastQty: 12, atBest: 346.8, atWorst: 409.2 },
        { name: 'Farm Milk 1L', samples: 2, avg: 1.62, best: { supplier: 'Green Valley Organics Ltd', unitPrice: 1.55 }, worst: { supplier: 'Kerry Wholesale Foods', unitPrice: 1.7 }, spreadPct: 9.7, lastQty: 60, atBest: 93, atWorst: 102 },
      ],
      kpis: { revenue: 66660, cost: 41170, profit: 25490, margin: 38.2, orders: 306, avgOrder: 217.8, vat: 4117, stockValue: 8420, items: 24, suppliers: 3, pendingDocs: 0 },
    };
  })(),
  insights: {
    sample: true,
    actions: [
      { kind: 'price', item: 'Basmati Rice 25kg', supplier: 'Green Valley Organics Ltd', saving: 62.4, title: 'Buy Basmati Rice 25kg from Green Valley Organics Ltd', detail: 'Kerry Wholesale Foods charges €34.10 a unit, Green Valley Organics Ltd charges €28.90 — 18% cheaper. On your last quantity of 12 that is €62.40 back.' },
      { kind: 'risk', supplier: 'Green Valley Organics Ltd', saving: 0, title: 'Green Valley Organics Ltd is 41% of your buying', detail: 'One supplier carrying that much of the basket is a supply risk. Ask a second distributor to quote the same lines and split the volume.' },
      { kind: 'deal', item: 'Bulgur Wheat', saving: 0, title: 'Room for a deal on Bulgur Wheat', detail: 'Costs €1.75, sells at €2.90 — 40% margin. You can take up to 20% off and still keep 20%, with 80 in stock.' },
    ],
    deals: [{ name: 'Bulgur Wheat', price: 2.9, cost: 1.75, margin: 39.7, room: 19.7, stock: 80 }],
    totals: { identified: 62.4, vat: 4117, stockValue: 8420, margin: 38.2 },
  },
  deals: [
    { id: 'deal-turmeric', badge: 'SALE', discount: '25% OFF', title: 'Organic Turmeric', sub: 'Cold ground, premium quality', pack: '500 g pack', price: '€2.93', cta: 'Shop now', href: '/cat/spices', img: '/assets/deals/hero-1.webp', from: '#19063b', to: '#3300ff', accent: '#E8C454' },
    { id: 'deal-lamb', badge: 'SALE', discount: '20% OFF', title: 'Lamb Rack Chops', sub: 'Grass-fed and halal certified', pack: 'Per kg', price: '€3.12', cta: 'Shop meat', href: '/cat/meat', img: '/assets/deals/hero-2.webp', from: '#000157', to: '#2A00D6', accent: '#E8C454' },
    { id: 'deal-rice', badge: 'SALE', discount: '10% OFF', title: 'Basmati Rice', sub: 'Aromatic and aged', pack: '25 kg sack', price: '€2.61', cta: 'Shop rice', href: '/cat/rice', img: '/assets/deals/hero-3.webp', from: '#000157', to: '#19063b', accent: '#E8C454' },
    { id: 'deal-eggs', badge: 'MEMBERS', discount: 'DOUBLE POINTS', title: 'Free-Range Eggs', sub: 'Large brown eggs, 12 pack', pack: 'This weekend', price: '2 for €7.00', cta: 'My card', href: '/membership', img: '/assets/deals/hero-4.webp', from: '#19063b', to: '#2A00D6', accent: '#E8C454' },
  ],
  more: [
    { id: 'tile-spice', title: 'Spice Collection', sub: 'Mixed spices bundle', price: 'from €4.90', img: '/assets/deals/tile-1.webp', href: '/cat/spices' },
    { id: 'tile-cheddar', title: 'Aged Cheddar', sub: '12-month matured', price: '€5.40', img: '/assets/deals/tile-2.webp', href: '/cat/dairy' },
    { id: 'tile-tomatoes', title: 'Vine Tomatoes', sub: 'Greenhouse grown', price: '€3.90', img: '/assets/deals/tile-3.webp', href: '/cat/produce' },
    { id: 'tile-grains', title: 'Wheat & Grains', sub: 'Bulgur, groats, pearl', price: 'from €2.90', img: '/assets/deals/tile-4.webp', href: '/cat/rice' },
  ],
};

export const api = {
  /* accounts - the same email + password signs you in on any phone */
  auth: {
    login: (b: { email: string; password: string; role?: string }) =>
      LIVE ? post<any>('/api/auth/login', b) : Promise.resolve({ ok: true, email: b.email, name: b.email.split('@')[0], role: b.role || 'customer' }),
    guest: (code: string) => (LIVE ? post<any>('/api/auth/guest', { code }) : Promise.resolve({ ok: true, name: 'Guest', role: 'customer' })),
    signup: (b: { name: string; email: string; password: string; role: string }) =>
      LIVE ? post<any>('/api/auth/signup', b) : Promise.resolve({ ok: true, email: b.email, name: b.name, role: b.role }),
  },
  /* loyalty / membership — points are earned on real orders (0.01 per euro) */
  loyalty: {
    balance: () => (LIVE ? get<any>('/api/loyalty/balance?email=' + encodeURIComponent(email())) : Promise.resolve(MOCK.loyalty)),
    earn: (amt: number) =>
      LIVE
        ? get<any>('/api/loyalty/balance?email=' + encodeURIComponent(email())).then((b) => ({ ...b, earned: amt }))
        : Promise.resolve({ earned: amt, total: MOCK.loyalty.points + amt }),
    offers: () => (LIVE ? get<{ offers: any[] }>('/api/member-offers').then((r) => r.offers || []) : Promise.resolve(MOCK.offers)),
  },
  inventory: {
    save: (p: any) => (LIVE ? post<any>('/api/inventory', p) : Promise.resolve({ ok: true })),
    remove: (id: string) => (LIVE ? req<any>('/api/inventory/' + id, { method: 'DELETE' }) : Promise.resolve({ ok: true })),
    list: () => (LIVE ? get<{ items: any[] }>('/api/inventory').then((r) => r.items || []) : Promise.resolve(MOCK.inventory)),
    ingest: () => Promise.resolve({ parsed: [] }),
  },
  distributors: {
    list: () => (LIVE ? get<{ distributors: any[] }>('/api/distributors').then((r) => r.distributors || []) : Promise.resolve(MOCK.distributors)),
    detail: (id: string) => (LIVE ? get<any>('/api/distributors/' + id) : Promise.resolve(MOCK.distributors[0])),
  },
  me: {
    get: () => (LIVE ? get<any>('/api/me?email=' + encodeURIComponent(email())) : Promise.resolve({ name: 'Mazin' })),
    save: (d: any) => (LIVE ? post<any>('/api/me', { email: email(), ...d }) : Promise.resolve({ ok: true })),
    shareLocation: (loc: any) => (LIVE ? post<any>('/api/me/location', { email: email(), ...loc }) : Promise.resolve({ ok: true })),
  },
  chat: {
    history: () => Promise.resolve([]),
    send: (msg: string) =>
      LIVE ? post<{ reply: string | null }>('/api/chat', { message: msg, kb: [], name: 'there' }).then((r) => r.reply || '') : Promise.resolve(''),
  },
  /* the store-admin spine: photo / screenshot / document -> AI -> ledger */
  scan: {
    mode: () =>
      LIVE
        ? get<{ mode: string; model: string; hasKey: boolean }>('/api/scan/mode')
        : Promise.resolve({ mode: 'mock', model: 'offline', hasKey: false }),
    files: (files: File[], hint?: string) =>
      Promise.all(files.map(fileToBase64)).then((images) =>
        LIVE
          ? post<{ document: ScanRecord; ai: { mode: string; model: string } }>('/api/scan', { images, hint, by: 'admin' })
          : Promise.resolve({
              document: { id: 'doc_mock_' + Date.now(), at: Date.now(), status: 'pending' as const, doc: demoDoc(images.length) },
              ai: { mode: 'mock', model: 'offline' },
            })
      ),
  },
  /* real customer orders - this is what feeds revenue, loyalty points and the admin list */
  orders: {
    create: (o: { items: any[]; total: number; fee?: number; address?: string; payment?: string }) =>
      LIVE
        ? post<{ id: string; status: string }>('/api/orders', { ...o, email: email(), customer: (() => { try { const a = JSON.parse(localStorage.getItem('ko-account') || 'null'); return (a && a.name) || 'Guest'; } catch { return 'Guest'; } })() })
        : Promise.resolve({ id: 'KO-' + String(Date.now()).slice(-6), status: 'preparing' }),
    list: () => (LIVE ? get<{ orders: any[] }>('/api/orders').then((r) => r.orders || []) : Promise.resolve([])),
    history: () =>
      LIVE ? get<{ orders: any[] }>('/api/orders/history?email=' + encodeURIComponent(email())).then((r) => r.orders || []) : Promise.resolve([]),
    advance: (id: string) => (LIVE ? post<any>('/api/orders/' + id + '/advance', {}) : Promise.resolve({ id, status: 'preparing' })),
  },
  documents: {
    list: () => (LIVE ? get<ScanRecord[]>('/api/documents') : Promise.resolve([])),
    commit: (id: string, lines: ScanLine[]) => (LIVE ? post<any>('/api/documents/' + id + '/commit', { lines }) : Promise.resolve({ ok: true })),
  },
  ledger: { list: () => (LIVE ? get<any[]>('/api/ledger') : Promise.resolve([])) },
  /* owner analytics: the numbers behind the finance graphs and the buying advice */
  finance: () => (LIVE ? get<any>('/api/analytics/finance') : Promise.resolve(MOCK.finance)),
  insights: () => (LIVE ? get<any>('/api/analytics/insights') : Promise.resolve(MOCK.insights)),
  guide: () => (LIVE ? get<any>('/api/advisor/guide') : Promise.resolve({ guide: '', source: 'offline', sample: true })),
  deals: () => (LIVE ? get<{ deals: any[]; more: any[] }>('/api/deals') : Promise.resolve({ deals: MOCK.deals, more: MOCK.more })),
  accountant: { summary: () => (LIVE ? get<any>('/api/accountant/summary') : Promise.resolve(MOCK.summary)) },
  /* pick-your-window, online payments, chats, alerts, driver onboarding */
  slots: (days = 3) => (LIVE ? get<any>('/api/orders/slots?days=' + days) : Promise.resolve({ days: [], freeOver: 20, fee: 4.5 })),
  history: () => (LIVE ? get<{ orders: any[] }>('/api/orders/history?email=' + encodeURIComponent(email())).then((r) => r.orders || []) : Promise.resolve([])),
  payments: {
    config: () => (LIVE ? get<any>('/api/payments/config') : Promise.resolve({ live: false, providers: [
      { id: 'apple_pay', label: 'Apple Pay', ready: false, note: 'iPhone and iPad' },
      { id: 'google_pay', label: 'Google Pay', ready: false, note: 'Android' },
      { id: 'card', label: 'Debit or credit card', ready: false, note: 'Visa, Mastercard' },
      { id: 'paypal', label: 'PayPal', ready: false, note: 'PayPal balance or card' }] })),
    intent: (b: any) => (LIVE ? post<any>('/api/payments/intent', b) : Promise.resolve({ ok: true, ref: 'test', test: true })),
    confirm: (b: any) => (LIVE ? post<any>('/api/payments/confirm', b) : Promise.resolve({ ok: true, paid: true })),
    checkout: (b: any) => (LIVE ? post<any>('/api/payments/checkout', b) : Promise.resolve({ ok: false })),
    session: (id: string) => (LIVE ? get<any>('/api/payments/session?session_id=' + encodeURIComponent(id)) : Promise.resolve({ ok: false })),
  },
  messages: {
    list: (channel: string, since = 0) => (LIVE ? get<{ messages: any[] }>('/api/messages?channel=' + encodeURIComponent(channel) + '&since=' + since).then((r) => r.messages || []) : Promise.resolve([])),
    send: (b: any) => (LIVE ? post<any>('/api/messages', b) : Promise.resolve({ ok: true })),
  },
  alerts: {
    list: () => (LIVE ? get<any>('/api/notifications?email=' + encodeURIComponent(email())) : Promise.resolve({ notifications: [], unread: 0 })),
    read: () => (LIVE ? post<any>('/api/notifications/read', { email: email() }) : Promise.resolve({ ok: true })),
  },
  prefs: {
    get: () => (LIVE ? get<any>('/api/prefs?email=' + encodeURIComponent(email())) : Promise.resolve({ order_updates: 1, deals: 0, stock: 0 })),
    set: (p: any) => (LIVE ? post<any>('/api/prefs', { email: email(), ...p }) : Promise.resolve({ ok: true })),
  },
  drivers: {
    apply: (d: any) => (LIVE ? post<any>('/api/drivers/apply', d) : Promise.resolve({ ok: true, status: 'in_review' })),
    list: () => (LIVE ? get<{ drivers: any[] }>('/api/drivers').then((r) => r.drivers || []) : Promise.resolve([])),
    approve: (email: string) => (LIVE ? post<any>('/api/drivers/' + encodeURIComponent(email) + '/approve', {}) : Promise.resolve({ ok: true })),
  },
  delivery: { availability: () => (LIVE ? get<{ available: boolean }>('/api/delivery/availability') : Promise.resolve({ available: false })) },
  deliveries: { queue: () => (LIVE ? get<{ deliveries: any[] }>('/api/deliveries/queue').then(r => r.deliveries || []) : Promise.resolve([])), claim: (id: string, driver: string) => (LIVE ? post<any>('/api/deliveries/' + encodeURIComponent(id) + '/claim', { driver }) : Promise.resolve({ ok: true })), fresh: () => (LIVE ? get<{ new: number }>('/api/deliveries/new') : Promise.resolve({ new: 0 })) },
  driverProfile: { save: (email: string, d: any) => (LIVE ? post<any>('/api/drivers/' + encodeURIComponent(email) + '/profile', d) : Promise.resolve({ ok: true })), get: (email: string) => (LIVE ? get<any>('/api/drivers/' + encodeURIComponent(email) + '/profile') : Promise.resolve({ vehicle: 'walker', notifications: false, lat: 0, lon: 0 })) }, /* superuser console */
  admin: {
    overview: () => (LIVE ? get<any>('/api/admin/overview?as_email=' + encodeURIComponent(superEmail())) : Promise.resolve({ ok: false })),
    users: () => (LIVE ? get<any>('/api/admin/users?as_email=' + encodeURIComponent(superEmail())) : Promise.resolve({ ok: true, users: [] })),
    setRole: (target: string, role: string) => (LIVE ? post<any>('/api/admin/users/' + encodeURIComponent(target) + '/role', { role, as: superEmail() }) : Promise.resolve({ ok: true })),
  },
  /* store setup: business + VAT, certificates, distributors, stock with allergens */
  setup: {
    checklist: () => (LIVE ? get<any>('/api/setup/checklist') : Promise.resolve({ items: [], done: 0, total: 0 })),
    business: () => (LIVE ? get<any>('/api/setup/business') : Promise.resolve({ business: {} })),
    saveBusiness: (b: any) => (LIVE ? post<any>('/api/setup/business', b) : Promise.resolve({ ok: true })),
  },
  certificates: {
    list: () => (LIVE ? get<any>('/api/certificates') : Promise.resolve({ certificates: [], kinds: [] })),
    add: (c: any) => (LIVE ? post<any>('/api/certificates', c) : Promise.resolve({ ok: true })),
    remove: (id: string) => (LIVE ? req<any>('/api/certificates/' + id, { method: 'DELETE' }) : Promise.resolve({ ok: true })),
  },
  suppliers: {
    list: () => (LIVE ? get<{ suppliers: any[] }>('/api/suppliers') : Promise.resolve({ suppliers: [] })),
    add: (s: any) => (LIVE ? post<any>('/api/suppliers', s) : Promise.resolve({ ok: true })),
  },
  /* plans, the four-week free trial and enquiries */
  services: {
    pricing: () => (LIVE ? get<any>('/api/services/pricing') : Promise.resolve({ tiers: [], addons: [], trialWeeks: 4 })),
    status: () => (LIVE ? get<any>('/api/services/status') : Promise.resolve({})),
    startTrial: (b: any) => (LIVE ? post<any>('/api/services/trial', b) : Promise.resolve({ ok: true, days: 28 })),
    enquire: (b: any) => (LIVE ? post<any>('/api/services/enquiry', b) : Promise.resolve({ ok: true })),
  },
  /* deals the owner creates, plus the AI read on what to promote */
  dealPlans: {
    list: () => (LIVE ? get<{ deals: any[] }>('/api/deal-plans') : Promise.resolve({ deals: [] })),
    save: (d: any) => (LIVE ? post<any>('/api/deal-plans', d) : Promise.resolve({ ok: true })),
    remove: (id: string) => (LIVE ? req<any>('/api/deal-plans/' + id, { method: 'DELETE' }) : Promise.resolve({ ok: true })),
  },
  dealOpps: () => (LIVE ? get<any>('/api/deals/opportunities') : Promise.resolve({ opportunities: [], avoid: [], advice: '' })),
  dealAdvice: () => (LIVE ? get<any>('/api/deals/advice') : Promise.resolve({ advice: '', source: 'offline' })),
  /* superuser only: mint guest codes that work for two to four weeks */
  guests: {
    list: () => (LIVE ? get<any>('/api/guest-codes?as_email=' + encodeURIComponent(superEmail())) : Promise.resolve({ codes: [] })),
    create: (weeks: number, label: string) => (LIVE ? post<any>('/api/guest-codes', { weeks, label, as: superEmail() }) : Promise.resolve({ ok: true, code: 'TEST-CODE' })),
    revoke: (code: string) => (LIVE ? post<any>('/api/guest-codes/' + code + '/revoke', { as: superEmail() }) : Promise.resolve({ ok: true })),
  },
  account: { deleteRequest: (email: string) => (LIVE ? post<any>('/api/account/delete-request', { email }) : Promise.resolve({ ok: true })) },
  onboarding: { state: () => (LIVE ? get<any>('/api/onboarding/state?email=' + encodeURIComponent(accountEmail())) : Promise.resolve({ required: false, complete: true, missing: [] })) },
  app: { latest: () => (LIVE ? get<any>('/api/app/latest') : Promise.resolve({ latest_version: 'v96' })),
         apk: () => (LIVE ? get<any>('/api/app/apk') : Promise.resolve({ version: '1.0.0', versionCode: 1, url: '/download/kingdom-organics.apk', size: 70991856 })) },
  driverFees: { list: () => (LIVE ? get<any>('/api/driver-fees') : Promise.resolve({ fees: [] })), save: (f: any) => (LIVE ? post<any>('/api/driver-fees', f) : Promise.resolve({ ok: true })) },
  stickers: { list: () => (LIVE ? get<any>('/api/stickers') : Promise.resolve({ stickers: [] })), save: (s: any) => (LIVE ? post<any>('/api/stickers', s) : Promise.resolve({ ok: true })) },
  staff: { list: () => { try { return Promise.resolve(JSON.parse(localStorage.getItem('kog-team') || '[]') || []); } catch { return Promise.resolve([]); } }, create: (b: any) => (LIVE ? post<any>('/api/staff/create', b) : Promise.resolve({ ok: true })) },
};
