import React,{Component} from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

/* ---- runtime theme: ?theme=<base64url json>  OR localStorage 'ko-theme' ---- */
function b64d(s){try{s=String(s).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';return decodeURIComponent(escape(atob(s)))}catch(e){return null}}
function applyTheme(t){
  if(!t)return;
  var g=t.globals||t;
  for(var k in g){var name;k=k.trim();if(k.indexOf('--ko-')===0)name=k;else if(k.indexOf('--')===0)name='--ko-'+k.slice(2);else name='--ko-'+k;try{document.documentElement.style.setProperty(name,g[k])}catch(e){}}
}
/* deep links: /chat -> #/chat  (shareable URLs + screenshot-able screens) */
(function(){
  var p=location.pathname;
  if(p && p!=='/' && p.indexOf('/assets')!==0 && !location.hash){
    location.replace(location.origin+'/'+location.search+'#/'+p.replace(/^\//,''));
  }
})();
(function(){
  var m=location.search.match(/[?&]theme=([^&]+)/)||location.hash.match(/theme=([^&]+)/);
  var t=null;
  if(m){var raw=b64d(m[1]);if(raw){try{t=JSON.parse(raw)}catch(e){}}}
  if(!t){try{var ls=localStorage.getItem('ko-theme');if(ls)t=JSON.parse(ls)}catch(e){}}
  applyTheme(t);
  /* v134: apply the saved theme at boot, not only inside the Settings toggle */
  try{var tm=localStorage.getItem('kog-theme');
    document.documentElement.setAttribute('data-theme', tm==='dark'?'dark':'light');
  }catch(e){document.documentElement.setAttribute('data-theme','light')}
})();

/* v138: capture the last runtime error so a phone-side crash can be read back */
(function(){
  var K = 'kog-last-error';
  function rec(kind, msg, stack){
    try{ localStorage.setItem(K, JSON.stringify({ at: new Date().toISOString(), kind: kind, msg: String(msg).slice(0, 600), stack: String(stack || '').slice(0, 2000), route: (location.hash || '#/') })); }catch(e){}
    try{ console.error('[kog]', kind, msg, stack); }catch(e){}
    strip();
  }
  function strip(){
    try{
      var d = JSON.parse(localStorage.getItem(K) || 'null'); if(!d) return;
      if(document.getElementById('kog-err-strip')) return;
      if(!document.body) return;
      var el = document.createElement('div'); el.id = 'kog-err-strip';
      el.style.cssText = 'position:fixed;left:8px;right:8px;bottom:8px;z-index:9999;background:#8a2d1f;color:#fff;font:12px/1.4 monospace;padding:10px;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.4)';
      el.textContent = d.kind + ': ' + d.msg + '  @ ' + d.route;
      var b = document.createElement('button'); b.textContent = 'Dismiss';
      b.style.cssText = 'display:block;margin-top:8px;background:#fff;color:#8a2d1f;border:0;border-radius:8px;padding:6px 10px;font:bold 12px monospace';
      b.onclick = function(){ try{ localStorage.removeItem(K); }catch(e){} if(el.parentNode) el.parentNode.removeChild(el); };
      el.appendChild(b); document.body.appendChild(el);
    }catch(e){}
  }
  window.addEventListener('error', function(e){ rec('error', (e && e.message) || 'unknown', (e && e.error && e.error.stack) || ''); });
  window.addEventListener('unhandledrejection', function(e){ var r = e && e.reason; rec('promise', (r && (r.message || r)) || 'unhandled rejection', (r && r.stack) || ''); });
  window.addEventListener('load', function(){ setTimeout(strip, 700); });
  window.__kogLastError = function(){ try{ return JSON.parse(localStorage.getItem(K) || 'null'); }catch(e){ return null; } };
})();
class EB extends Component{constructor(p){super(p);this.state={e:null}}static getDerivedStateFromError(e){return {e: e}}render(){ if(this.state.e){ return React.createElement('div',{style:{padding:20,color:'#fff',background:'#8a2d1f',minHeight:'100vh',fontFamily:'monospace'}}, React.createElement('h2',null,'App error'), React.createElement('pre',{style:{whiteSpace:'pre-wrap'}}, String(this.state.e && this.state.e.stack || this.state.e))) } return this.props.children }}

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><EB><App/></EB></React.StrictMode>)
