import React,{useState,useEffect,useRef} from 'react';
import {Shell,go,useApp} from './App';
import {api} from './api';
import {PRODUCTS,CATEGORIES} from './lib/data';
import {IconSearch,IconScooter} from './icons';

const eur=(n:any)=>'€'+Number(n||0).toFixed(2);

/* ---------------------------------------------------------------- order chat */
export const ChannelChat=({channel,title,sub}:{channel:string;title:string;sub?:string})=>{
 const{user,role}=useApp();const[msgs,setMsgs]=useState<any[]>([]);const[inp,setInp]=useState('');const[since,setSince]=useState(0);const box=useRef<HTMLDivElement|null>(null);
 const load=()=>api.messages.list(channel,since).then((m:any[])=>{if(m.length){setMsgs(x=>[...x,...m]);setSince(m[m.length-1].created)}}).catch(()=>{});
 useEffect(()=>{load();const t=setInterval(load,4000);return()=>clearInterval(t)},[channel,since]);
 useEffect(()=>{if(box.current)box.current.scrollTop=box.current.scrollHeight},[msgs]);
 const send=async()=>{const b=inp.trim();if(!b)return;setInp('');setMsgs(x=>[...x,{id:'local'+Date.now(),sender:user,role,body:b,me:true,created:Date.now()/1000}]);
  try{await api.messages.send({channel,sender:user,role,body:b})}catch(e){}};
 return(<Shell back="/home"><div className="px-4 pt-3 flex flex-col" style={{height:'calc(100dvh - 130px)'}}>
  <div className="mb-2"><h1 className="font-display text-white text-xl font-bold">{title}</h1>{!!sub&&<div className="text-white/70 text-[11px]">{sub}</div>}</div>
  <div ref={box} className="flex-1 overflow-y-auto space-y-2 pb-3">
   {!msgs.length&&<div className="text-white/70 text-[12px]">No messages yet. Say hello.</div>}
   {msgs.map((m:any,i:number)=>{const mine=(m.me||m.sender===user);return(<div key={m.id||i} className={"max-w-[85%] rounded-2xl px-3 py-2 text-[13px] "+(mine?"ml-auto":"")} style={mine?{background:'#2A00D6',color:'#F9F7F2'}:{background:'#F9F7F2',color:'#111827'}}>
    {!mine&&<div className="text-[10px] font-bold mb-0.5" style={{color:'#4B5563'}}>{m.sender}{m.role?' · '+m.role:''}</div>}{m.body}</div>)})}
  </div>
  <div className="flex gap-2 py-2"><input value={inp} onChange={(e:any)=>setInp(e.target.value)} onKeyDown={(e:any)=>e.key==='Enter'&&send()} placeholder="Message…" className="flex-1 rounded-xl px-3 py-2.5 text-sm outline-none" style={{background:'#F9F7F2',color:'#111827'}}/>
   <button onClick={send} className="px-4 rounded-xl font-bold" style={{background:'#E8960F',color:'#1a1206'}}>Send</button></div>
 </div></Shell>);};

/* ---------------------------------------------------------------- order history + buy again */
export const OrdersPage=()=>{const{add,refreshKey}=useApp();const[orders,setOrders]=useState<any[]>([]);const[added,setAdded]=useState('');
 useEffect(()=>{api.orders.history().then(setOrders).catch(()=>{})},[refreshKey]);
 const again=(o:any)=>{let n=0;(o.items||[]).forEach((i:any)=>{for(let k=0;k<(i.qty||1);k++){add(i.id);n++}});setAdded(String(o.id)+':'+n);setTimeout(()=>setAdded(''),2500)};
 const tone=(s:string)=>s==='delivered'?'#0B6B4F':s==='rider'||s==='arriving'?'#8a4b06':'#1b1146';
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>My orders</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Every basket you have placed, with a one-tap repeat.</p>
  {!orders.length&&<div className="card-white p-4 text-[12px] text-gray-600 shadow-lg">No orders yet — your first basket will appear here.</div>}
  {orders.map((o:any)=>(<div key={o.id} className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <div className="flex justify-between items-baseline"><b className="text-sm">{o.id}</b><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{background:'rgba(0,1,87,.08)',color:tone(o.status)}}>{o.status}</span></div>
   <div className="text-[11px] text-gray-600 mt-0.5">{new Date(Number(o.created||0)*1000).toLocaleString()}{o.slot?' · '+o.slot:''}{o.paid?' · paid':''}</div>
   <div className="mt-2">{(o.items||[]).map((i:any,k:number)=>(<div key={k} className="flex justify-between text-[12px] py-0.5"><span>{i.name} × {i.qty}</span><span>{eur((i.price||0)*(i.qty||1))}</span></div>))}</div>
   <div className="flex justify-between items-center mt-2 pt-2 border-t"><b>{eur(o.total)}</b>
    <div className="flex gap-2"><button onClick={()=>go('/order-chat/'+o.id)} className="text-[11px] font-semibold px-3 py-1.5 rounded-full" style={{background:'rgba(42,0,214,.10)',color:'#1b1146'}}>Track chat</button>
    <button onClick={()=>again(o)} className="text-[11px] font-bold px-3 py-1.5 rounded-full" style={{background:'#E8960F',color:'#1a1206'}}>{added.startsWith(o.id)?'Added ✓':'Buy again'}</button></div></div>
  </div>))}
 </div></Shell>);};

/* ---------------------------------------------------------------- alerts + optional opt-in */
export const AlertsPage=()=>{
 const{refreshKey}=useApp();const[list,setList]=useState<any[]>([]);const[unread,setUnread]=useState(0);const[p,setP]=useState<any>({order_updates:1,deals:0,stock:0});const[saved,setSaved]=useState(false);
 useEffect(()=>{api.alerts.list().then((r:any)=>{setList(r.notifications||[]);setUnread(r.unread||0)}).catch(()=>{});api.prefs.get().then((r:any)=>setP(r)).catch(()=>{})},[refreshKey]);
 const toggle=(k:string)=>{const n={...p,[k]:p[k]?0:1};setP(n);setSaved(true);api.prefs.set(n).catch(()=>{});setTimeout(()=>setSaved(false),1500)};
 const markRead=()=>{api.alerts.read().then(()=>{setUnread(0);setList(l=>l.map(x=>({...x,read:1})))}).catch(()=>{})};
 const row=(k:string,t:string,s:string)=>(<button key={k} onClick={()=>toggle(k)} className="w-full flex items-center gap-3 py-2.5 border-b last:border-0 text-left">
  <span className="flex-1"><span className="block text-sm font-semibold">{t}</span><span className="block text-[11px] text-gray-600">{s}</span></span>
  <span className="w-11 h-6 rounded-full relative shrink-0" style={{background:p[k]?'#2A00D6':'rgba(17,24,39,.25)'}}><span className="absolute top-0.5 size-5 rounded-full bg-white transition" style={{left:p[k]?'22px':'2px'}}/></span></button>);
 return(<Shell back="/home"><div className="px-4 pt-3">
  <div className="flex items-center justify-between mb-1"><h1 className="font-display text-white text-2xl font-bold">Alerts</h1>{unread>0&&<button onClick={markRead} className="text-[11px] text-ko-goldbright font-semibold">Mark all read</button>}</div>
  <p className="text-white/70 text-xs mb-4" data-reveal>Optional — switch on only what you want to hear about.</p>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <div className="font-bold text-sm mb-1">What we may send you</div>
   {row('order_updates','Order updates','Confirmed, packed, driver on the way, delivered')}
   {row('deals','Deals and offers','Weekly specials and member prices')}
   {row('stock','Back in stock','Only for items you asked about')}
   {saved&&<div className="text-[11px] mt-2" style={{color:'#0B6B4F'}}>Saved ✓</div>}
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <div className="font-bold text-sm mb-2">Recent</div>
   {!list.length&&<div className="text-[12px] text-gray-600">Nothing yet. Order updates land here.</div>}
   {list.map((n:any)=>(<div key={n.id} className="py-2 border-b last:border-0"><div className="text-sm font-semibold">{n.title}</div><div className="text-[11px] text-gray-600">{n.body}</div><div className="text-[10px] text-gray-600 mt-0.5">{new Date(Number(n.created||0)*1000).toLocaleString()}</div></div>))}
  </div>
 </div></Shell>);};

/* ---------------------------------------------------------------- driver onboarding */
export const DriverApplyPage=()=>{
 const{user}=useApp();const[step,setStep]=useState(0);const[busy,setBusy]=useState(false);const[err,setErr]=useState('');const[done,setDone]=useState<any>(null);
 const[f,setF]=useState({name:'',email:'',phone:'',vehicle:'Van',plate:'',area:'Tralee',radius:'5 km',licence:false,insurance:false,idDoc:false});
 const set=(k:string)=>(e:any)=>setF(x=>({...x,[k]:e&&e.target?e.target.value:e}));
 useEffect(()=>{try{const a=JSON.parse(localStorage.getItem('ko-account')||'null');if(a)setF(x=>({...x,name:x.name||a.name||'',email:x.email||a.email||''}))}catch(e){}},[]);
 const submit=async()=>{setErr('');
  if(!f.name.trim()||!f.email.trim()||!f.phone.trim()||!f.plate.trim()){setErr('Name, email, phone and plate are needed.');return}
  if(!f.licence||!f.insurance||!f.idDoc){setErr('Tick the three documents so the shop can verify you.');return}
  setBusy(true);try{const r:any=await api.drivers.apply(f);setDone(r)}catch(e){setErr('Could not send it — try again.');setBusy(false)}};
 if(done)return(<Shell nav={false}><div className="min-h-[70vh] flex flex-col items-center justify-center text-white gap-3 px-6 text-center"><div className="size-16 rounded-full bg-ko-brand flex items-center justify-center"><IconScooter className="size-8"/></div><h1 className="font-display text-2xl font-bold">Application sent</h1><p className="text-white/75 text-sm">The store reviews your licence, insurance and ID, then you are live. You will get an alert the moment you are approved.</p><button onClick={()=>go('/driver')} className="mt-2 text-ko-goldbright underline text-sm">Go to my runs</button></div></Shell>);
 const stepBox=(n:number,t:string,body:any)=>(<div className="card-white p-4 mb-3 shadow-lg" data-reveal>
  <div className="flex items-center gap-2 mb-2"><span className="size-6 rounded-full text-[11px] font-bold flex items-center justify-center" style={{background:step>=n?'#2A00D6':'rgba(17,24,39,.18)',color:'#F9F7F2'}}>{n+1}</span><b className="text-sm">{t}</b></div>{step>=n&&body}</div>);
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Drive for Kingdom Organics</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Three short steps. Most drivers are approved the same day.</p>
  {stepBox(0,'Who you are',<div>
    <input value={f.name} onChange={set('name')} aria-label="Full name" placeholder="Full name" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
    <input value={f.email} onChange={set('email')} aria-label="Email" placeholder="Email" inputMode="email" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
    <input value={f.phone} onChange={set('phone')} aria-label="Mobile" placeholder="Mobile" inputMode="tel" className="w-full border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ko-gold/50"/>
    {step===0&&<button onClick={()=>setStep(1)} className="mt-3 w-full py-3 rounded-xl font-semibold text-white" style={{background:'#2A00D6'}}>Next</button>}</div>)}
  {stepBox(1,'Your vehicle and area',<div>
    {['Van','Car','E-bike','Motorbike'].map(v=>(<button key={v} onClick={()=>setF(x=>({...x,vehicle:v}))} className="px-3 py-1.5 rounded-full text-[12px] font-semibold mr-2 mb-2" style={{background:f.vehicle===v?'#2A00D6':'rgba(0,1,87,.08)',color:f.vehicle===v?'#F9F7F2':'#1b1146'}}>{v}</button>))}
    <input value={f.plate} onChange={set('plate')} aria-label="Registration" placeholder="Registration" className="w-full border rounded-xl px-3 py-2.5 text-sm mb-2 outline-none focus:ring-2 focus:ring-ko-gold/50"/>
    <div className="flex gap-2"><input value={f.area} onChange={set('area')} aria-label="Area, e.g. Tralee" placeholder="Area, e.g. Tralee" className="flex-1 border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ko-gold/50"/>
    <input value={f.radius} onChange={set('radius')} aria-label="Radius" placeholder="Radius" className="w-24 border rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ko-gold/50"/></div>
    {step===1&&<button onClick={()=>setStep(2)} className="mt-3 w-full py-3 rounded-xl font-semibold text-white" style={{background:'#2A00D6'}}>Next</button>}</div>)}
  {stepBox(2,'Documents',<div>
    <div className="text-[11px] text-gray-600 mb-2">Photograph each one — they are checked by the shop, never shared.</div>
    {[['licence','Driving licence'],['insurance','Vehicle insurance'],['idDoc','Photo ID']].map(([k,tx])=>(<button key={k} onClick={()=>setF(x=>({...x,[k]:!(x as any)[k]}))} className="w-full flex items-center gap-3 py-2 border-b last:border-0 text-left text-sm">
      <span className="flex-1">{tx}</span><span className="text-[11px] font-bold" style={{color:(f as any)[k]?'#0B6B4F':'#8a4b06'}}>{(f as any)[k]?'Attached ✓':'Attach'}</span></button>))}
    {!!err&&<div className="mt-3 rounded-xl px-3 py-2 text-[12px]" style={{background:'rgba(232,150,15,.16)',border:'1px solid rgba(232,150,15,.6)',color:'#8a4b06'}}>{err}</div>}
    <button onClick={submit} disabled={busy} className="mt-3 w-full py-3 rounded-xl font-bold" style={{background:'#E8960F',color:'#1a1206'}}>{busy?'Sending…':'Send application'}</button></div>)}
 </div></Shell>);};

/* ---------------------------------------------------------------- owner: drivers + approvals */
export const DriversAdminPage=()=>{
 const{refreshKey}=useApp();const[rows,setRows]=useState<any[]>([]);const[busy,setBusy]=useState('');
 const load=()=>api.drivers.list().then(setRows).catch(()=>{});
 useEffect(()=>{load()},[refreshKey]);
 const approve=async(e:string)=>{setBusy(e);try{await api.drivers.approve(e);await load()}catch(err){}setBusy('')};
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Drivers</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Applications, documents and approvals.</p>
  {!rows.length&&<div className="card-white p-4 text-[12px] text-gray-600 shadow-lg">No driver applications yet.</div>}
  {rows.map((d:any)=>(<div key={d.email} className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <div className="flex justify-between items-baseline"><b className="text-sm">{d.name||d.email}</b><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{background:d.status==='approved'?'rgba(11,107,79,.12)':'rgba(232,150,15,.16)',color:d.status==='approved'?'#0B6B4F':'#8a4b06'}}>{d.status}</span></div>
   <div className="text-[11px] text-gray-600 mt-0.5">{d.phone} · {d.vehicle||'—'} {d.plate||''} · {d.area||''} {d.radius||''}</div>
   <div className="text-[11px] text-gray-600">Documents attached: {d.docs}/3 · deliveries {d.deliveries||0}</div>
   {d.status!=='approved'&&<button onClick={()=>approve(d.email)} disabled={busy===d.email} className="mt-3 w-full py-2.5 rounded-xl font-bold text-white" style={{background:busy===d.email?'#6f6f92':'#2A00D6'}}>{busy===d.email?'Approving…':'Approve driver'}</button>}
  </div>))}
 </div></Shell>);};

/* ---------------------------------------------------------------- windows + payment */
export const PickWindow=({value,onChange}:{value:string;onChange:(k:string)=>void})=>{
 const{refreshKey}=useApp();const[data,setData]=useState<any>(null);
 useEffect(()=>{api.slots(3).then(setData).catch(()=>{})},[refreshKey]);
 if(!data)return <div className="text-[12px] text-gray-600">Loading delivery windows…</div>;
 const days=(data.days||[]).slice(0,3);
 return(<div>
  {days.map((d:any)=>(<div key={d.date} className="mb-2">
   <div className="text-[11px] font-bold text-gray-600 mb-1">{d.label}</div>
   <div className="grid grid-cols-3 gap-2">{d.slots.map((s:any)=>(<button key={s.key} disabled={s.full} onClick={()=>onChange(s.key)} className="py-2 rounded-xl text-[11px] font-semibold" style={value===s.key?{background:'#2A00D6',color:'#F9F7F2'}:s.full?{background:'rgba(17,24,39,.08)',color:'rgba(17,24,39,.35)'}:{background:'rgba(0,1,87,.06)',color:'#1b1146'}}>{s.window}<span className="block text-[9px] font-normal">{s.full?'full':s.left+' left'}</span></button>))}</div></div>))}
  {!days.length&&<div className="text-[12px] text-gray-600">No windows open — the shop will call you to arrange one.</div>}
 </div>);};

export const PayPanel=({method,setMethod,total}:{method:string;setMethod:(m:string)=>void;total:number})=>{
 const[cfg,setCfg]=useState<any>(null);
 useEffect(()=>{api.payments.config().then(setCfg).catch(()=>{})},[]);
 if(!cfg)return <div className="text-[12px] text-gray-600">Checking payment methods…</div>;
 return(<div>
  <div className="text-[12px] font-semibold mb-2">Pay {eur(total)} now</div>
  {(cfg.providers||[]).map((p:any)=>(<button key={p.id} onClick={()=>setMethod(p.id)} className="w-full flex items-center gap-3 py-2.5 border-b last:border-0 text-left">
   <span className="size-4 rounded-full border-2 shrink-0" style={{borderColor:'#2A00D6',background:method===p.id?'#2A00D6':'transparent'}}/>
   <span className="flex-1"><span className="block text-sm font-semibold">{p.label}</span><span className="block text-[10px] text-gray-600">{p.note}</span></span>
   {!p.ready&&<span className="text-[10px] font-bold" style={{color:'#8a4b06'}}>ready to connect</span>}</button>))}
  {!cfg.live&&<div className="mt-3 rounded-xl px-3 py-2 text-[11px]" style={{background:'rgba(232,196,84,.16)',border:'1px solid rgba(232,196,84,.6)',color:'#8a4b06'}}>Payment keys are not connected yet, so this run is a test authorisation — no money moves. Cash on delivery has been withdrawn.</div>}
 </div>);};

/* ---------------------------------------------------------------- search with filters */
export const SearchWithFilters=()=>{
 const{add}=useApp();const[q,setQ]=useState('');const[cat,setCat]=useState('All');const[organicOnly,setOrganic]=useState(false);const[max,setMax]=useState(7);const[sort,setSort]=useState('popular');
 const cats=['All'].concat(CATEGORIES.map(c=>c.id));
 let list=PRODUCTS.filter(p=>(!q||(p.name+' '+p.sub+' '+(p.tags||[]).join(' ')).toLowerCase().includes(q.toLowerCase()))&&(cat==='All'||p.cat===cat)&&(!organicOnly||p.organic)&&p.price<=max);
 if(sort==='cheap')list=[...list].sort((a,b)=>a.price-b.price);else if(sort==='dear')list=[...list].sort((a,b)=>b.price-a.price);
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-3" data-reveal>Search</h1>
  <div className="glass rounded-2xl flex items-center gap-2 px-4 py-3 text-white mb-3" data-reveal><IconSearch className="size-5"/><input value={q} onChange={(e:any)=>setQ(e.target.value)} placeholder="Rice, halal meat, organic milk…" className="bg-transparent outline-none flex-1 placeholder-white/60 text-sm"/></div>
  <div className="pill-scroll mb-2">{cats.map(c=>(<button key={c} onClick={()=>setCat(c)} className="whitespace-nowrap px-3 py-1.5 rounded-full text-[12px] font-semibold mr-2" style={cat===c?{background:'#E8C454',color:'#1a1206'}:{background:'rgba(255,255,255,.14)',color:'#F9F7F2'}}>{c==='All'?'All':c}</button>))}</div>
  <div className="card-white p-3 mb-3 shadow-lg" data-reveal>
   <div className="flex items-center justify-between mb-2"><span className="text-[12px] font-semibold">Organic only</span>
    <button onClick={()=>setOrganic(!organicOnly)} className="w-11 h-6 rounded-full relative" style={{background:organicOnly?'#2A00D6':'rgba(17,24,39,.25)'}}><span className="absolute top-0.5 size-5 rounded-full bg-white transition" style={{left:organicOnly?'22px':'2px'}}/></button></div>
   <div className="text-[12px] font-semibold mb-1">Max price {eur(max)}</div>
   <input type="range" min={1} max={7} step={0.1} value={max} onChange={(e:any)=>setMax(Number(e.target.value))} className="w-full"/>
   <div className="flex gap-2 mt-2">{['popular','cheap','dear'].map(s=>(<button key={s} onClick={()=>setSort(s)} className="px-3 py-1 rounded-full text-[11px] font-semibold" style={sort===s?{background:'#2A00D6',color:'#F9F7F2'}:{background:'rgba(0,1,87,.06)',color:'#1b1146'}}>{s==='popular'?'Popular':s==='cheap'?'Cheapest':'Dearest'}</button>))}</div>
  </div>
  <div className="text-[11px] text-white/70 mb-2" data-reveal>{list.length} item{list.length===1?'':'s'}</div>
  <div className="grid grid-cols-2 gap-3">{list.slice(0,24).map(p=>(<div key={p.id} className="card-white overflow-hidden shadow-lg" data-reveal>
   <div className="aspect-square bg-gray-50 flex items-center justify-center p-2"><img src={p.img} alt={p.name} className="w-full h-full object-cover" loading="lazy"/></div>
   <div className="p-3"><div className="font-semibold text-sm leading-snug min-h-[2.2em]">{p.name}</div><div className="text-[11px] text-gray-600">{p.sub}</div>
   <div className="flex items-center justify-between mt-2"><b>{eur(p.price)}</b><button onClick={()=>add(p.id)} className="px-3 py-1.5 rounded-lg text-[12px] font-bold text-white" style={{background:'#2A00D6'}}>+ Add</button></div></div>
  </div>))}</div>
  {!list.length&&<div className="card-white p-4 text-[12px] text-gray-600 shadow-lg" data-reveal>Nothing matches those filters. Try widening the price or clearing a filter.</div>}
 </div></Shell>);};

/* ---------------------------------------------------------------- superuser console */
export const SuperPage=()=>{
 const{user,refreshKey}=useApp();const[ov,setOv]=useState<any>(null);const[users,setUsers]=useState<any[]>([]);const[busy,setBusy]=useState('');const[err,setErr]=useState('');
 const email=user;
 const load=()=>{api.admin.overview().then((r:any)=>setOv(r&&r.ok?r:null)).catch(()=>setErr('Only the superuser account can open this.'));api.admin.users().then((r:any)=>setUsers((r&&r.users)||[])).catch(()=>{})};
 useEffect(()=>{load()},[]);
 const setRole=async(e:string,role:string)=>{setBusy(e+role);try{await api.admin.setRole(e,role);await load()}catch(x){}setBusy('')};
 const roles=['customer','driver','admin','owner','staff'];
 const box=(label:string,value:any)=>(<div key={label} className="card-white p-3 text-center shadow-lg"><div className="font-display text-base font-bold">{value}</div><div className="text-[10px] text-gray-600">{label}</div></div>);
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Superuser</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Everything on the platform, and the keys to every account.</p>
  {!!err&&<div className="rounded-2xl px-3 py-2 mb-3 text-[12px]" style={{background:'rgba(232,150,15,.16)',border:'1px solid rgba(232,150,15,.6)',color:'#E8C454'}} data-reveal>{err}</div>}
  {!!ov&&<>
   <div className="grid grid-cols-2 gap-3 mb-3">
    {box('People',ov.people.total)}{box('Customers',ov.people.customers)}{box('Staff',ov.people.staff)}{box('Drivers',ov.people.drivers)}
   </div>
   <div className="grid grid-cols-2 gap-3 mb-3">
    {box('Orders',ov.orders.count)}{box('Revenue','€'+Number(ov.orders.revenue||0).toFixed(2))}{box('Paid online',ov.orders.paid)}{box('Open orders',ov.orders.open)}
   </div>
   <div className="grid grid-cols-2 gap-3 mb-4">
    {box('Supplier spend','€'+Number(ov.money.spend||0).toFixed(2))}{box('VAT on purchases','€'+Number(ov.money.vat||0).toFixed(2))}{box('Stock value','€'+Number(ov.money.stockValue||0).toFixed(2))}{box('Apps in review',ov.drivers.inReview)}
   </div>
  </>}
  <div className="card-white p-4 shadow-lg" data-reveal>
   <div className="font-bold text-sm mb-2">Accounts</div>
   {!users.length&&<div className="text-[12px] text-gray-600">No accounts to show.</div>}
   {users.map((u:any)=>(<div key={u.email} className="py-2 border-b last:border-0">
    <div className="flex items-center gap-2"><span className="flex-1 min-w-0"><span className="block text-sm font-semibold truncate">{u.name||u.email}{u.is_super?' ★':''}</span><span className="block text-[10px] text-gray-600 truncate">{u.email}</span></span>
     <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{background:'rgba(0,1,87,.08)',color:'#1b1146'}}>{u.role}</span></div>
    <div className="flex gap-1.5 mt-1.5 flex-wrap">{roles.filter(r=>r!==u.role).map(r=>(<button key={r} onClick={()=>setRole(u.email,r)} disabled={busy===u.email+r} className="px-2.5 py-1 rounded-full text-[10px] font-semibold" style={{background:'rgba(42,0,214,.10)',color:'#1b1146'}}>{busy===u.email+r?'…':'make '+r}</button>))}</div>
   </div>))}
  </div>
 </div></Shell>);};
