import React,{useState,useEffect} from 'react';
import {Shell,go,useApp} from './App';
import {api} from './api';

/* ---------------------------------------------------------------------------
   Legal. The company behind the shop, and the terms every user accepts.
   Entity details must match the CRO register exactly.
   --------------------------------------------------------------------------- */
export const LEGAL = {
  company: 'Hive Health Ecosystem Ltd',
  address: '20 Harcourt Street, Dublin 2, D02 H364, Ireland',
  reg: '824008',
  jurisdiction: 'Ireland',
  email: 'hello@kingdomorganics.ie',
  privacyEmail: 'privacy@kingdomorganics.ie',
  dpa: 'Data Protection Commission, 21 Fitzwilliam Square South, Dublin 2, D02 RD28 — info@dataprotection.ie',
  updated: '11 September 2026',
  trades: ['Kingdom Organics', 'Hive Nutrition'],
};

export const COPYRIGHT = '© 2026 ' + LEGAL.company + '. All rights reserved.';

const H=({children}:{children:any})=>(<h2 className="font-display text-white text-lg font-bold mt-5 mb-2">{children}</h2>);
const P=({children}:{children:any})=>(<p className="text-[12px] leading-relaxed mb-2" style={{color:'#E8E6F5'}}>{children}</p>);
const LI=({children}:{children:any})=>(<li className="text-[12px] leading-relaxed mb-1" style={{color:'#E8E6F5'}}>{children}</li>);
const Card=({children}:{children:any})=>(<div className="glass rounded-2xl p-4 mb-3" data-reveal>{children}</div>);
const Strong=({children}:{children:any})=>(<b style={{color:'#F9F7F2'}}>{children}</b>);

export const LegalPage=()=>{
 const[accepted,setAccepted]=useState<string>('');
 useEffect(()=>{try{setAccepted(localStorage.getItem('ko-consent')||'')}catch(e){}},[]);
 return(<Shell back="/home"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Legal</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Who runs this shop, and the terms you agreed to.</p>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <div className="font-bold text-sm mb-1">{LEGAL.company}</div>
   <div className="text-[12px] text-gray-700 leading-relaxed">
    Registered office: {LEGAL.address}<br/>
    Registered in {LEGAL.jurisdiction}, company number <b>{LEGAL.reg}</b><br/>
    Trading names: {LEGAL.trades.join(' · ')}<br/>
    Contact: {LEGAL.email}
   </div>
   <div className="text-[11px] text-gray-600 mt-2">Kingdom Organics is operated by {LEGAL.company}. {COPYRIGHT}</div>
  </div>
  <div className="grid grid-cols-2 gap-3 mb-3">
   <button onClick={()=>go('/terms')} className="card-white p-4 text-left shadow-lg" data-reveal><b className="text-sm block">Terms of Service</b><span className="text-[11px] text-gray-600">Orders, delivery, licence to use the app</span></button>
   <button onClick={()=>go('/privacy')} className="card-white p-4 text-left shadow-lg" data-reveal><b className="text-sm block">Privacy Notice</b><span className="text-[11px] text-gray-600">Your data, your rights, our duties</span></button>
  </div>
  <button onClick={()=>go('/delete-account')} className="card-white p-4 w-full text-left shadow-lg mb-3" data-reveal><b className="text-sm block">Delete your account</b><span className="text-[11px] text-gray-600">Five minutes to read, and your data goes</span></button>
  <button onClick={()=>go('/accessibility')} className="card-white p-4 w-full text-left shadow-lg mb-3" data-reveal><b className="text-sm block">Accessibility statement</b><span className="text-[11px] text-gray-600">How we meet the European Accessibility Act, and what to do if we fall short</span></button>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <div className="font-bold text-sm mb-1">Your acceptance</div>
   <div className="text-[12px] text-gray-700">{accepted?('Accepted on '+new Date(accepted).toLocaleString()):'Not recorded on this device yet — you will be asked at sign-up.'}</div>
  </div>
 </div></Shell>);};

export const TermsPage=()=>(
 <Shell back="/legal"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Terms of Service</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Version of {LEGAL.updated} · governed by the laws of {LEGAL.jurisdiction}</p>
  <Card>
   <Strong>1. Who we are.</Strong>
   <P>This app and the Kingdom Organics store are operated by {LEGAL.company}, registered office {LEGAL.address}, registered in {LEGAL.jurisdiction} under company number {LEGAL.reg}, trading as {LEGAL.trades.join(' and ')} ("we", "us"). You can reach us at {LEGAL.email}. These terms form a contract between you and us.</P>
  </Card>
  <Card>
   <Strong>2. Your licence to use this app.</Strong>
   <P>We grant you a personal, non-exclusive, non-transferable, revocable licence to use this application on devices you control, for the purpose of shopping with us, managing your account, and — if you hold a staff or driver account — carrying out your role. You may not copy, modify, resell, sublicense, reverse engineer, scrape, or attempt to extract the source code of the app, except where the law expressly allows it.</P>
   <P>All rights, title and interest in the application, its design, its software and its content remain with {LEGAL.company} or its licensors. No rights are granted to you other than the licence above. This is a licence, not a sale: nothing in these terms transfers ownership of the app to you.</P>
  </Card>
  <Card>
   <Strong>3. Accounts.</Strong>
   <P>You must be 18 or over to open an account. Keep your password confidential; you are responsible for activity under your account. Staff and driver accounts are granted by us and may be withdrawn at any time. One person, one account.</P>
  </Card>
  <Card>
   <Strong>4. Orders, prices and payment.</Strong>
   <P>Prices are shown in euro and include VAT where it applies. A contract of sale is formed when we confirm your order in the app. Goods are subject to availability; if an item runs out we will tell you and refund that part of the order.</P>
   <P>Where we show a discount or a previous price, that previous price is the lowest price at which we offered the item in the 30 days before the reduction.</P>
   <P>We take payment online only (card, Apple Pay, Google Pay or PayPal) at the time you place the order. We no longer offer cash on delivery. Card payments are processed by our payment provider; we never store your full card details.</P>
  </Card>
  <Card>
   <Strong>5. Delivery.</Strong>
   <P>You choose a delivery window at checkout. We aim to arrive inside it, but traffic and weather can move it. If we cannot deliver, we will contact you and refund the delivery charge. Risk passes to you on delivery.</P>
  </Card>
  <Card>
   <Strong>6. Cancellation and your right to withdraw.</Strong>
   <P>As a consumer you may cancel within 14 days of delivery under the Consumer Rights Directive. <Strong>Perishable goods — fresh meat, fish, dairy, produce, bakery and anything with a short life — are exempt</Strong> once delivered, as are sealed goods opened after delivery and items made to your specification. To cancel non-perishable items, contact {LEGAL.email} and return them unused, at your cost, within 14 days. Faulty or incorrect items are always refunded in full or replaced. Nothing here affects your statutory rights.</P>
  </Card>
  <Card>
   <Strong>7. Food information and allergens.</Strong>
   <P>We are a registered food business and follow the EU Food Information to Consumers rules. <Strong>Allergen information for every item is available before you buy</Strong> — ask in the product page chat or by email and we will confirm in writing. Product images are illustrative. If you have a severe allergy, contact us before ordering so we can advise on handling in our premises.</P>
   <P>Organic items are certified organic; halal items come from suppliers certified halal. Certificates are available on request.</P>
  </Card>
  <Card>
   <Strong>8. Loyalty points.</Strong>
   <P>Points are earned on paid orders at the rate shown in the app, have no cash value, are not transferable, and may be corrected if awarded in error. We may change the programme with notice in the app.</P>
  </Card>
  <Card>
   <Strong>9. AI features.</Strong>
   <P>Parts of this app use artificial intelligence: the assistant that answers your questions, the reading of photographed supplier documents for stock and accounts, and the buying advice shown to the shop. AI output can be wrong. <Strong>You are talking to an AI, not a person</Strong>, and a human at the shop confirms any document before it affects stock or accounts. Do not rely on AI output as legal, medical, tax or accounting advice.</P>
  </Card>
  <Card>
   <Strong>10. Acceptable use.</Strong>
   <P>Do not use the app to break the law, to interfere with its operation, to place fraudulent orders, to upload unlawful content, or to harass our staff, drivers or other customers in the chat channels.</P>
  </Card>
  <Card>
   <Strong>11. Our liability.</Strong>
   <P>We do not exclude liability that cannot be excluded by law, including for death or personal injury caused by negligence, or for defective goods. Subject to that, we are not liable for indirect or consequential loss, and our total liability for any order is limited to the amount you paid for it.</P>
  </Card>
  <Card>
   <Strong>12. Changes, law and disputes.</Strong>
   <P>We may update these terms; the version in force is the one in the app when you order. These terms are governed by the laws of {LEGAL.jurisdiction} and the courts of {LEGAL.jurisdiction} have jurisdiction. Consumers may also use the EU Online Dispute Resolution platform and the CCPC's consumer helpline.</P>
  </Card>
  <Card>
   <Strong>13. App stores and device terms.</Strong>
   <P>You may install the app from the Apple App Store or Google Play. Downloads and payments made through those stores are governed by the store provider's own terms, including the Apple Licensed Application End User License Agreement and the Google Play Terms of Service. Any refund request for a purchase made inside the app must be raised with the store you bought from first, as we do not control those platforms.</P>
  </Card>
  <Card>
   <Strong>14. Irish and European consumer protection.</Strong>
   <P>As an Irish business we comply with the Consumer Rights Acts, the Consumer Rights Directive 2011/83/EU, the Sale of Goods and Digital Content Directive (EU) 2019/771, and the Platform to Business Regulation (EU) 2019/1150 for business users, together with Irish food law including registration with the Food Safety Authority of Ireland. Nothing in these terms reduces your statutory rights, including the 14-day right of withdrawal for distance sales, remedies for faulty goods, and access to the European Online Dispute Resolution platform and the CCPC consumer helpline.</P>
  </Card>
  <div className="text-center text-white/70 text-[10px] mt-4 mb-2">{COPYRIGHT}</div>
 </div></Shell>);

export const PrivacyPage=()=>(
 <Shell back="/legal"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Privacy Notice</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Version of {LEGAL.updated} · your rights under the GDPR</p>
  <Card>
   <Strong>Who is responsible.</Strong>
   <P>{LEGAL.company}, {LEGAL.address}, company number {LEGAL.reg}, is the data controller for this app. Questions or requests: {LEGAL.privacyEmail}. You may complain at any time to the {LEGAL.dpa}.</P>
  </Card>
  <Card>
   <Strong>What we collect and why.</Strong>
   <ul className="list-disc pl-5">
    <LI><Strong>Account:</Strong> name, email, password (stored only as a salted hash), role — to create your account and sign you in. Lawful basis: performance of a contract.</LI>
    <LI><Strong>Orders and delivery:</Strong> basket, order history, delivery address, chosen window, driver assigned — to fulfil your order. Contract.</LI>
    <LI><Strong>Location:</Strong> only if you tap "Share my location", so the driver can find you. Consent — you can revoke it in Settings.</LI>
    <LI><Strong>Payments:</Strong> the method, amount and a provider reference. Card numbers are handled by the payment provider, never by us. Contract.</LI>
    <LI><Strong>Documents and photographs:</Strong> images a staff account uploads of invoices, delivery dockets or stock sheets, and driver documents (licence, insurance, ID) — to run stock, accounts and driver checks. Legitimate interests; documents are reviewed by a human.</LI>
    <LI><Strong>Chat:</Strong> messages you send in order and staff channels, visible to the people in that channel — to deliver and support your order. Contract.</LI>
    <LI><Strong>Alerts and preferences:</Strong> which optional notifications you switched on. Consent — switch them off any time in Alerts.</LI>
    <LI><Strong>Technical:</Strong> device and log data needed to keep the service working and secure. Legitimate interests.</LI>
   </ul>
  </Card>
  <Card>
   <Strong>AI processing.</Strong>
   <P>When you use the assistant, or when the shop scans a supplier document, the text or image is sent to an AI model provider through our gateway to produce the answer or the extracted rows. AI answers are generated, not written by a person. We do not use your data to train third-party models, and we do not send your payment details to AI systems.</P>
  </Card>
  <Card>
   <Strong>Who we share it with.</Strong>
   <P>Our hosting and database provider (Render, EU region), our website host (Vercel), our payment providers (Stripe for card, Apple Pay and Google Pay; PayPal), our AI model gateway, and our delivery drivers — only what each needs. We do not sell your personal data.</P>
  </Card>
  <Card>
   <Strong>How long we keep it.</Strong>
   <P>Account and order records: 6 years after your last order, to meet Irish tax and company law. Driver documents: 12 months after the driver relationship ends. Chat: 24 months. Alerts: until you switch them off or delete your account. Location: overwritten each time you share it.</P>
  </Card>
  <Card>
   <Strong>Your rights.</Strong>
   <P>Access, correction, erasure, restriction, portability, objection, and withdrawal of consent. Email {LEGAL.privacyEmail} and we will answer within one month. You can also complain to the {LEGAL.dpa}.</P>
  </Card>
  <Card>
   <Strong>Cookies and device storage.</Strong>
   <P>We do not use advertising cookies or third-party trackers. We store your sign-in, basket and preferences in your device's local storage, and a service worker caches the app so it opens offline — these are strictly necessary, so no consent banner is required. Clearing your browser or app data removes them.</P>
  </Card>
  <Card>
   <Strong>Security, children and accessibility.</Strong>
   <P>Traffic is encrypted in transit and passwords are hashed. Accounts are for people aged 18 or over; we do not knowingly collect data from children. We work to keep the app usable with screen readers and at high contrast, in line with the European Accessibility Act.</P>
  </Card>
  <div className="text-center text-white/70 text-[10px] mt-4 mb-2">{COPYRIGHT}</div>
 </div></Shell>);

export const AccessibilityPage=()=>(
 <Shell back="/legal"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Accessibility</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>Our accessibility statement, {LEGAL.updated}</p>
  <Card>
   <Strong>Our commitment.</Strong>
   <P>{LEGAL.company} wants everyone to be able to shop with us, including people using screen readers, magnification, voice control or switch access. Since 28 June 2025 the European Accessibility Act applies to online shops in Ireland, and we treat it as a floor rather than a target.</P>
  </Card>
  <Card>
   <Strong>What we have done.</Strong>
   <ul className="list-disc pl-5">
    <LI>Text and background colours are checked against WCAG 2.2 contrast ratios — body copy meets AAA (7:1) and graphics meet 3:1.</LI>
    <LI>Buttons, links and status messages are labelled for screen readers, and status is never signalled by colour alone.</LI>
    <LI>The layout is a single column with 44px minimum touch targets, and it reflows without horizontal scrolling.</LI>
    <LI>Motion is reduced automatically if your device asks for it.</LI>
    <LI>Allergen and price information is given as text, not only in images.</LI>
   </ul>
  </Card>
  <Card>
   <Strong>Known limitations.</Strong>
   <P>Product photographs are supplied by manufacturers and may not describe the item in words — the written name, price and allergen line are the authoritative information. Some supplier documents scanned by staff are photographs and may be unreadable to a screen reader until a person confirms the extracted rows. Delivery-window capacity changes live, so the slot count can change between reading and ordering.</P>
  </Card>
  <Card>
   <Strong>Tell us about a problem.</Strong>
   <P>Email {LEGAL.email} with the screen and what happened. We aim to reply within 5 working days and will offer the information or the order by another route — phone or in person — in the meantime. If you are not satisfied you can contact the CCPC, which handles accessibility complaints for services under the European Accessibility Act.</P>
  </Card>
  <div className="text-center text-white/70 text-[10px] mt-4 mb-2">{COPYRIGHT}</div>
 </div></Shell>);

export const DeleteAccountPage=()=>{
 const{user}=useApp();const[done,setDone]=useState(false);const[busy,setBusy]=useState(false);const[err,setErr]=useState('');
 const ask=async()=>{setBusy(true);setErr('');try{const r:any=await api.account.deleteRequest(user);if(r&&r.ok===false){setErr((r&&r.error)||'Could not send it.')}else{setDone(true)}}catch(e){setErr('Could not send it — try again.')}setBusy(false)};
 return(<Shell back="/legal"><div className="px-4 pt-3">
  <h1 className="font-display text-white text-2xl font-bold mb-1" data-reveal>Delete your account</h1>
  <p className="text-white/70 text-xs mb-4" data-reveal>You can leave at any time, and take your data with you.</p>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <b className="text-sm block mb-1">In the app</b>
   <div className="text-[12px] text-gray-700 mb-2">Tap the button below while signed in. We confirm by email and delete within 30 days.</div>
   {done?<div className="rounded-xl px-3 py-2 text-[12px]" style={{background:'rgba(11,107,79,.12)',border:'1px solid rgba(11,107,79,.4)',color:'#0B6B4F'}}>Request received for <b>{user}</b>. You will get a confirmation by email.</div>
    :<button onClick={ask} disabled={busy} className="w-full py-3 rounded-xl font-bold text-white" style={{background:busy?'#6f6f92':'#8a2d1f'}}>{busy?'Sending…':'Request deletion of my account'}</button>}
   {!!err&&<div className="text-[11px] mt-2" style={{color:'#8a2d1f'}}>{err}</div>}
  </div>
  <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
   <b className="text-sm block mb-1">By email instead</b>
   <div className="text-[12px] text-gray-700">Write to privacy@kingdomorganics.ie from the address on the account and ask for deletion. This is the same route for anyone who cannot sign in.</div>
  </div>
  <div className="card-white p-4 shadow-lg" data-reveal>
   <b className="text-sm block mb-1">What is deleted, and what we must keep</b>
   <div className="text-[12px] text-gray-700">Deleted: your account, basket, saved addresses, alert preferences and chat messages.<br/>Kept: order and invoice records for six years, because Irish tax and company law require it. They are kept securely and used only for that.</div>
  </div>
 </div></Shell>);};
