export type Product={id:string;name:string;sub:string;price:number;img:string;cat:string;tags:string[];organic?:boolean;allergens?:string[]};
export type Store={id:string;name:string;kind:string;live:boolean;rating:number;distance:string;image:string;banner:string;tagline:string;accent:string;short:string};
export type NavItem={to:string;icon:string;label:string};

export type Cat={id:string;title:string;poster:string;tile:string;zoom:number;pos:string;bright:number;sat?:number;fit?:string;aspect?:string;filters:string[]};

export const CATEGORIES:Cat[]=[
 {id:'meat',title:'Meats',poster:'/assets/cat-meat-tile.webp',tile:'/assets/cat-meat-grid.webp',zoom:1,pos:'16% 15%',bright:1,filters:['All','Beef','Lamb','Poultry','Fish','Frozen Meats']},
 {id:'rice',title:'Rice & Grains',poster:'/assets/cat-rice-tile.webp',tile:'/assets/cat-rice-grid.webp',zoom:1.0,pos:'50% 50%',bright:1,filters:['All','Rice','Wheat','Pulses','Grains']},
 {id:'spices',title:'Oriental Spices & Special Oils',poster:'/assets/cat-spices-tile.webp',tile:'/assets/cat-spices-grid.webp',zoom:1.0,pos:'50% 50%',bright:1,filters:['All','Spices','Oils','Nuts','Pastes']},
 {id:'produce',title:'Organic Vegetable Produce',poster:'/assets/cat-produce-tile.webp',tile:'/assets/cat-produce-grid.webp',zoom:1.0,pos:'50% 50%',bright:1,filters:['All','Vegetables','Fruits','Herbs','Salads']},
 {id:'beans',title:'Beans, Seeds & African Specialty',poster:'/assets/cat-beans-tile.webp',tile:'/assets/cat-beans-grid.webp',zoom:1.04,pos:'50% 50%',bright:1,filters:['All','Beans','Seeds','Pulses','Grains']},
 {id:'dairy',title:'Dairy & Milk Products',poster:'/assets/cat-dairy-tile.webp',tile:'/assets/cat-dairy-grid.webp',zoom:1,pos:'50% 50%',bright:1,sat:2.2,fit:'contain',aspect:'4/3',filters:['All','Milk','Cheese','Yogurt','Butter']}
];

export const PRODUCTS:Product[]=[
 {id:'p1',name:'Basmati Rice',sub:'Aromatic & Aged Rice',price:2.90,img:'/assets/products/c1.png',cat:'rice',tags:['Rice'],organic:true},
 {id:'p2',name:'Organic Wheat Groats',sub:'High in Fiber & Protein',price:2.90,img:'/assets/products/r-wheat.webp',cat:'rice',tags:['Wheat'],organic:true,allergens:['Cereals containing gluten']},
 {id:'p3',name:'Organic Verde Rice',sub:'Whole Grain & Gluten-Free',price:2.90,img:'/assets/products/r-verde.webp',cat:'rice',tags:['Rice'],organic:true},
 {id:'p4',name:'Bulgur Wheat',sub:'Cracked Wheat',price:2.90,img:'/assets/products/r-bulgur.webp',cat:'rice',tags:['Grains','Wheat'],organic:true,allergens:['Cereals containing gluten']},
 {id:'b1',name:'Chicken Breast',sub:'Free-Range & Organic',price:3.90,img:'/assets/products/b1.png',cat:'meat',tags:['Poultry'],organic:true},
 {id:'b2',name:'Lamb Rack Chops',sub:'Grass-Fed & Organic',price:3.90,img:'/assets/products/b2.png',cat:'meat',tags:['Lamb'],organic:true},
 {id:'b3',name:'Beef Mince',sub:'Grass-Fed & Organic',price:3.90,img:'/assets/products/b3.png',cat:'meat',tags:['Beef'],organic:true},
 {id:'b4',name:'Sea Bream (Halal)',sub:'Fresh Whole Fish',price:4.50,img:'/assets/products/b4.png',cat:'meat',tags:['Fish'],organic:true,allergens:['Fish']},
 {id:'c1',name:'Royal Saffron',sub:'Premium Saffron Threads',price:6.90,img:'/assets/products/o3.png',cat:'spices',tags:['Spices'],organic:true},
 {id:'c2',name:'Turmeric Powder',sub:'Cold Ground',price:3.90,img:'/assets/products/o1.png',cat:'spices',tags:['Spices'],organic:true},
 {id:'c3',name:'Ceylon Cinnamon',sub:'Rolled Sticks',price:4.90,img:'/assets/products/o2.png',cat:'spices',tags:['Spices'],organic:true},
 {id:'c4',name:'Garam Masala',sub:'House Blend',price:4.90,img:'/assets/products/o4.png',cat:'spices',tags:['Spices'],organic:true},
 {id:'o1',name:'Baby Spinach',sub:'Fresh & Organic',price:3.90,img:'/assets/products/p1.png',cat:'produce',tags:['Vegetables'],organic:true},
 {id:'o2',name:'Vine Tomatoes',sub:'Greenhouse Grown',price:3.90,img:'/assets/products/p2.png',cat:'produce',tags:['Vegetables','Salads'],organic:true},
 {id:'o3',name:'Medjool Dates',sub:'Naturally Sweet',price:5.90,img:'/assets/products/p3.png',cat:'produce',tags:['Fruits'],organic:true},
 {id:'o4',name:'Fresh Mint',sub:'Cut Daily',price:2.90,img:'/assets/products/p4.png',cat:'produce',tags:['Herbs'],organic:true},
 {id:'d1',name:'Farm Milk 1L',sub:'Whole & Pasteurised',price:2.40,img:'/assets/products/d1.webp',cat:'dairy',tags:['Milk'],organic:true,allergens:['Milk']},
 {id:'d2',name:'Aged Cheddar',sub:'12-Month Matured',price:5.40,img:'/assets/products/d2.webp',cat:'dairy',tags:['Cheese'],organic:true,allergens:['Milk']},
 {id:'d3',name:'Greek Yogurt',sub:'Thick & Creamy',price:3.20,img:'/assets/products/d3.webp',cat:'dairy',tags:['Yogurt'],organic:true,allergens:['Milk']},
 {id:'d4',name:'Free-Range Eggs ×12',sub:'Large Brown Eggs',price:4.10,img:'/assets/products/d4.webp',cat:'dairy',tags:['Butter & Eggs'],organic:true,allergens:['Egg']}
];

// Home quick category pill shortcuts + store quick shortcuts
export const QUICK_PILLS=[{label:'Vegetables',cat:'produce'},{label:'Fruits',cat:'produce'},{label:'Grains',cat:'rice'},{label:'Spices',cat:'spices'}];
export const STORE_SHORTCUTS=[{label:'Tralee Supermarket',store:'kingdom'},{label:"Terry's Butchers Asian Market",store:'terry'},{label:'Kingdom Food & Manna Organic Store',store:'manna'}];

export const STORES:Store[]=[
 {id:'kingdom',name:'Kingdom Organics',kind:'HALAL SHOP • ORGANIC ORIENTAL & LOCAL ITEMS',live:true,rating:4.8,distance:'0.5 km',image:'/assets/logo-official.webp',banner:'/assets/kingdom-poster.webp',tagline:'Organic, halal & locally sourced',accent:'#C9A227',short:'Kingdom Organics'},
 {id:'yousef',name:"Yousef's Spice",kind:'HALAL SHOP • ORIENTAL & LOCAL ITEMS',live:true,rating:4.6,distance:'1.2 km',image:'/assets/poster-spices.webp',banner:'/assets/store-hero-spice.png',tagline:'Oriental organic products & halal butcher',accent:'#E8960F',short:"Yousef's Spice"},
 {id:'terry',name:"Terry's Butchers Asian Market",kind:'HALAL BUTCHER • ASIAN MARKET',live:true,rating:4.7,distance:'2.0 km',image:'/assets/poster-butcher.webp',banner:'/assets/bg-butcher.jpg',tagline:'Premium halal cuts & Asian pantry',accent:'#B91C1C',short:"Terry's Butchers"},
 {id:'manna',name:'Kingdom Food & Manna Organic Store',kind:'ORGANIC • HEALTH FOOD',live:true,rating:4.5,distance:'2.4 km',image:'/assets/poster-produce.webp',banner:'/assets/produce-bg.jpg',tagline:'Wholefoods, organic & pantry',accent:'#059669',short:'Kingdom Food & Manna'},
 {id:'kerry',name:'Kerry Dairy',kind:'PENDING PARTNER',live:false,rating:0,distance:'3.0 km',image:'/assets/poster-dairy.webp',banner:'/assets/templates/template-dairy.jpg',tagline:'Dairy & milk products',accent:'#2563EB',short:'Kerry Dairy'},
 {id:'aran',name:'Aran Bakery',kind:'PENDING PARTNER',live:false,rating:0,distance:'2.5 km',image:'/assets/poster-rice-grains.webp',banner:'/assets/templates/template-rice.jpg',tagline:'Bakery & grains',accent:'#D97706',short:'Aran Bakery'},
 {id:'atlantic',name:'Atlantic Fish',kind:'PENDING PARTNER',live:false,rating:0,distance:'4.0 km',image:'/assets/poster-butcher.webp',banner:'/assets/bg-produce.jpg',tagline:'Fresh fish & seafood',accent:'#0E7490',short:'Atlantic Fish'}
];

// Partner store card set for Home
export const PARTNER_STORES=[
 {id:'kingdom',name:'Kingdom Organics',desc:'Tralee & Killarney’s independent grocers',note:'2 live now, 20 invited and pending reply',image:'/assets/kingdom-poster.webp'},
 {id:'yousef',name:"Yousef's Spice",desc:'Asian Market',image:'/assets/store-hero-spice.png'},
 {id:'terry',name:"Terry's Butchers",desc:'Wine & more',image:'/assets/poster-butcher.webp'},
 {id:'manna',name:'Kingdom Food & Manna',desc:'Organic Store',image:'/assets/poster-produce.webp'}
];

export const LIVE_NOW=[
 {name:'Tralee Supermarket',img:'/assets/store-hero-supermarket.png',food:'Serving 2 live stores'},
 {name:"Yousef's Spice Asian Market",img:'/assets/store-hero-spice.png',food:'Organic oriental items'}
];

export const IN_TALKS=[
 {name:"Terry's Butchers Wine",img:'/assets/poster-butcher.webp'},
 {name:'Kingdom Food & Wine',img:'/assets/bg-spices.jpg'},
 {name:'Manna Organic Stores',img:'/assets/poster-produce.webp'},
 {name:'Kerry Dairy Co-op',img:'/assets/poster-dairy.webp'},
 {name:'Aran Bakery',img:'/assets/poster-rice-grains.webp'}
];

// Store-specific inventory (subset of PRODUCTS per store)
export const STORE_INVENTORY:Record<string,string[]>={
 kingdom:['p1','p2','b1','b2','o1','o2','d1','d2'],
 yousef:['c1','c2','c3','c4','p3','p4','b3','b4'],
 terry:['b1','b2','b3','b4','c1','c2'],
 manna:['o1','o2','o3','o4','p1','p4','d3'],
 kerry:['d1','d2','d3','d4'],
 aran:['p1','p2','p3','p4'],
 atlantic:['b1','b2','b3','b4']
};

// Role-aware bottom navigation
export const NAV_BY_ROLE:Record<string,NavItem[]>={
 customer:[{to:'/home',icon:'⌂',label:'Home'},{to:'/cats',icon:'▦',label:'Categories'},{to:'/cart',icon:'🛒',label:'Cart'},{to:'/search',icon:'🔍',label:'Search'}],
 admin:[{to:'/dashboard',icon:'▦',label:'Dashboard'},{to:'/finances',icon:'€',label:'Finances'},{to:'/my-store',icon:'⌂',label:'Store View'}],
 driver:[{to:'/driver',icon:'🛵',label:'Runs'},{to:'/active',icon:'📍',label:'Active'},{to:'/earnings',icon:'€',label:'Earnings'},{to:'/channel',icon:'💬',label:'Chat'}]
};

// Admin upload simulation data
export const ADMIN_DATA={
 pendingOrders:[{id:'ORD-101',store:'kingdom',items:3,total:12.50,status:'Preparing',customer:'Alice M.'},{id:'ORD-102',store:'yousef',items:2,total:8.90,status:'Pending',customer:'Bob K.'}],
 recentUploads:[{name:'inventory-sept.csv',date:'2026-09-05',status:'Parsed',items:45},{name:'prices-update.xlsx',date:'2026-09-04',status:'Applied',items:12}]
};

// Driver KYC simulation data
export const DRIVER_DATA={
 kycStatus:'verified',
 vehicle:{type:'Van',plate:'261-G-1234',year:2022},
 earnings:{today:45.50,week:280.00,month:1120.00},
 deliveries:[{id:'DEL-201',store:'kingdom',status:'In Transit',eta:'15 min',address:'12 Main St'},{id:'DEL-202',store:'yousef',status:'Pending Pickup',eta:'--',address:'5 Market Rd'}]
};

// ---- Distributor ledger: items, dates, prices, spend (feeds AI Accountant + Deals) ----
export type DistLine={name:string;qty:number;unit:string;price:number};
export type DistOrder={id:string;supplier:string;category:string;date:string;invoice:string;status:string;lines:DistLine[]};
export const DIST_ORDERS:DistOrder[]=[
 {id:'PO-2201',supplier:'Halal Meats Co.',category:'meat',date:'2026-09-05',invoice:'INV-2201',status:'paid',lines:[
   {name:'Grass-fed Beef Box',qty:10,unit:'box',price:42.00},
   {name:'Lamb Rack Chops',qty:8,unit:'kg',price:38.50},
   {name:'Chicken Breast',qty:12,unit:'kg',price:18.90}]},
 {id:'PO-2202',supplier:'Oriental Oils Ltd',category:'spices',date:'2026-09-04',invoice:'INV-8814',status:'paid',lines:[
   {name:'Cold-Pressed Black Seed Oil',qty:24,unit:'btl',price:6.20},
   {name:'Tahini Paste',qty:18,unit:'jar',price:4.10},
   {name:'Pekmez',qty:15,unit:'jar',price:3.80}]},
 {id:'PO-2203',supplier:'Kerry Produce',category:'produce',date:'2026-09-03',invoice:'INV-3390',status:'due',lines:[
   {name:'Vine Tomatoes',qty:30,unit:'kg',price:2.10},
   {name:'Baby Spinach',qty:20,unit:'kg',price:3.40},
   {name:'Sweet Oranges',qty:25,unit:'kg',price:1.90}]},
 {id:'PO-2204',supplier:'Grains Direct',category:'rice',date:'2026-09-01',invoice:'INV-1120',status:'paid',lines:[
   {name:'Basmati Rice 25kg',qty:6,unit:'sack',price:28.90},
   {name:'Bulgur Wheat',qty:10,unit:'kg',price:1.75}]},
 {id:'PO-2205',supplier:'Creamery West',category:'dairy',date:'2026-08-30',invoice:'INV-7741',status:'due',lines:[
   {name:'Farm Milk 1L',qty:48,unit:'btl',price:0.95},
   {name:'Aged Cheddar',qty:8,unit:'kg',price:7.40},
   {name:'Greek Yogurt',qty:24,unit:'tub',price:1.60}]}
];
export const distTotal=(o:DistOrder)=>o.lines.reduce((s,l)=>s+l.qty*l.price,0);
export const DIST_SPEND:Record<string,number>=DIST_ORDERS.reduce((a,o)=>{a[o.supplier]=(a[o.supplier]||0)+distTotal(o);return a},{} as Record<string,number>);

// ---- Driver earnings (driver finances) ----
export type Delivery={id:string;store:string;area:string;km:number;fee:number;tip:number;status:string;time:string};
export const DRIVER_DELIVERIES:Delivery[]=[
 {id:'D-4471',store:'Kingdom Organics',area:'Tralee Town',km:3.2,fee:6.50,tip:1.50,status:'delivered',time:'09:20'},
 {id:'D-4472',store:"Yousef Spice",area:'Oakpark',km:4.8,fee:7.00,tip:2.00,status:'delivered',time:'10:05'},
 {id:'D-4473',store:'Kingdom Organics',area:'Ballymullen',km:2.1,fee:5.50,tip:0,status:'delivered',time:'11:10'},
 {id:'D-4474',store:'Kerry Produce',area:'Manor West',km:6.4,fee:8.50,tip:1.00,status:'active',time:'12:00'},
 {id:'D-4475',store:'Kingdom Organics',area:'Clash',km:5.0,fee:7.50,tip:0,status:'queued',time:'12:40'}
];
export const driverFees=(d:Delivery)=>d.fee+d.tip;

