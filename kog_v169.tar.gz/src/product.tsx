import React,{useState} from 'react';
import {Shell,go,useApp} from './App';
import {PRODUCTS,CATEGORIES} from './lib/data';

const POS:Record<string,string>={Organic:'#0B6B4F',Halal:'#0B6B4F',Vegan:'#0B6B4F','Gluten-Free':'#0B6B4F','High Fibre':'#0B6B4F','No Added Sugar':'#0B6B4F',Fresh:'#0B6B4F'};
const tagColour=(t:string)=>{const k=Object.keys(POS).find(p=>t.toLowerCase().indexOf(p.toLowerCase())>=0);return k?POS[k]:'#2A00D6';};

export const ProductPage=({id}:{id:string})=>{
 const{add,cart}=useApp();
 const p=PRODUCTS.find(x=>x.id===id);
 const[q,setQ]=useState(1);
 if(!p)return(<Shell back="/home"><div className="px-4 pt-3"><div className="card-white p-4 text-[12px] text-gray-700">That product is not in the catalogue.</div></div></Shell>);
 const allergens:any=(p as any).allergens||[];
 const dietary:string[]=(p as any).tags||[];
 const cat=CATEGORIES.find(c=>c.id===p.cat);
 const nutrition:any=(p as any).nutrition||null;
 const row=(k:string,v:any)=>(<div key={k} className="flex justify-between py-1.5 border-b last:border-0 text-sm"><span>{k}</span><b>{v}</b></div>);
 return(<Shell back={'/cat/'+p.cat}>
  <div className="relative" style={{aspectRatio:'1.15'}}>
   <img src={p.img} alt={p.name} className="absolute inset-0 w-full h-full object-cover"/>
   <div className="absolute top-3 right-3 flex items-center gap-2 rounded-2xl px-3 py-2 shadow-lg" style={{background:'rgba(249,247,242,.92)'}}>
    <button onClick={()=>setQ(Math.max(1,q-1))} className="size-7 rounded-full font-bold" style={{background:'rgba(0,1,87,.08)'}}>−</button>
    <span className="text-[13px] font-bold min-w-[3.2rem] text-center">{q} {p.unit||'each'}</span>
    <button onClick={()=>setQ(q+1)} className="size-7 rounded-full font-bold" style={{background:'rgba(0,1,87,.08)'}}>+</button>
   </div>
  </div>
  <div className="px-4 pt-3">
   <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
    <div className="flex items-start justify-between gap-3">
     <div><h1 className="font-display text-xl font-bold">{p.name}</h1><div className="text-[12px] text-gray-700">{p.sub}</div></div>
     <div className="text-right"><div className="font-display text-xl font-bold">{'€'}{p.price.toFixed(2)}</div><div className="text-[10px] text-gray-600">{p.unit?'per '+p.unit:''}</div></div>
    </div>
    <div className="flex flex-wrap gap-1.5 mt-3">
     {p.organic&&<span className="text-[10px] font-bold px-2 py-1 rounded-full" style={{background:'rgba(11,107,79,.14)',color:'#0B6B4F'}}>ORGANIC</span>}
     {[['meat','HALAL'],['dairy','FRESH DAILY']].map(([c,lab])=>p.cat===c?(<span key={lab} className="text-[10px] font-bold px-2 py-1 rounded-full" style={{background:'rgba(11,107,79,.14)',color:'#0B6B4F'}}>{lab}</span>):null)}
     {dietary.map(t=>(<span key={t} className="text-[10px] font-bold px-2 py-1 rounded-full" style={{background:'rgba(42,0,214,.10)',color:'#1b1146'}}>{String(t).toUpperCase()}</span>))}
    </div>
    {!!nutrition&&!!nutrition.kcal&&<div className="flex gap-4 mt-3 pt-3 border-t text-[12px]"><span><b>{nutrition.kcal}</b> kcal / 100 g</span>{nutrition.protein?<span>Protein <b>{nutrition.protein}</b></span>:null}{nutrition.fat?<span>Fat <b>{nutrition.fat}</b></span>:null}</div>}
   </div>
   <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
    <b className="text-sm block mb-1">Description</b>
    <div className="text-[12px] leading-relaxed" style={{color:'#374151'}}>{p.desc||(p.name+' \u2014 '+(p.sub||'')+'. Sold by Kingdom Organics'+(cat?(' in the '+cat.title.toLowerCase()+' range'):'')+'. Ask us anything about this item and we will answer before you buy.')}</div>
   </div>
   <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
    <b className="text-sm block mb-2">Allergens</b>
    {allergens.length?allergens.map((a:string)=>(<div key={a} className="flex items-center gap-2 py-1.5 border-b last:border-0"><span className="size-2.5 rounded-full" style={{background:'#C2410C'}}/><span className="text-[12px] font-semibold">Contains {a}</span></div>))
     :<div className="flex items-center gap-2 py-1.5"><span className="size-2.5 rounded-full" style={{background:'#0B6B4F'}}/><span className="text-[12px] font-semibold">No declared allergens</span></div>}
    <div className="mt-2 rounded-xl px-3 py-2 text-[11px]" style={{background:'rgba(232,150,15,.12)',border:'1px solid rgba(232,150,15,.45)',color:'#7a3f05'}}>Handled in a shop that also sells nuts, sesame, cereals, milk, egg and fish. Always check the pack on arrival. If you have a severe allergy, contact us before ordering.</div>
   </div>
   <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
    <b className="text-sm block mb-2">Nutrition</b>
    <b className="text-sm block mb-2">{'Nutrition'}</b>
    {nutrition?<div>{['kcal','protein','carbohydrate','ofWhichSugars','fat','ofWhichSaturates','fibre','salt'].filter(k=>nutrition[k]!=null).map(k=>row(({kcal:'Energy (kcal)',protein:'Protein',carbohydrate:'Carbohydrate',ofWhichSugars:'of which sugars',fat:'Fat',ofWhichSaturates:'of which saturates',fibre:'Fibre',salt:'Salt'} as any)[k],nutrition[k]))}<div className="text-[10px] text-gray-600 mt-1">Typical values per 100 g</div></div>
     :<div className="text-[12px]" style={{color:'#374151'}}>Nutrition figures for this line are supplied on the manufacturer's pack panel. We record them here as they are confirmed \u2014 ask us for this item and we will send a photograph of the panel before you buy.</div>}
   </div>
   <div className="card-white p-4 mb-3 shadow-lg" data-reveal>
    <b className="text-sm block mb-2">Food information</b>
    {row('Ingredients',(p as any).ingredients||(p.name+' ('+(p.sub||'')+')'))}
    {row('Country of origin',(p as any).origin||'Ask us \u2014 varies by delivery')}
    {row('Supplier',(p as any).supplier||'Listed in the shop ledger')}
    {row('Sold as',(p.unit?('per '+p.unit):'per item'))}
    {p.organic&&row('Certification','Organic \u2014 certificate on file')}
    {p.cat==='meat'&&row('Halal','Certified halal \u2014 certificate on file')}
   </div>
   <div className="flex gap-2 mb-6">
    <button onClick={()=>{for(let i=0;i<q;i++)add(p.id);go('/cart')}} className="flex-1 py-3 rounded-xl font-bold" style={{background:'#E8960F',color:'#1a1206'}}>Add {q} {'\u00b7'} {'€'}{(p.price*q).toFixed(2)}</button>
    <button onClick={()=>go('/chat')} className="px-4 py-3 rounded-xl font-semibold glass text-white">Ask</button>
   </div>
  </div>
 </Shell>);};
