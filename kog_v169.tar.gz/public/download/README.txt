Android APK goes in this folder.

Drop the built file here as:  kingdom-organics.apk
The "Get the app" screen checks for it and shows the download button only when it exists.
Built from the Expo project in ~/kog_expo (Android package ie.kingdomorganics.app).
