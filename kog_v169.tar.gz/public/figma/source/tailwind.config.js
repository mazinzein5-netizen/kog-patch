/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: {
      'ko-forest':'#0B2E28','ko-deep':'#0d2818','ko-emerald':'#07332B','ko-teal':'#0E6B5C','ko-brand':'#059669',
      'ko-harvest':'#E8960F','ko-amber':'#D97706','ko-gold':'#C9A227','ko-goldbright':'#E8C454','ko-bg':'#F9F7F2','ko-ink':'#111827','ko-purple':'#2D2A4A'
    },
    fontFamily: { display:['"Playfair Display"','serif'], body:['"DM Sans"','sans-serif'] },
    boxShadow: { glass:'0 8px 32px rgba(0,0,0,.25)', card:'0 4px 14px rgba(0,0,0,.08)', glow:'0 0 18px rgba(232,196,84,.55)' }
  }},
  plugins: []
}
