import subprocess, time, re
CWD = '/a0/usr/projects/commerce_websites_and_apps/phone-source'
def pcli(*a, t=150):
    r = subprocess.run(['playwright-cli'] + list(a), capture_output=True, text=True, cwd=CWD, timeout=t)
    return (r.stdout or '') + (r.stderr or '')
TS = int(time.time())
def show(tag, out):
    lines = [l for l in out.split('\n') if l.strip()]
    hits = [l for l in lines if re.search(r'185|Maximum update|Minified React|Uncaught|\berror\b', l, re.I)]
    print('--- ' + tag + ' | console_lines=' + str(len(lines)) + ' | hits=' + str(len(hits)))
    for l in hits[:12]:
        print('    ' + l[:190])
print(pcli('open', '--browser=chrome')[-300:])
routes = ['https://aura-grocery.vercel.app/?v=' + str(TS),
          'https://aura-grocery.vercel.app/#/home',
          'https://aura-grocery.vercel.app/#/cats',
          'https://aura-grocery.vercel.app/#/cart',
          'https://aura-grocery.vercel.app/#/login']
for u in routes:
    pcli('goto', u)
    time.sleep(5)
    tag = u.split('#')[-1] if '#' in u else 'root'
    show(tag, pcli('console'))
pcli('close')
print('PROBE_DONE')
