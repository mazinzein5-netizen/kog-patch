import { defineConfig } from 'vite'
import { reticle } from '@reticlehq/vite-plugin'
import react from '@vitejs/plugin-react'
export default defineConfig({ plugins: [reticle(), react()], build: { outDir: 'dist' } })
