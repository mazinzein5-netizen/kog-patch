# Visual editor for the Kingdom Organics app

Tap any element in the *real* running app, change its text, image, classes or styles,
press **Save**, and the change is written straight into the React source and hot-reloaded.

No separate design tool, no exported HTML mock-up, no drift between design and code.

---

## 1. Why not Flutter

The app is React + Vite + Tailwind (`src/App.tsx`, `src/features.tsx`, `src/shop.tsx`, …)
and the shipped Android build is the Expo project in `~/kog_expo`.
Rewriting it in Flutter would throw away a deployed PWA, an APK, the Expo app and the
design system, and Flutter has no on-device visual editor anyway (FlutterFlow is a separate
cloud product that would regenerate its own project). So the editor was built for the stack
that already exists, and it edits the same files the app is built from.

## 2. One thing that had to be fixed first

`src/App.tsx` imported `ChannelChat` and `PrivacyPage` twice (from `./features` **and**
from `./shop` / `./legal`). esbuild tolerated it in the production build, but Babel — which
the dev server uses — refused the file outright:

    Identifier 'ChannelChat' has already been declared

so `vite dev` could never serve this app. The duplicate names were removed from the
`./features` import: the routes use `<ChannelChat channel title sub/>`, which is
`shop.tsx`'s signature, and production already resolved `PrivacyPage` to `legal.tsx`
(its bundle never contained `features.tsx`'s "Privacy & Loyalty Terms" copy). The rebuilt
bundle has the **same hash as before** (`index-Djb6ZDhA.js`), so nothing about the deployed
app changed — the dev server simply works now.

## 3. Start it

```bash
cd ~/kog_react
npm run edit          # vite dev server on 0.0.0.0:8080
```

Then open, in any browser on the phone or on the same Wi-Fi:

    http://127.0.0.1:8080/?edit=1          (this phone)
    http://<phone-lan-ip>:8080/?edit=1     (another device)

Without `?edit=1` the dev server is a normal dev server — the editor never loads.

**How to use it**

1. Tap the orange ✎ button (bottom right) to turn edit mode on.
2. Tap the element you want to change. A label shows `Component › tag  src/App.tsx:55`.
3. Edit in the bottom sheet:
   * **Text** — the literal text of that element.
   * **Image source** — type a path or tap **Images** to pick from the 130+ files in `public/`.
   * **CSS classes / Add CSS classes** — Tailwind classes.
   * **Styles** — font size, weight, family, colours (with a colour picker), padding,
     margin, radius, border, shadow, letter spacing, line height, alignment, gap, opacity,
     transform.
4. **Save to source** writes the change into the `.tsx` file and reloads. **Undo** puts the
   previous version of that file back. **Reload** throws away a live preview.
5. Text that comes from data (product names, store copy, prices in `src/lib/data.ts`) shows
   a **Locate** button: it finds the literal in `src/` and links the field to it, so editing
   the field edits the data file.

## 4. What it actually does

* **`plugins/kog-visual.mjs`** — a Vite plugin (`apply: 'serve'`, so **never** part of a
  production build — verified: a build contains zero editor code). On every request it
  parses each `src/**/*.tsx` with Babel and stamps JSX elements with
  `data-ko='{"f","ln","col","tag","comp","txt","cls","clsx","sty","at"}' ` — the file,
  line/column and the exact **character ranges** of the editable text, `className`,
  `style` object and `src`/`alt`/`href`/`placeholder` attributes.
* **`plugins/kog-visual-client.js`** — the overlay that runs inside the page (shadow DOM,
  so app CSS cannot touch it). It reads those ranges, previews changes live on the DOM and
  posts them back.
* Routes: `/__ko/inspect|save|style|find|undo|assets|state`.

Because a save is a **text splice at known offsets**, the app source keeps its own
formatting (this codebase is written one-component-per-line; nothing reflows it).

## 5. Safety rails (all covered by `npm run edit:test`)

| Guard | Behaviour |
|---|---|
| **Stale offsets** | Every edit carries the text it expects to find. If the file moved on, the save is refused with a "stale" error instead of writing in the wrong place. |
| **Parse guard** | A splice is refused if it would introduce a syntax problem the file did not already have (pre-existing issues such as the duplicate `ChannelChat` import do not block editing). |
| **Backups** | The previous content of every touched file is kept in `.ko-backups/` (last 60), and **Undo** restores the newest one. |
| **Path scope** | Writes are only ever allowed inside `src/`, only for `.tsx/.jsx/.ts/.js/.css/.json`. |
| **Dev only** | The plugin runs only under `vite dev`; `npm run build` output is untouched. |

The editor only ever touches files you can also see in `git diff`, so any change can be
reviewed and reverted with git.

Editing then deploying is the normal flow — the visual editor is a faster way to produce
the same source change you would otherwise type:

```bash
npm run edit        # tap, edit, Save to source
npm run build       # verify
# deploy the build as usual (Vercel / deploy_root)
```

## 6. Commands

```bash
npm run edit        # start the dev server + editor      -> http://127.0.0.1:8080/?edit=1
npm run edit:test   # 18-check round trip against the running dev server (leaves src/ untouched)
npm run build       # production build — no editor code in it
npm run preview     # serve the built app
```

## 7. Files

| File | Role |
|---|---|
| `plugins/kog-visual.mjs` | Vite plugin: JSX source stamping, save/inspect/undo API |
| `plugins/kog-visual-client.js` | In-page overlay UI |
| `plugins/kog-visual.e2e.cjs` | Round-trip test suite (`npm run edit:test`) |
| `vite.config.ts` | registers the plugin |
| `.ko-backups/` | automatic per-file backups (git-ignored) |

## 8. Current limits / next steps

* Edits apply to JSX host elements. Text inside a component that renders from a variable is
  reached through **Locate** (it finds the literal in `src/`).
* Styling writes inline `style` props; it does not create Tailwind classes.
* The marketing site (`~/aura_grocery_repo/website`) is plain HTML and is not covered yet —
  the same plugin idea works there by stamping elements at build/serve time.
* The Expo app (`~/kog_expo`) is React Native and cannot be inspected through the DOM;
  share components stay in `src/lib` and `src/index.css` design tokens.
