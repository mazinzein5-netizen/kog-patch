/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: {
      'ko-forest':'var(--ko-forest)','ko-deep':'var(--ko-deep)','ko-emerald':'var(--ko-emerald)','ko-teal':'var(--ko-teal)','ko-brand':'var(--ko-brand)',
      'ko-harvest':'var(--ko-harvest)','ko-amber':'var(--ko-amber)','ko-gold':'var(--ko-gold)','ko-goldbright':'var(--ko-goldbright)','ko-bg':'var(--ko-bg)','ko-ink':'var(--ko-ink)','ko-purple':'var(--ko-purple)'
    },
    fontFamily: { display:['Comfortaa','sans-serif'], body:['"DM Sans"','sans-serif'] },
    boxShadow: { glass:'0 8px 32px rgba(0,0,0,.25)', card:'0 4px 14px rgba(0,0,0,.08)', glow:'0 0 18px rgba(232,196,84,.55)' }
  }},
  plugins: []
}
