#!/bin/bash
set -euo pipefail
cd /a0/usr/projects/commerce_websites_and_apps/phone-source
rm -rf deploy_root/website/src deploy_root/website/public
cp -r src deploy_root/website/src
cp -r public deploy_root/website/public
echo "SW=$(grep -o 'aura-v115' deploy_root/website/public/sw.js | head -1)"
echo "BUILD=$(grep -o "const BUILD='v115'" deploy_root/website/src/App.tsx)"
echo "CSS=$(grep -c 'GLOBAL LEGIBILITY' deploy_root/website/src/index.css)"
echo "PROJECT=$(grep -o 'prj_[A-Za-z0-9]*' deploy_root/.vercel/project.json | head -1)"
cd deploy_root
vercel deploy --prod --yes 2>&1 | tail -25
