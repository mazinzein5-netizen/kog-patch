#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd ~/kog_react
for f in index.html package.json postcss.config.cjs tailwind.config.js vercel.json; do
  cp -f "$f" deploy_root/website/
done
rm -rf deploy_root/website/src deploy_root/website/public
cp -r src deploy_root/website/src
cp -r public deploy_root/website/public
# NOTE: deploy_root/website/vite.config.ts stays the plain react-only config
# (the repo copy imports plugins/kog-visual.mjs which is a dev-only visual editor).
cd deploy_root && vercel deploy --prod --yes
