import subprocess, time
CWD = '/a0/usr/projects/commerce_websites_and_apps/phone-source'
OUT = '/a0/usr/projects/commerce_websites_and_apps/probe185.out'
L = open(OUT, 'w')
def w(s):
    L.write(str(s) + chr(10)); L.flush()
def pcli(*a, t=200):
    try:
        r = subprocess.run(['playwright-cli'] + list(a), capture_output=True, text=True, cwd=CWD, timeout=t)
        return (r.stdout or '') + (r.stderr or '')
    except Exception as e:
        return 'EXC ' + str(e)
w('OPEN ' + pcli('open')[-240:])
w('RESIZE ' + pcli('resize', '390', '844')[-100:])
w('GOTO ' + pcli('goto', 'https://aura-grocery.vercel.app/?v=185p')[-240:])
time.sleep(4)
w('STORAGE ' + pcli('eval', "(function(){var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);o[k]=String(localStorage.getItem(k)).slice(0,40)}return JSON.stringify(o)})()")[-900:])
for r in ['#/home', '#/cats', '#/cart', '#/profile', '#/login']:
    pcli('goto', 'https://aura-grocery.vercel.app/' + r)
    time.sleep(5)
    w('CONSOLE ' + r + ' ' + pcli('console')[-900:])
pcli('close')
w('PROBE_DONE')
L.close()
