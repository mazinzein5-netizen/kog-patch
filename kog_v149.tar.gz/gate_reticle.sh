#!/usr/bin/env bash
# Reticle gate for Kingdom Organics frontend builds.
#
# PURPOSE
#   Prove that the app under test ACTUALLY ATTACHED to the Reticle bridge.
#   A bare exit 0 from Reticle is NOT proof, and neither is a bare exit 1.
#   `reticle verify` exits 1 in two completely different situations:
#       exit 1 + "No saved flows to verify"  -> nothing wrong, nothing checked
#       exit 1 + "No app connected"          -> the app never dialled back
#   So the EXIT CODE CANNOT BE USED as an attachment assertion. The only
#   reliable discriminator is stdout:
#       contains session_connected  -> app attached        (PASS)
#       contains No app connected   -> app never attached  (FAIL)
#
# USAGE
#   ./gate_reticle.sh                  gate the local dev server
#   ./gate_reticle.sh <url>            gate any url (use for negative control)
#   PORT=5199 TIMEOUT=90 ./gate_reticle.sh
#
# EXIT CODES
#   0  attached        (gate PASS)
#   1  not attached    (gate FAIL)
#   2  setup error     (no binary, or dev server never came up)

set -u

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR" || { echo "SETUP_ERROR cannot cd to $PROJECT_DIR"; exit 2; }

PORT="${PORT:-5199}"
TIMEOUT="${TIMEOUT:-90}"
URL="${1:-http://localhost:${PORT}/}"
RETICLE="./node_modules/.bin/reticle"
STAMP="$(date +%Y%m%d-%H%M%S)"
LOG="/tmp/reticle_gate_${STAMP}.log"
VITELOG="/tmp/reticle_gate_vite_${STAMP}.log"
STARTED_VITE=0

if [ ! -x "$RETICLE" ]; then
  echo "SETUP_ERROR reticle binary not executable at $RETICLE"
  exit 2
fi

# Cleanup resolves the real listener through ss, because `nohup npx vite ... &`
# makes $! the npx wrapper pid and killing $! leaves vite running.
free_port() {
  local p="$1"
  local pids
  pids=$(ss -ltnp 2>/dev/null | grep ":${p}" | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u)
  for pid in $pids; do kill "$pid" 2>/dev/null; done
  pkill -f "vite --port ${p}" 2>/dev/null
}

cleanup() {
  if [ "$STARTED_VITE" = "1" ]; then
    free_port "$PORT"
    sleep 1
  fi
}
trap cleanup EXIT INT TERM

BOOTED_LOCAL=0
if [ "$URL" = "http://localhost:${PORT}/" ]; then
  BOOTED_LOCAL=1
fi

if [ "$BOOTED_LOCAL" = "1" ]; then
  echo "RETICLE_GATE start  port=${PORT} timeout=${TIMEOUT}s"
  free_port "$PORT"
  sleep 1
  echo "  port ${PORT} listeners before start: $(ss -ltnp 2>/dev/null | grep -c ":${PORT}")"

  nohup npx vite --port "$PORT" --strictPort > "$VITELOG" 2>&1 &
  STARTED_VITE=1

  up=0
  for _ in $(seq 1 45); do
    if curl -sf -o /dev/null "http://localhost:${PORT}/" 2>/dev/null; then up=1; break; fi
    sleep 1
  done
  if [ "$up" != "1" ]; then
    echo "SETUP_ERROR dev server never answered on :${PORT}"
    echo "  --- vite log ---"
    tail -20 "$VITELOG" 2>/dev/null
    exit 2
  fi
  echo "  dev server up, http=$(curl -s -o /dev/null -w '%{http_code}' "http://localhost:${PORT}/")"

  sdk=$(curl -s "http://localhost:${PORT}/" 2>/dev/null | grep -c -i 'reticle-connect')
  echo "  sdk marker in served html: ${sdk}"
  if [ "$sdk" = "0" ]; then
    echo "  note: no SDK marker in HTML, so the app cannot attach. If the plugin was"
    echo "  added after this dev server started, restart it - HMR is not enough."
  fi
else
  echo "RETICLE_GATE start  url=${URL} timeout=${TIMEOUT}s (external url, no dev server)"
fi

echo "  --- reticle verify output ---"
timeout $((TIMEOUT + 60)) "$RETICLE" verify "$URL" --timeout "$TIMEOUT" > "$LOG" 2>&1
RC=$?
cat "$LOG"

ATTACHED=0
NOTCONN=0
FLOWS_EMPTY=0
if grep -q 'session_connected' "$LOG" 2>/dev/null; then ATTACHED=1; fi
if grep -qi 'No app connected' "$LOG" 2>/dev/null; then NOTCONN=1; fi
if grep -qi 'No saved flows to verify' "$LOG" 2>/dev/null; then FLOWS_EMPTY=1; fi

SID=$(sed -n 's/.*sessionId":"\([^"]*\)".*/\1/p' "$LOG" 2>/dev/null | head -1)

 echo ""
echo "  ----------------------------------------------------------------"
echo "  verify exit code        : ${RC}"
echo "    (not a pass/fail signal - see header of this script)"
echo "  session_connected seen  : ${ATTACHED}"
echo "  No-app-connected seen   : ${NOTCONN}"
echo "  sessionId               : ${SID:-none}"

if [ "$ATTACHED" = "1" ] && [ "$NOTCONN" = "0" ]; then
  echo "  VERDICT                 : ATTACHED - gate PASS"
  if [ "$FLOWS_EMPTY" = "1" ]; then
    echo "  coverage caveat         : attached, but .reticle/flows is EMPTY, so no saved"
    echo "                            flow was replayed. Attachment is proven; flow"
    echo "                            coverage is NONE. Record flows to raise this."
  fi
  echo "  log                     : ${LOG}"
  echo "  ----------------------------------------------------------------"
  exit 0
fi

if [ "$NOTCONN" = "1" ]; then
  echo "  VERDICT                 : NOT ATTACHED - gate FAIL"
  echo "                            Reticle drove the URL but no browser session dialled back."
  echo "                            Usual cause: the build under test carries no Reticle SDK,"
  echo "                            which is expected for a production build because the SDK"
  echo "                            is dev-only, or the dev server predates the plugin."
else
  echo "  VERDICT                 : NO ATTACHMENT EVIDENCE - gate FAIL"
  echo "                            stdout carried neither session_connected nor the"
  echo "                            no-app-connected message. Treat as unproven."
fi
echo "  log                     : ${LOG}"
echo "  ----------------------------------------------------------------"
exit 1
