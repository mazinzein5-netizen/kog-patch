/* Kingdom Organics Visual Editor PLUGIN v6 - portable, self-contained, zero dependencies.
   Drop this ONE file onto any page; it stays inert until activated.
     Turn on now :  ?edit=1  |  #edit=1  |  window.KOG_EDIT_FLAG = true  |  KOG_VISUAL_PLUGIN.activate()
     Pencil pill :  ?kog=1 once (remembered on this device)  |  window.KOG_EDIT_PILL = true
   The engine injects all of its own CSS, so nothing else on the host page has to change. */
(function () {
  'use strict';
  if (window.KOG_VISUAL_PLUGIN) { return; }

  var VERSION = '6.0';
  var KPILL = 'kog-editor-pill';
  var FAB = 'kog-fab';

function KOG_ENGINE() {
  'use strict';

  var KEY = 'kog-edits-v4', OLD = 'kog-edits-v3';
  var FONTS = [['Comfortaa', 'Comfortaa'], ['DM Sans', 'DM Sans'], ['System', ''], ['Georgia', 'Georgia, serif'], ['Arial', 'Arial, Helvetica, sans-serif'], ['Courier', 'Courier New, monospace']];
  var TEXT_TAGS = { H1: 1, H2: 1, H3: 1, H4: 1, P: 1, SPAN: 1, LI: 1, A: 1, BUTTON: 1, STRONG: 1, EM: 1, SMALL: 1, BLOCKQUOTE: 1, FIGCAPTION: 1, LABEL: 1 };
  var LAYOUT_TAGS = { SECTION: 1, DIV: 1, HEADER: 1, FOOTER: 1, NAV: 1, MAIN: 1, ARTICLE: 1, UL: 1, OL: 1, FORM: 1, ASIDE: 1 };

  var edits = {}, hist = [], sel = null, dragMode = true, more = false, editing = false, dg = null;
  var idSeq = (function () { var m = 0, a = document.querySelectorAll('[data-kogid]'), i, v; for (i = 0; i < a.length; i++) { v = parseInt(String(a[i].getAttribute('data-kogid')).replace(/[^0-9]/g, ''), 10); if (v > m) { m = v; } } return m; })(), bgCount = 0, reIdxT = null;
  var state = { mode: 'text', canvasZoom: 1, assets: {}, assetN: 0, memOnly: false };
  var ed, rowsEl, hintEl, cntEl, fileIn;

  function ce(t, c, x) { var e = document.createElement(t); if (c) { e.className = c; } if (x != null) { e.textContent = x; } return e; }
  function btn(l, a, c) { var b = ce('button', 'kog-btn' + (c ? ' ' + c : ''), l); b.type = 'button'; b.setAttribute('data-act', a); return b; }
  function hint(t) { if (hintEl) { hintEl.textContent = t || ''; } }
  function idOf(el) { return el ? el.getAttribute('data-kogid') : null; }
  function E(el) { var i = idOf(el); if (!i) { return null; } if (!edits[i]) { edits[i] = {}; } return edits[i]; }
  function has(e, k) { return e && e[k] && Object.keys(e[k]).length > 0; }
  function snap() { hist.push(JSON.stringify(edits)); if (hist.length > 40) { hist.shift(); } }
  function count() { var n = 0, k, j; for (k in edits) { if (!edits[k]) { continue; } for (j in edits[k]) { if (Object.keys(edits[k][j] || {}).length) { n++; break; } } } if (cntEl) { cntEl.textContent = n + ' change' + (n === 1 ? '' : 's'); } return n; }
  function leafText(el) { var c = el.children, i; for (i = 0; i < c.length; i++) { if (c[i].tagName !== 'BR') { return false; } } return (el.textContent || '').trim().length > 0; }
  function kindOf(el) { if (el.tagName === 'IMG') { return 'image'; } if (TEXT_TAGS[el.tagName] && leafText(el)) { return 'text'; } if (LAYOUT_TAGS[el.tagName]) { return 'layout'; } return ''; }
  function pickable(el) { var k = el.getAttribute('data-kogkind'); if (state.mode === 'image') { return k === 'image' || el.getAttribute('data-kogbg') === '1'; } if (state.mode === 'layout') { return k === 'layout'; } return k === 'text'; }

  function load() {
    try {
      try { localStorage.removeItem(OLD); } catch (e0) { }
      var raw = localStorage.getItem(KEY);
      if (!raw) { return; }
      var o = JSON.parse(raw);
      if (o.edits) { edits = o.edits; }
      if (o.state && o.state.canvasZoom) { state.canvasZoom = o.state.canvasZoom; }
      if (o.assets) { state.assets = o.assets; state.assetN = Object.keys(o.assets).length; }
    } catch (e) { edits = {}; }
  }
  function persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify({ v: '4.0', url: location.pathname, saved: new Date().toISOString(), state: { canvasZoom: state.canvasZoom }, edits: edits, assets: state.assets }));
      state.memOnly = false;
    } catch (e) { state.memOnly = true; }
  }

  function hasBgUrl(el) {
    if (!/^(DIV|SECTION|HEADER|FOOTER|NAV|MAIN|ARTICLE|ASIDE|FIGURE|A|LI|SPAN|TD)$/.test(el.tagName)) { return false; }
    var b = '';
    try { b = getComputedStyle(el).backgroundImage || ''; } catch (e) { return false; }
    return b.indexOf('url(') === 0;
  }
  function index() {
    var all = document.querySelectorAll('body *'), i, el, added = 0;
    for (i = 0; i < all.length; i++) {
      el = all[i];
      if ((ed && ed.contains(el)) || el.id === 'kog-fab' || (el.closest && el.closest('#kog-fab'))) { continue; }
      if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE' || el.tagName === 'NOSCRIPT' || el.tagName === 'LINK') { continue; }
      if (!el.getAttribute('data-kogid')) { idSeq++; el.setAttribute('data-kogid', 'e' + idSeq); added++; }
      el.setAttribute('data-kogkind', kindOf(el));
      if (hasBgUrl(el)) { el.setAttribute('data-kogbg', '1'); } else if (el.getAttribute('data-kogbg')) { el.removeAttribute('data-kogbg'); }
    }
    return added;
  }
  function scheduleReindex() {
    if (reIdxT) { return; }
    reIdxT = setTimeout(function () {
      reIdxT = null;
      var added = index();
      if (added > 0) { applyAll(); marks(); count(); hint('New content indexed: ' + added + ' element(s)'); }
    }, 300);
  }
  function findBgAt(x, y) {
    if (state.mode !== 'image' || typeof x !== 'number' || !document.elementsFromPoint) { return null; }
    var list = document.elementsFromPoint(x, y), i;
    for (i = 0; i < list.length; i++) { if (list[i].getAttribute && list[i].getAttribute('data-kogbg') === '1') { return list[i]; } }
    return null;
  }

  function reorder(el, idx) {
    var p = el.parentNode, sib = [], i, c;
    if (!p) { return; }
    for (i = 0; i < p.children.length; i++) { sib.push(p.children[i]); }
    c = sib.indexOf(el);
    var want = Math.max(0, Math.min(sib.length - 1, idx));
    if (c < 0 || c === want) { return; }
    p.insertBefore(el, want > c ? sib[want].nextSibling : sib[want]);
  }

  function apply(el) {
    var i = idOf(el), e = i ? edits[i] : null, t, m, im, ly, pos;
    if (!e) { return; }
    t = e.text || {}; m = e.move || {}; im = e.image || {}; ly = e.layout || {};
    if (m.x || m.y) {
      pos = getComputedStyle(el).position;
      el.style.position = (pos === 'absolute' || pos === 'fixed') ? pos : 'relative';
      el.style.left = (m.x || 0) + 'px';
      el.style.top = (m.y || 0) + 'px';
    }
    if (t.hidden) { el.style.display = 'none'; } else if (el.style.display === 'none') { el.style.display = ''; }
    if (t.align) { el.style.textAlign = t.align; }
    if (t.font) { el.style.fontFamily = t.font; }
    if (t.size) { el.style.fontSize = t.size + 'px'; }
    if (t.bold !== undefined) { el.style.fontWeight = t.bold ? '700' : ''; }
    if (t.ital !== undefined) { el.style.fontStyle = t.ital ? 'italic' : ''; }
    if (t.html != null) { el.innerHTML = t.html; }
    var isBg = el.getAttribute('data-kogbg') === '1';
    if (im.scale) { if (isBg) { el.style.backgroundSize = Math.round(100 * im.scale) + '%'; } else { el.style.scale = String(im.scale); } }
    if (im.fit) { if (isBg) { el.style.backgroundSize = im.fit; } else { el.style.objectFit = im.fit; } }
    if (im.width) { el.style.width = im.width; }
    if (im.height) { el.style.height = im.height; }
    if (im.radius != null) { el.style.borderRadius = im.radius + 'px'; }
    if (im.opacity != null) { el.style.opacity = String(im.opacity); }
    if (im.src) { if (isBg) { el.style.backgroundImage = 'url(' + im.src + ')'; } else { el.setAttribute('src', im.src); } }
    if (ly.gap) { el.style.gap = ly.gap + 'px'; }
    if (ly.dir) { el.style.display = 'flex'; el.style.flexDirection = ly.dir; }
    if (ly.align) { el.style.alignItems = ly.align; }
    if (ly.justify) { el.style.justifyContent = ly.justify; }
    if (ly.cols) { el.style.display = 'grid'; el.style.gridTemplateColumns = 'repeat(' + ly.cols + ',minmax(0,1fr))'; }
    if (ly.pad != null) { el.style.padding = ly.pad + 'px'; }
    if (ly.maxw) { el.style.maxWidth = ly.maxw; }
    if (ly.order != null) { reorder(el, ly.order); }
  }

  function applyAll() { var all = document.querySelectorAll('[data-kogid]'), i; for (i = 0; i < all.length; i++) { apply(all[i]); } }

  function canvasZoom(z) {
    state.canvasZoom = Math.max(0.5, Math.min(2, Math.round(z * 100) / 100));
    document.documentElement.style.zoom = String(state.canvasZoom);
    if (ed) { ed.style.zoom = String(1 / state.canvasZoom); }
    hint('Canvas zoom ' + Math.round(state.canvasZoom * 100) + '%');
  }

  function lockScroll(on) {
    document.documentElement.classList.toggle('kog-noscroll', !!on);
    document.body.style.touchAction = on ? 'none' : '';
  }

  function marks() {
    var all = document.querySelectorAll('[data-kogkind]'), i;
    for (i = 0; i < all.length; i++) { all[i].classList.toggle('kog-hit', pickable(all[i])); }
  }
  function select(el) {
    if (sel) { sel.classList.remove('kog-sel'); }
    sel = el;
    if (sel) { sel.classList.add('kog-sel'); }
    var n = sel ? sel.tagName.toLowerCase() + (sel.getAttribute('data-kogbg') === '1' ? ' (bg image)' : '') + ' ' + (sel.className || '').toString().slice(0, 28) : 'nothing';
    hint('Selected ' + n);
    renderRows();
  }
  function findTarget(node) {
    var el = node;
    while (el && el.nodeType === 1) {
      if (el.getAttribute('data-kogid') && pickable(el)) { return el; }
      if (el === document.body) { return null; }
      el = el.parentElement;
    }
    return null;
  }

  function assetAdd(name, bytes, dataUrl) {
    state.assetN++;
    var id = 'IMG' + state.assetN;
    state.assets[id] = { name: name, bytes: bytes, dataUrl: dataUrl };
    return id;
  }
  function assetDownload() {
    var k = Object.keys(state.assets), i, a;
    if (!k.length) { hint('No inserted images yet'); return; }
    for (i = 0; i < k.length; i++) {
      a = ce('a');
      a.href = state.assets[k[i]].dataUrl;
      a.download = state.assets[k[i]].name || (k[i] + '.png');
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
    hint('Downloaded ' + k.length + ' image(s)');
  }

  function textRows() {
    var r = [[btn('Edit text', 'edit-text', 'p'), btn('Hide', (has(edits[idOf(sel)], 'text') && edits[idOf(sel)].text.hidden) ? 'Show' : 'Hide', 'hide'), btn('Undo', 'undo'), btn(more ? 'Less' : 'More', 'more')]];
    if (more) {
      r.push([btn('Left', 'al-left'), btn('Center', 'al-center'), btn('Right', 'al-right'), btn('A-', 'sz-'), btn('A+', 'sz+'), btn('B', 'bold', 'b'), btn('I', 'ital', 'i')]);
      var s = ce('select', 'kog-scin');
      var cur = sel && edits[idOf(sel)] ? (edits[idOf(sel)].text || {}).font : '';
      for (var i = 0; i < FONTS.length; i++) {
        var o = ce('option', '', FONTS[i][0]);
        o.value = FONTS[i][1];
        if (cur === FONTS[i][1]) { o.selected = true; }
        s.appendChild(o);
      }
      s.setAttribute('data-act', 'font');
      r.push([s]);
    }
    r.push([btn('Drag: ' + (dragMode ? 'ON' : 'OFF'), 'drag'), btn('Up', 'scr-up'), btn('Down', 'scr-dn'), btn('Reset', 'reset')]);
    r.push([btn('Save', 'save', 'g'), btn('Send changes', 'send', 'g'), btn('HTML', 'html'), btn('Exit', 'exit')]);
    return r;
  }
  function imageRows() {
    var im = sel && edits[idOf(sel)] ? (edits[idOf(sel)].image || {}) : {};
    var r = [[btn('Replace', 'img-rep', 'p'), btn('Add image', 'img-add'), btn('Delete', 'img-del', 'r'), btn('Undo', 'undo')]];
    r.push([btn('Zoom -', 'im-zm-'), btn('Zoom +', 'im-zm+'), btn('Fit: ' + (im.fit || 'cover'), 'im-fit'), btn('Round -', 'im-rd-'), btn('Round +', 'im-rd+')]);
    r.push([btn('Width -', 'im-w-'), btn('Width +', 'im-w+'), btn('Ratio: ' + (im.prop === false ? 'free' : 'lock'), 'im-prop'), btn('Fade -', 'im-fa-'), btn('Fade +', 'im-fa+')]);
    r.push([btn('Save image', 'img-save'), btn('Up', 'scr-up'), btn('Down', 'scr-dn'), btn('Reset', 'reset')]);
    r.push([btn('Save', 'save', 'g'), btn('Send changes', 'send', 'g'), btn('HTML', 'html'), btn('Exit', 'exit')]);
    return r;
  }
  function layoutRows() {
    return [
      [btn('Z -', 'z-'), btn('Z +', 'z+'), btn('100%', 'z100'), btn(more ? 'Less' : 'More', 'more'), btn('Undo', 'undo')],
      [btn('Gap -', 'ly-g-'), btn('Gap +', 'ly-g+'), btn('Row', 'ly-row'), btn('Column', 'ly-col'), btn('Cols -', 'ly-c-'), btn('Cols +', 'ly-c+')],
      [btn('Start', 'ly-a-start'), btn('Middle', 'ly-a-center'), btn('End', 'ly-a-end'), btn('Space between', 'ly-j-between')],
      [btn('Pad -', 'ly-p-'), btn('Pad +', 'ly-p+'), btn('Full', 'ly-w-full'), btn('90%', 'ly-w-90'), btn('50%', 'ly-w-50')],
      [btn('Move up', 'ly-up'), btn('Move down', 'ly-dn'), btn('Drag: ' + (dragMode ? 'ON' : 'OFF'), 'drag'), btn('Reset', 'reset')],
      [btn('Save', 'save', 'g'), btn('Send changes', 'send', 'g'), btn('HTML', 'html'), btn('Exit', 'exit')]
    ];
  }
  function renderRows() {
    rowsEl.innerHTML = '';
    var spec = state.mode === 'image' ? imageRows() : (state.mode === 'layout' ? layoutRows() : textRows());
    for (var i = 0; i < spec.length; i++) {
      var r = ce('div', 'kog-row');
      for (var j = 0; j < spec[i].length; j++) { r.appendChild(spec[i][j]); }
      rowsEl.appendChild(r);
    }
  }
  function setMode(m) {
    state.mode = m;
    if (sel && !pickable(sel)) { select(null); }
    var tabs = ed.querySelectorAll('.kog-tab');
    for (var i = 0; i < tabs.length; i++) { tabs[i].classList.toggle('on', tabs[i].getAttribute('data-mode') === m); }
    marks();
    renderRows();
    hint(m.toUpperCase() + ' mode - tap a ' + (m === 'image' ? 'picture' : (m === 'layout' ? 'block' : 'line of text')));
  }

  function step(cur, d, min, max) { return Math.max(min, Math.min(max, cur + d)); }
  function curMove(el) { var e = edits[idOf(el)]; return (e && e.move) ? { x: e.move.x || 0, y: e.move.y || 0 } : { x: 0, y: 0 }; }
  function curNum(el, grp, key, fallback) { var e = edits[idOf(el)]; var g = e ? e[grp] : null; var v = g ? g[key] : undefined; return (v == null) ? fallback : v; }

  function doAct(a, tgt) {
    var e, im, ly, m, cs;
    if (a === 'reset') { try { localStorage.removeItem(KEY); localStorage.removeItem(OLD); } catch (x) { } location.href = location.pathname; return; }
    if (a === 'exit') { location.href = location.pathname; return; }
    if (a === 'save') { persist(); hint(state.memOnly ? 'Saved in memory only - image too large to store' : 'Saved on this device'); return; }
    if (a === 'send') { modal(exportJSON()); return; }
    if (a === 'html') { download('index-edited.html', cleanHTML()); return; }
    if (a === 'undo') { if (hist.length) { edits = JSON.parse(hist.pop()); location.reload(); } else { hint('Nothing to undo'); } return; }
    if (a === 'more') { more = !more; renderRows(); return; }
    if (a === 'drag') { dragMode = !dragMode; lockScroll(dragMode); renderRows(); hint(dragMode ? 'Drag mode ON - page scroll paused' : 'Drag mode OFF - normal scrolling'); return; }
    if (a === 'scr-up') { window.scrollBy(0, -Math.round(innerHeight * 0.7)); return; }
    if (a === 'scr-dn') { window.scrollBy(0, Math.round(innerHeight * 0.7)); return; }
    if (a === 'z-') { canvasZoom(state.canvasZoom - 0.1); return; }
    if (a === 'z+') { canvasZoom(state.canvasZoom + 0.1); return; }
    if (a === 'z100') { canvasZoom(1); return; }
    if (a === 'img-add') { fileIn.setAttribute('data-for', 'add'); fileIn.click(); return; }
    if (a === 'img-rep') {
      if (!sel || (sel.tagName !== 'IMG' && sel.getAttribute('data-kogbg') !== '1')) { hint('Pick an image first'); return; }
      fileIn.setAttribute('data-for', 'rep'); fileIn.click(); return;
    }
    if (a === 'img-save') { assetDownload(); return; }
    if (!sel) { hint('Tap something first'); return; }

    if (a === 'edit-text') {
      editing = !editing;
      sel.setAttribute('contenteditable', editing ? 'true' : 'false');
      if (editing) { sel.focus(); hint('Type, then tap Done text'); } else {
        snap(); E(sel).text = E(sel).text || {}; E(sel).text.html = sel.innerHTML; persist(); hint('Text saved');
      }
      renderRows(); return;
    }
    if (a === 'hide') { snap(); e = E(sel); e.text = e.text || {}; e.text.hidden = !e.text.hidden; apply(sel); persist(); renderRows(); hint(e.text.hidden ? 'Hidden' : 'Shown'); return; }
    if (a === 'al-left' || a === 'al-center' || a === 'al-right') { snap(); e = E(sel); e.text = e.text || {}; e.text.align = a.split('-')[1]; apply(sel); persist(); hint('Aligned ' + e.text.align); return; }
    if (a === 'sz-' || a === 'sz+') { snap(); cs = parseFloat(getComputedStyle(sel).fontSize) || 16; e = E(sel); e.text = e.text || {}; e.text.size = step(cs, a === 'sz+' ? 2 : -2, 10, 96); apply(sel); persist(); hint('Size ' + e.text.size + 'px'); return; }
    if (a === 'bold' || a === 'ital') { snap(); e = E(sel); e.text = e.text || {}; var kk = a === 'bold' ? 'bold' : 'ital'; var nowb = kk === 'bold' ? getComputedStyle(sel).fontWeight : getComputedStyle(sel).fontStyle; e.text[kk] = kk === 'bold' ? !(parseInt(nowb, 10) >= 600) : !(nowb === 'italic'); apply(sel); persist(); hint(kk + ' ' + (e.text[kk] ? 'on' : 'off')); return; }

    if (state.mode === 'image') {
      e = E(sel); e.image = e.image || {}; im = e.image;
      if (a === 'im-zm-' || a === 'im-zm+') { snap(); im.scale = step(im.scale || 1, a === 'im-zm+' ? 0.1 : -0.1, 0.2, 3); }
      else if (a === 'im-fit') { snap(); var order = ['cover', 'contain', 'fill', 'none']; im.fit = order[(order.indexOf(im.fit || 'cover') + 1) % order.length]; }
      else if (a === 'im-rd-' || a === 'im-rd+') { snap(); im.radius = step(im.radius || 0, a === 'im-rd+' ? 4 : -4, 0, 200); }
      else if (a === 'im-fa-' || a === 'im-fa+') { snap(); im.opacity = step(im.opacity == null ? 1 : im.opacity, a === 'im-fa+' ? 0.1 : -0.1, 0.1, 1); }
      else if (a === 'im-prop') { snap(); im.prop = im.prop === false; if (im.prop !== false) { im.height = null; sel.style.height = ''; } }
      else if (a === 'im-w-' || a === 'im-w+') { snap(); cs = sel.getBoundingClientRect().width; var base = im.width ? parseFloat(im.width) : Math.round(cs); im.width = step(base, a === 'im-w+' ? 10 : -10, 40, 2000) + 'px'; if (im.prop !== false && sel.naturalWidth) { im.height = Math.round(parseFloat(im.width) * sel.naturalHeight / sel.naturalWidth) + 'px'; } }
      else if (a === 'img-del') { snap(); e.image = null; if (sel.getAttribute('data-kogbg') === '1') { sel.style.backgroundImage = 'none'; hint('Background image removed'); } else { sel.parentNode.removeChild(sel); hint('Image removed'); } select(null); persist(); hint('Image removed'); renderRows(); return; }
      apply(sel); persist(); renderRows(); hint('Image: ' + JSON.stringify(im).slice(0, 90)); return;
    }

    if (state.mode === 'layout') {
      e = E(sel); e.layout = e.layout || {}; ly = e.layout;
      if (a === 'ly-g-' || a === 'ly-g+') { snap(); ly.gap = step(ly.gap == null ? (parseInt(getComputedStyle(sel).gap, 10) || 0) : ly.gap, a === 'ly-g+' ? 4 : -4, 0, 120); }
      else if (a === 'ly-row') { snap(); ly.dir = 'row'; }
      else if (a === 'ly-col') { snap(); ly.dir = 'column'; }
      else if (a === 'ly-c-' || a === 'ly-c+') { snap(); ly.cols = step(ly.cols || 1, a === 'ly-c+' ? 1 : -1, 1, 6); }
      else if (a === 'ly-a-start' || a === 'ly-a-center' || a === 'ly-a-end') { snap(); ly.align = a.replace('ly-a-', ''); }
      else if (a === 'ly-j-between') { snap(); ly.justify = 'space-between'; }
      else if (a === 'ly-p-' || a === 'ly-p+') { snap(); ly.pad = step(ly.pad == null ? (parseInt(getComputedStyle(sel).paddingTop, 10) || 0) : ly.pad, a === 'ly-p+' ? 4 : -4, 0, 160); }
      else if (a === 'ly-w-full') { snap(); ly.maxw = '100%'; }
      else if (a === 'ly-w-90') { snap(); ly.maxw = '90%'; }
      else if (a === 'ly-w-50') { snap(); ly.maxw = '50%'; }
      else if (a === 'ly-up' || a === 'ly-dn') {
        snap();
        var p = sel.parentNode, sib = [], i;
        for (i = 0; i < p.children.length; i++) { sib.push(p.children[i]); }
        var c = sib.indexOf(sel);
        var w = step(c, a === 'ly-up' ? -1 : 1, 0, sib.length - 1);
        ly.order = w; reorder(sel, w); persist(); renderRows(); hint('Moved to ' + (w + 1) + ' of ' + sib.length); return;
      }
      apply(sel); persist(); renderRows(); hint('Layout: ' + JSON.stringify(ly).slice(0, 90)); return;
    }
  }

  function modal(text) {
    var ov = ce('div', 'kog-ov'); ov.id = 'kog-modal';
    var ta = ce('textarea', 'kog-ta'); ta.value = text;
    var row = ce('div', 'kog-row');
    var cp = btn('Copy', 'cp', 'g'), cl = btn('Close', 'cl');
    row.appendChild(cp); row.appendChild(cl);
    ov.appendChild(ta); ov.appendChild(row);
    document.body.appendChild(ov);
    cp.onclick = function () { ta.select(); try { document.execCommand('copy'); hint('Copied - paste it to me'); } catch (x) { hint('Select all and copy manually'); } };
    cl.onclick = function () { document.body.removeChild(ov); };
  }
  function download(name, text) {
    var b = new Blob([text], { type: 'text/html' }), a = ce('a');
    a.href = URL.createObjectURL(b); a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    hint('Saved ' + name);
  }
  function exportJSON() {
    var small = JSON.stringify(state.assets).length < 300000;
    var out = { version: '5.0', url: location.pathname, saved: new Date().toISOString(), canvasZoom: state.canvasZoom, edits: edits };
    out.assets = {};
    var k;
    for (k in state.assets) { out.assets[k] = { name: state.assets[k].name, bytes: state.assets[k].bytes }; }
    if (small) { for (k in state.assets) { out.assets[k].dataUrl = state.assets[k].dataUrl; } }
    return JSON.stringify(out, null, 2);
  }
  function cleanHTML() {
    var c = document.documentElement.cloneNode(true);
    var rm = c.querySelectorAll('#kog-ed, #kog-modal, [data-kog]'), i, all;
    for (i = 0; i < rm.length; i++) { if (rm[i].parentNode) { rm[i].parentNode.removeChild(rm[i]); } }
    all = c.querySelectorAll('[data-kogid],[data-kogkind],[data-kogbg],[contenteditable]');
    for (i = 0; i < all.length; i++) {
      all[i].removeAttribute('data-kogid'); all[i].removeAttribute('data-kogkind'); all[i].removeAttribute('data-kogbg'); all[i].removeAttribute('contenteditable');
      all[i].classList.remove('kog-sel'); all[i].classList.remove('kog-hit');
    }
    return '<!DOCTYPE html>' + c.outerHTML;
  }

  function build() {
    var st = ce('style'); st.setAttribute('data-kog', '1');
    st.textContent = [
      '.kog-hit{outline:1px dashed rgba(255,209,102,.55) !important;outline-offset:1px}',
      '.kog-sel{outline:3px solid #FFD166 !important;outline-offset:2px}',
      '.kog-noscroll{overflow:hidden !important;touch-action:none}',
      '#kog-ed{position:fixed;left:0;right:0;bottom:0;z-index:2147483000;background:#0B1220;border-top:1px solid rgba(255,209,102,.35);padding:8px 8px calc(8px + env(safe-area-inset-bottom));font:12px/1.3 system-ui,sans-serif;color:#fff}',
      '#kog-ed .kog-tabs{display:flex;gap:6px;margin-bottom:6px}',
      '#kog-ed .kog-tab{flex:1;min-height:40px;border-radius:10px;border:1px solid rgba(255,255,255,.22);background:#16213A;color:#fff;font-weight:700}',
      '#kog-ed .kog-tab.on{background:#FFD166;color:#111827;border-color:#FFD166}',
      '#kog-ed .kog-row{display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap}',
      '#kog-ed .kog-btn{min-height:44px;flex:1 1 auto;border-radius:10px;border:1px solid rgba(255,255,255,.22);background:#1E2A44;color:#fff;font-weight:600}',
      '#kog-ed .kog-btn.p{background:#2563EB;border-color:#2563EB}',
      '#kog-ed .kog-btn.g{background:#15803D;border-color:#15803D}',
      '#kog-ed .kog-btn.r{background:#B91C1C;border-color:#B91C1C}',
      '#kog-ed .kog-btn.b{font-weight:900}',
      '#kog-ed .kog-btn.i{font-style:italic}',
      '#kog-ed .kog-scin{min-height:44px;flex:1;border-radius:10px;background:#1E2A44;color:#fff;border:1px solid rgba(255,255,255,.22)}',
      '#kog-ed .kog-foot{display:flex;justify-content:space-between;gap:8px;opacity:.85;font-size:11px}',
      '.kog-ov{position:fixed;inset:0;z-index:2147483600;background:rgba(4,10,24,.94);padding:14px;display:flex;flex-direction:column;gap:8px}',
      '.kog-ta{flex:1;width:100%;border-radius:10px;border:1px solid rgba(255,255,255,.25);background:#0B1220;color:#fff;font:12px/1.4 monospace;padding:10px}'
    ].join('');
    document.head.appendChild(st);

    ed = ce('div'); ed.id = 'kog-ed';
    var tabs = ce('div', 'kog-tabs');
    var names = [['text', 'Text'], ['image', 'Image'], ['layout', 'Layout']];
    for (var i = 0; i < names.length; i++) {
      var tb = ce('button', 'kog-tab', names[i][1]);
      tb.type = 'button'; tb.setAttribute('data-mode', names[i][0]);
      tb.onclick = (function (m) { return function () { setMode(m); }; }(names[i][0]));
      tabs.appendChild(tb);
    }
    rowsEl = ce('div');
    var foot = ce('div', 'kog-foot');
    hintEl = ce('span', '', 'Ready');
    cntEl = ce('span', '', '0 changes');
    foot.appendChild(hintEl); foot.appendChild(cntEl);
    ed.appendChild(tabs); ed.appendChild(rowsEl); ed.appendChild(foot);
    document.body.appendChild(ed);

    fileIn = ce('input');
    fileIn.type = 'file'; fileIn.accept = 'image/*'; fileIn.style.display = 'none'; fileIn.setAttribute('data-kog', '1');
    fileIn.onchange = function () {
      var f = fileIn.files && fileIn.files[0];
      if (!f) { return; }
      var mode = fileIn.getAttribute('data-for');
      var fr = new FileReader();
      fr.onload = function () {
        var id = assetAdd(f.name, f.size, String(fr.result));
        if (mode === 'rep' && sel && (sel.tagName === 'IMG' || sel.getAttribute('data-kogbg') === '1')) {
          snap(); E(sel).image = E(sel).image || {}; E(sel).image.src = String(fr.result); apply(sel); hint('Replaced with ' + f.name + ' (' + id + ')');
        } else {
          idSeq++; var img = ce('img'); img.src = String(fr.result); img.setAttribute('data-kogid', 'e' + idSeq); img.setAttribute('data-kogkind', 'image');
          img.style.maxWidth = '100%'; img.className = 'kog-hit';
          var host = (sel && state.mode === 'layout' && sel.tagName !== 'IMG') ? sel : (sel && sel.parentNode ? sel.parentNode : document.body);
          host.appendChild(img);
          hint('Inserted ' + f.name + ' (' + id + ') - save image to download it');
        }
        persist(); count();
      };
      fr.readAsDataURL(f);
      fileIn.value = '';
    };
    document.body.appendChild(fileIn);
    ed.style.zoom = String(1 / state.canvasZoom);
  }

  ed = null;
  load();
  build();
  index();
  applyAll();
  setMode('text');
  if (state.canvasZoom !== 1) { canvasZoom(state.canvasZoom); }
  lockScroll(dragMode);
  count();
  if (window.MutationObserver) {
    new MutationObserver(function () { scheduleReindex(); }).observe(document.body, { childList: true, subtree: true });
  }

  document.addEventListener('click', function (ev) {
    var t = ev.target;
    if (t.closest && t.closest('#kog-ed')) {
      var a = t.getAttribute('data-act'), v = t.value;
      if (a === 'font') { if (sel) { snap(); E(sel).text = E(sel).text || {}; E(sel).text.font = v; apply(sel); persist(); hint('Font set'); } return; }
      if (a) { ev.preventDefault(); doAct(a); }
      return;
    }
    if (editing) { return; }
    var el = findTarget(t) || findBgAt(ev.clientX, ev.clientY);
    if (el && el !== sel) { select(el); }
  }, true);

  document.addEventListener('pointerdown', function (ev) {
    if (!dragMode || editing) { return; }
    if (ev.target.closest && (ev.target.closest('#kog-ed') || ev.target.closest('#kog-modal'))) { return; }
    var t = findTarget(ev.target) || findBgAt(ev.clientX, ev.clientY);
    if (!t) { return; }
    var m = curMove(t);
    dg = { el: t, sx: ev.clientX, sy: ev.clientY, bx: m.x, by: m.y };
    select(t);
    snap();
  }, true);
  document.addEventListener('pointermove', function (ev) {
    if (!dg) { return; }
    ev.preventDefault();
    var e = E(dg.el); e.move = e.move || {};
    e.move.x = Math.round(dg.bx + ev.clientX - dg.sx);
    e.move.y = Math.round(dg.by + ev.clientY - dg.sy);
    apply(dg.el);
    hint('x ' + e.move.x + ' y ' + e.move.y);
  }, { passive: false, capture: true });
  document.addEventListener('pointerup', function () {
    if (dg) { persist(); count(); hint('Moved - remember to Save or Send changes'); dg = null; }
  }, true);
  document.addEventListener('touchmove', function (ev) { if (dg) { ev.preventDefault(); } }, { passive: false });

  window.KOG_EDITOR = {
    version: '5.0',
    modes: ['text', 'image', 'layout'],
    setMode: setMode,
    get mode() { return state.mode; },
    edits: function () { return edits; },
    count: count,
    canvasZoom: canvasZoom,
    exportJSON: exportJSON,
    apply: apply,
    select: select,
    doAct: doAct,
    els: function () { return document.querySelectorAll('[data-kogid]').length; },
    bgEls: function () { return document.querySelectorAll('[data-kogbg="1"]').length; },
    reindex: function () { return index(); }
  };
}

  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { if (v) { localStorage.setItem(k, v); } else { localStorage.removeItem(k); } } catch (e) { } }
  function hasFlag(name) {
    try { return location.search.indexOf(name + '=1') >= 0 || location.hash.indexOf(name + '=1') >= 0; }
    catch (e) { return false; }
  }
  function isOn() { return !!window.KOG_EDITOR; }
  function pillWanted() { return window.KOG_EDIT_PILL === true || lsGet(KPILL) === '1'; }

  function fabCss() {
    if (document.getElementById('kog-fab-css')) { return; }
    var s = document.createElement('style');
    s.id = 'kog-fab-css';
    s.textContent =
      '#' + FAB + '{position:fixed;right:14px;bottom:calc(96px + env(safe-area-inset-bottom));z-index:2147483000;' +
      'width:46px;height:46px;padding:0;border-radius:999px;display:flex;align-items:center;justify-content:center;' +
      'background:rgba(4,14,52,.82);color:#FFD166;border:1px solid rgba(255,255,255,.3);' +
      'box-shadow:0 10px 26px rgba(0,0,0,.45);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);cursor:pointer}' +
      '#' + FAB + ':active{transform:scale(.94)}';
    document.head.appendChild(s);
  }

  function showFab() {
    if (document.getElementById(FAB) || isOn()) { return; }
    fabCss();
    var b = document.createElement('button');
    b.id = FAB;
    b.type = 'button';
    b.setAttribute('aria-label', 'Open visual editor');
    b.title = 'Visual editor';
    b.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
    b.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      toggle();
    }, true);
    document.body.appendChild(b);
  }

  function hideFab() {
    var b = document.getElementById(FAB);
    if (b && b.parentNode) { b.parentNode.removeChild(b); }
  }

  function activate() {
    if (isOn()) { return true; }
    window.KOG_EDIT_FLAG = true;
    hideFab();
    try { KOG_ENGINE(); } catch (e) { return false; }
    return isOn();
  }

  function off() {
    if (!isOn()) { return false; }
    try {
      var q = location.search.replace(/([?&])edit=1/, '$1').replace(/[?&]$/, '');
      var hh = location.hash.replace(/([?&])edit=1/, '$1');
      location.replace(location.pathname + q + hh);
    } catch (e) { location.replace(location.pathname); }
    return true;
  }

  function toggle() { if (isOn()) { off(); return false; } return activate(); }

  window.KOG_VISUAL_PLUGIN = {
    version: VERSION,
    activate: activate,
    off: off,
    deactivate: off,
    toggle: toggle,
    isOn: isOn,
    showPill: function () { lsSet(KPILL, '1'); showFab(); },
    hidePill: function () { lsSet(KPILL, ''); hideFab(); },
    engine: function () { return window.KOG_EDITOR || null; }
  };

  if (hasFlag('kog')) { lsSet(KPILL, '1'); }
  if (hasFlag('edit') || window.KOG_EDIT_FLAG === true) {
    activate();
  } else if (pillWanted()) {
    if (document.body) { showFab(); } else { document.addEventListener('DOMContentLoaded', showFab); }
  }
})();
