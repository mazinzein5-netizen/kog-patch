// Minimal event buffer: the 'make the invisible visible' layer.
// Captures errors + key actions into localStorage so field problems are readable
// on-device (same philosophy as the existing kog-last-error strip) and later
// forwardable to the API when a route exists.
const KEY='kog-events';
export type Evt={at:string;kind:string;msg:string;route:string};
const MAX=200;

export const logEvent=(kind:string,msg:string)=>{try{const raw=JSON.parse(localStorage.getItem(KEY)||'[]');const e:Evt={at:new Date().toISOString(),kind,msg:String(kind).indexOf('error')>=0?'':(msg||'')&&location.hash||location.hash};raw.push({at:e.at,kind,msg:String(msg||'').slice(0,300),route:location.hash||'#'});while(raw.length>MAX)raw.shift();localStorage.setItem(KEY,JSON.stringify(raw));(window as any).__kogEvents=raw;}catch(e){}};

// One-time init: fold the existing last-error record (set by main.tsx) into the
// buffer, and keep catching new crashes, without duplicating the visible strip.
export const initEvents=()=>{try{if((window as any).__kogEventsInit)return;(window as any).__kogEventsInit=1;
 const le=JSON.parse(localStorage.getItem('kog-last-error')||'null');
 if(le)logEvent('boot:'+le.kind,(le.msg||'')+' @ '+(le.route||''));
 window.addEventListener('error',(ev)=>{logEvent('error',String((ev&&ev.message)||'unknown'));});
 window.addEventListener('unhandledrejection',(ev:any)=>{const r=ev&&ev.reason;logEvent('promise',String((r&&(r.message||r))||'rejected'));});
 (window as any).__kogEvents=JSON.parse(localStorage.getItem(KEY)||'[]');
}catch(e){}};

export const recentEvents=(n=20)=>{try{const raw=JSON.parse(localStorage.getItem(KEY)||'[]');return raw.slice(-n);}catch(e){return[];}};
