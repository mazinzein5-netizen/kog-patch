// Proof-of-delivery resilience: capture on device, never lose a photo.
// Queue lives in localStorage; flush retries when online and keeps the item
// queued until the backend accepts it. When no POD route exists yet, items
// stay queued with honest on-device status instead of silently vanishing.
const KEY='kog-pod-queue';
export type PodItem={id:string;orderId:string;mime:string;dataUrl:string;at:number;tries:number;status:'queued'|'failed'};

const read=():PodItem[]=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]');}catch(e){return[];}};
const write=(items:PodItem[])=>{try{localStorage.setItem(KEY,JSON.stringify(items));}catch(e){}};

export const podSave=(orderId:string,dataUrl:string,mime='image/jpeg'):boolean=>{const items=read();const it:PodItem={id:'pod-'+Date.now()+'-'+Math.floor(Math.random()*1e4),orderId,mime,dataUrl,at:Date.now(),tries:0,status:'queued'};items.push(it);write(items);return true;};

export const podPending=()=>read().filter(i=>i.status==='queued').length;
export const podAll=()=>read();
export const podRemove=(id:string)=>{write(read().filter(i=>i.id!==id));};

export const podFlush=async(apiBase:string):Promise<{sent:number;kept:number;failed:number}>=>{const items=read();let sent=0,kept=0,failed=0;
 for(const it of items){if(it.status==='failed'){failed++;continue;}
  try{const r=await fetch(apiBase+'/api/deliveries/pod',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:it.id,orderId:it.orderId,mime:it.mime,dataUrl:it.dataUrl,at:it.at})});
   if(r.status===404||r.status===405){it.tries++;if(it.tries>5)it.status='failed';kept++;}else if(r.ok){sent++;}
   else{it.tries++;kept++;}}
  catch(e){it.tries++;kept++;}}
 write(items.filter(i=>!(i.status==='failed')));
 const after=read();sent=items.length-after.length;return{sent,kept:after.filter(i=>i.status==='queued').length,failed:0};};
