// Polling with exponential backoff + jitter: holds battery and server load
// when the signal is poor, snaps back to the base rate when things work.
import {useEffect,useRef} from 'react';
export const usePoll=(fn:()=>Promise<any>,base=8000)=>{const fnRef=useRef(fn);fnRef.current=fn;
 useEffect(()=>{let cancelled=false;let tries=0;let timer:number|undefined=undefined;
  const tick=()=>{if(cancelled)return;
   Promise.resolve().then(()=>fnRef.current()).then(()=>{tries=0;}).catch(()=>{tries=Math.min(tries+1,4);}).finally(()=>{if(cancelled)return;
    const delay=Math.min(60000,base*Math.pow(2,tries))+Math.floor(Math.random()*1500);
    timer=window.setTimeout(tick,delay);});};
  tick();return()=>{cancelled=true;if(timer)clearTimeout(timer);};},[base]);};
