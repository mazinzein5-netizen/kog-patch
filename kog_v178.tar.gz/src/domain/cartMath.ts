// Pure basket/cart math. No React, no network, no UI — testable anywhere.
// Source of truth for money rules, shared by Cart display and Checkout charge.
export const FREE_DELIVERY_THRESHOLD=20;
export const DELIVERY_FEE=4.5;

export const eur=(n:number)=>'€'+n.toFixed(2);

// Pickup never pays delivery. Empty basket pays nothing.
export const deliveryFee=(subtotal:number,pickup:boolean)=>pickup?0:(subtotal>=FREE_DELIVERY_THRESHOLD||subtotal===0?0:DELIVERY_FEE);

// items: [{price,qty}] -> {subtotal,fee,total}
export const basketTotals=(items:{price:number;qty:number}[],pickup:boolean)=>{const subtotal=items.reduce((s,i)=>s+i.price*i.qty,0);const fee=deliveryFee(subtotal,pickup);return{subtotal,fee,total:subtotal+fee};};
