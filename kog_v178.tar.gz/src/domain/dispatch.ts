import {api} from '../api';

const P='kog-pending-job',A='kog-active-job',L='kog-last-job',M='kog-my-deliveries';
const rj=(k:string,d:any):any=>{try{const raw=localStorage.getItem(k);if(raw===null||raw===''||raw==='null')return d;return JSON.parse(raw);}catch(e){return d;}};
const wj=(k:string,v:any)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}};
export const getPendingJob=()=>rj(P,null);
export const setPendingJob=(d:any)=>wj(P,d);
export const clearPendingJob=()=>wj(P,null);
export const getActiveJob=()=>rj(A,null);
export const setActiveJob=(d:any)=>wj(A,d);
export const clearActiveJob=()=>wj(A,null);
export const setLastJob=(d:any)=>wj(L,d);
export const getLastJob=()=>rj(L,null);
export const getMyDelivered=()=>{const v=rj(M,[]);return Array.isArray(v)?v:[];};
export const pushDelivered=(d:any)=>{const list=getMyDelivered();list.push({id:d.id,store:d.store,area:d.area,customer_name:d.customer_name||'Customer',km:d.km||0,fee:d.fee||0,tip:d.tip||0,completedAt:Math.floor(Date.now()/1000)});while(list.length>200)list.shift();wj(M,list);};
export const getMyDeliveredToday=()=>{const t=new Date().toDateString();return getMyDelivered().filter((d:any)=>new Date(d.completedAt*1000).toDateString()===t);};
export const earningsFrom=(list:any[])=>{const fee=list.reduce((s,d)=>s+(d.fee||0),0);const tip=list.reduce((s,d)=>s+(d.tip||0),0);const km=list.reduce((s,d)=>s+(d.km||0),0);const total=fee+tip;return{count:list.length,fee,tip,km,total,avg:list.length?total/list.length:0};};
export const myEmail=()=>{const a=rj('ko-account',null);if(a&&a.email)return a.email;return 'driver@kingdomorganics.ie';};
export const claimJob=async(id:string,my:string)=>{try{const r=await api.deliveries.claim(id,my);if(r&&r.ok)return{ok:true,delivery:r.delivery||null};if(r&&r.delivery&&String(r.delivery.claimed_by||'').toLowerCase()===String(my||'').toLowerCase())return{ok:true,delivery:r.delivery};if(r)return{ok:false,error:'lost'};return{ok:false,error:'lost'};}catch(e){return{ok:false,error:'network'};}};
