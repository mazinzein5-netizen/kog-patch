import React,{createContext,useContext} from 'react';

// Session + cart state contract. Pure leaf: imports nothing from the app graph.
export type Cart={[k:string]:number};
export const Ctx=createContext<{cart:Cart;add:(id:string)=>void;dec:(id:string)=>void;store:string;setStore:(s:string)=>void;role:string;setRole:(r:string)=>void;signOut:()=>void;signIn:(r:string)=>void;user:string;clear:()=>void;refreshKey:number;refresh:()=>void}>({cart:{},add:()=>{},dec:()=>{},store:'kingdom',setStore:()=>{},role:'customer',setRole:()=>{},signOut:()=>{},signIn:()=>{},user:'Guest',clear:()=>{},refreshKey:0,refresh:()=>{}});
export const useApp=()=>useContext(Ctx);
