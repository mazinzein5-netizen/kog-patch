BATCH B - Kingdom Organics Expo shell (kog_expo)
================================================

What this fixes
---------------
B1  WebView cache control. The shell had NO cache settings, so Android served a
    frozen old copy of the site. This is why the APK looked weeks out of date
    while the browser showed the current build.
B1b CACHE_TAG folded into the loaded URL, so any intermediate cache sees a new
    request too.
B2  Double splash removed. app.json declared a splash AND App.js drew its own
    overlay from the same image, so the logo appeared at two sizes on cold
    start. The overlay is kept (it has the progress bar and slow-server note).
B3  versionCode 2 -> 3.
B4  preview.autoIncrement = true. Without it every sideloaded APK reused the
    same versionCode and Android refused to install over it.
B5  The shell no longer injects body/header/nav/main pixel offsets. The website
    owns the safe-area now. The shell still sets --kog-safe-top and
    --kog-safe-bottom, which is what the website reads, and which keeps older
    installed APKs working.

How to run
----------
    cd $HOME/kog_expo
    cp patch_batchB.py .
    python3 patch_batchB.py

The patcher is idempotent: running it twice changes nothing the second time.
It backs up App.js, app.json and eas.json to *.bak_batchB before touching them.

If it prints ABORT, nothing was written in that step. Send the output back.

Revert
------
    cd $HOME/kog_expo
    cp -f App.js.bak_batchB App.js
    cp -f app.json.bak_batchB app.json
    cp -f eas.json.bak_batchB eas.json

Then build
----------
    cd $HOME/kog_expo
    eas whoami
    eas build -p android --profile preview --wait

preview (not production) is correct here: production builds an app-bundle (AAB),
while preview builds the sideloadable APK.

After the build finishes, paste the artifact URL back so the APK can be replaced
in public/download and apk.json updated with its real size and versionCode.
