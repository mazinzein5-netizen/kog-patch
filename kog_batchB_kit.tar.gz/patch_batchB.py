#!/usr/bin/env python3
"""Batch B patch for ~/kog_expo. Idempotent, assertion-gated, revertible.

Rule used throughout: a marker containing double quotes is written single-quoted,
and a marker containing an apostrophe is written double-quoted. No escaping.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
APPJS = os.path.join(ROOT, "App.js")
APPJSON = os.path.join(ROOT, "app.json")
EASJSON = os.path.join(ROOT, "eas.json")


def abort(msg):
    print("ABORT: " + msg)
    sys.exit(1)


for f in (APPJS, APPJSON, EASJSON):
    if not os.path.isfile(f):
        abort("missing " + f)

for f in (APPJS, APPJSON, EASJSON):
    b = f + ".bak_batchB"
    if not os.path.exists(b):
        open(b, "wb").write(open(f, "rb").read())
        print("backup " + os.path.basename(b))
    else:
        print("backup exists " + os.path.basename(b))

src = open(APPJS, encoding="utf-8").read()
orig = src

# ---------------- B1: WebView cache control ----------------
anchor = 'originWhitelist={["*"]}'
# Presence check FIRST. The anchor survives insertion, so testing the anchor
# count alone would re-insert on every run and duplicate the props.
if "cacheEnabled={false}" in src and 'cacheMode="LOAD_NO_CACHE"' in src:
    print("B1 already applied")
else:
    n = src.count(anchor)
    if n != 1:
        abort("B1 anchor count %d, expected 1" % n)
    src = src.replace(
        anchor,
        anchor + "\n        cacheEnabled={false}\n        cacheMode=\"LOAD_NO_CACHE\"",
        1,
    )
    print("B1 inserted cacheEnabled + cacheMode")

# ---------------- B1b: CACHE_TAG folded into the loaded URL ----------------
site_line = 'const SITE = process.env.EXPO_PUBLIC_SITE_URL || "https://aura-grocery.vercel.app";'
if "CACHE_TAG" not in src:
    if src.count(site_line) != 1:
        abort("B1b SITE line count %d" % src.count(site_line))
    block = site_line + "\n\n"
    block += "/* Bump CACHE_TAG whenever the web BUILD changes. With LOAD_NO_CACHE the\n"
    block += "   WebView stops serving its own frozen copy; the tag makes the URL\n"
    block += "   unique so any intermediate cache sees a new request too. */\n"
    block += 'const CACHE_TAG = "v173";'
    src = src.replace(site_line, block, 1)
    print("B1b added CACHE_TAG")
else:
    print("B1b CACHE_TAG already present")

old_attr = "source={{ uri: SITE }}"
new_attr = "source={{ uri: siteUrl }}"
if old_attr in src:
    if src.count(old_attr) != 1:
        abort("B1b source uri count %d" % src.count(old_attr))
    src = src.replace(old_attr, new_attr, 1)
    print("B1b swapped source uri to siteUrl")
elif new_attr in src:
    print("B1b source already swapped")
else:
    abort("B1b source uri attribute not found")

if "const siteUrl =" not in src:
    marker = "function Store() {"
    if src.count(marker) != 1:
        abort("B1b Store marker count %d" % src.count(marker))
    inject = 'const siteUrl =\n  SITE + (SITE.indexOf("?") > -1 ? "&" : "?") + "v=" + CACHE_TAG;\n\n'
    src = src.replace(marker, inject + marker, 1)
    print("B1b added siteUrl const")
else:
    print("B1b siteUrl already defined")

# ---------------- B5: shell stops owning layout offsets ----------------
# line-based removal; markers contain apostrophes only, so they are double-quoted
drop_markers = [
    "padding-top:' + top",
    "header.sticky{top:'",
    "nav.bottom-3{bottom:'",
    "main{padding-bottom:' +",
    "body:has(.full-bleed-screen){padding-top:0}",
]
kept = []
removed = 0
for line in src.split("\n"):
    if any(m in line for m in drop_markers):
        removed += 1
        continue
    kept.append(line)
src = "\n".join(kept)
print("B5 layout rules removed: %d of 5" % removed)

keep_line = "    'html[data-shell=\"expo\"]{overscroll-behavior:none;-webkit-tap-highlight-color:transparent}',"
body_overscroll = "    'html[data-shell=\"expo\"] body{overscroll-behavior:none}',"
if removed and body_overscroll not in src:
    if keep_line not in src:
        abort("B5 keep-anchor missing")
    src = src.replace(keep_line, keep_line + "\n" + body_overscroll, 1)
    print("B5 kept a body overscroll rule")

if src != orig:
    open(APPJS, "w", encoding="utf-8").write(src)
    print("App.js written")
else:
    print("App.js unchanged")

# ---------------- B2 + B3: app.json ----------------
j = json.load(open(APPJSON, encoding="utf-8"))
ex = j.get("expo", {})
sp = ex.get("splash", {})
if "image" in sp:
    del sp["image"]
    sp.setdefault("resizeMode", "contain")
    sp.setdefault("backgroundColor", "#000157")
    ex["splash"] = sp
    print("B2 removed splash.image (App.js overlay is now the single splash owner)")
else:
    print("B2 splash.image already absent")

and_ = ex.get("android", {})
vc = and_.get("versionCode")
if vc != 3:
    and_["versionCode"] = 3
    ex["android"] = and_
    print("B3 versionCode %s -> 3" % vc)
else:
    print("B3 versionCode already 3")
j["expo"] = ex
open(APPJSON, "w", encoding="utf-8").write(json.dumps(j, indent=2) + "\n")
print("app.json written")

# ---------------- B4: eas.json preview autoIncrement ----------------
k = json.load(open(EASJSON, encoding="utf-8"))
prev = k.get("build", {}).get("preview", {}).get("autoIncrement")
if prev is not True:
    k.setdefault("build", {}).setdefault("preview", {})["autoIncrement"] = True
    open(EASJSON, "w", encoding="utf-8").write(json.dumps(k, indent=2) + "\n")
    print("B4 preview.autoIncrement %s -> true" % prev)
else:
    print("B4 autoIncrement already true")

# ---------------- verify ----------------
print("")
print("=== VERIFY ===")
v = open(APPJS, encoding="utf-8").read()
print("cacheEnabled={false}        %d" % v.count("cacheEnabled={false}"))
print('cacheMode LOAD_NO_CACHE     %d' % v.count('cacheMode="LOAD_NO_CACHE"'))
print("CACHE_TAG refs              %d" % v.count("CACHE_TAG"))
print("source uses siteUrl         %d" % v.count(new_attr))
print("siteUrl const defined       %d" % v.count("const siteUrl ="))
left = sum(1 for line in v.split("\n") if any(m in line for m in drop_markers))
print("px injection left           %d  (must be 0)" % left)
print("kog-safe-top kept           %d  (must be >=1)" % v.count("--kog-safe-top"))
print("kog-safe-bottom kept        %d  (must be >=1)" % v.count("--kog-safe-bottom"))
j2 = json.load(open(APPJSON, encoding="utf-8"))
print("app.json versionCode        %s" % j2["expo"]["android"]["versionCode"])
print("app.json splash.image       %s" % ("image" in j2["expo"].get("splash", {})))
k2 = json.load(open(EASJSON, encoding="utf-8"))
print("eas preview autoIncrement   %s" % k2["build"]["preview"].get("autoIncrement"))
print("")
if left != 0:
    abort("px injection still present")
if v.count("--kog-safe-top") < 1:
    abort("safe-area vars were lost")
print("PATCH_COMPLETE")
